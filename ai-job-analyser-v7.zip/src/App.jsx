// v1.5.1 - 2026-03-18 - Chat 6 - pre-assign techniques, L9-12 taxonomy, word targets, 3100 budget, rotation tracker
// Changes: prompt caching, ISCO skill targets, debounced picker,
// picker header cleaned (removed redundant instructions),
// search box moved to top of idle screen
import { useState, useCallback, useRef, useEffect } from "react";

const C = {
  bg:         "#f5f7fa",
  surface:    "#ffffff",
  border:     "#dde3ec",
  accent:     "#1a56db",
  accentSoft: "#e8f0fe",
  eu:         "#003399",
  euStar:     "#ffcc00",
  muted:      "#6b7a8d",
  mutedLight: "#9aa5b4",
  text:       "#1a202c",
  textSub:    "#4a5568",
  green:      "#166534",
  greenBg:    "#ecfdf5",
  greenBdr:   "#a7f3d0",
  purple:     "#7c3aed",
  purpleBg:   "#f3e8ff",
  purpleBdr:  "#ddd6fe",
  teal:       "#0e7490",
  tealBg:     "#ecfeff",
  tealBdr:    "#a5f3fc",
  amber:      "#b45309",
  amberBg:    "#fffbeb",
  amberBdr:   "#fcd9a0",
};

async function claudeCall(prompt, maxTokens, attempt = 1, systemPrompt = null, model = "claude-haiku-4-5-20251001") {
  try {
    const body = {
      model,
      max_tokens: maxTokens,
      messages: [{ role: "user", content: prompt }],
    };
    if (systemPrompt) body.system = systemPrompt;

    // Per-call fetch timeout: longer for Sonnet (large output), shorter for Haiku
    const isSonnet = model.includes("sonnet");
    const fetchTimeout = isSonnet ? 150000 : 55000;
    const controller = new AbortController();
    const fetchTimer = setTimeout(() => controller.abort(), fetchTimeout);

    const res = await fetch("/api/claude", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    clearTimeout(fetchTimer);
    if (!res.ok) {
      let msg = `API error ${res.status}`;
      try {
        const e = await res.json();
        msg = e?.message || e?.error?.message || e?.error || msg;
        if (e?.debug) msg = `${msg} [${e.debug}]`;
        if (e?.code)  msg = `${msg} (${e.code})`;
      } catch(_) {}
      throw new Error(msg);
    }
    const data = await res.json();
    const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
    if (!text) throw new Error("Empty response");
    return text;
  } catch(err) {
    if (attempt < 3) {
      const delay = attempt === 1 ? 1500 : 3000;
      await new Promise(r => setTimeout(r, delay));
      return claudeCall(prompt, maxTokens, attempt + 1, systemPrompt, model);
    }
    throw err;
  }
}





function extractJSON(raw, label) {
  let s = raw.replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
  const ai = s.indexOf("[");
  const oi = s.indexOf("{");
  const start = (ai < 0) ? oi : (oi < 0) ? ai : Math.min(ai, oi);
  if (start < 0) throw new Error(`No JSON found for ${label}`);
  const isArr = s[start] === "[";
  const OPEN = isArr ? "[" : "{";
  const CLOSE = isArr ? "]" : "}";
  let depth = 0, lastCompleteClose = -1;
  let inString = false, escape = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (escape) { escape = false; continue; }
    if (c === "\\" && inString) { escape = true; continue; }
    if (c === "\"") { inString = !inString; continue; }
    if (inString) continue;
    if (c === OPEN) depth++;
    else if (c === CLOSE) {
      depth--;
      if (depth === 0) {
        try { return JSON.parse(s.slice(start, i + 1)); } catch(_) { lastCompleteClose = i; }
      }
      if (isArr && depth === 1) lastCompleteClose = i;
    }
  }
  // Truncation recovery: close array at last complete inner object
  if (isArr && lastCompleteClose > start) {
    const attempt1 = s.slice(start, lastCompleteClose + 1) + "]";
    try { const r = JSON.parse(attempt1); if (Array.isArray(r) && r.length > 0) return r; } catch(_) {}
  }
  const end = s.lastIndexOf(CLOSE);
  if (end > start) {
    try { return JSON.parse(s.slice(start, end + 1)); } catch(_) {}
  }
  throw new Error(`Could not parse JSON for ${label}`);
}

async function searchOccupations(keyword, count = "15 to 20") {
  const SYSTEM_SEARCH =
`You are an occupational classification expert specialising in the ESCO v1.2 taxonomy and ISCO-08 coding. Your role is to help workforce practitioners, HR professionals, and individuals identify the right occupation accurately. Apply Singapore and ASEAN labour market context where it differs from US or EU norms.
Return ONLY a JSON array. No text before or after. No markdown fences.
Format: [{"title":"Occupation Title","iscoCode":"1234","iscoGroup":"ISCO group name","industry":"Industry sector","description":"One sentence description","isAltLabel":false}]
Field rules:
- title: exact ESCO v1.2 occupation title - never invented
- iscoCode: 4-digit ISCO-08 code
- iscoGroup: plain English ISCO group name a non-expert would understand
- industry: plain English sector - e.g. Healthcare, Food and Beverage Manufacturing, Finance and Banking, Technology, Education, Retail and Commerce, Manufacturing, Logistics and Supply Chain, Legal and Compliance
- description: one clear sentence, no jargon, no acronyms
- isAltLabel: true only when the match is an alternate label, not the canonical ESCO title
PRECISION RULE: When the search term is a specific professional title (e.g. Food Technologist, Civil Engineer, Financial Analyst), the first result MUST be the closest professional match - not a related trade or hands-on role. Food Technologist is a science/manufacturing professional role - not a cook, chef, or food handler. Civil Engineer is a professional - not a construction worker. Never substitute a trade role for a professional title.
SECTOR SPREAD: For generic searches (e.g. Admin, Manager, Officer), spread across sectors. For specific professional titles, prioritise precision over diversity - return the correct professional role first, then related specialist roles.
PRECISION RULE applies first. Then:

CROSS-INDUSTRY ROLE RULE: The following role types exist in EVERY industry and must NEVER be assigned a single sector. This is an absolute rule with no exceptions.
Cross-industry terms: Apprentice, Trainee, Intern, Internship, Graduate, Student, Volunteer, Junior [any], Assistant [any], Trainer, Coach, Facilitator, Consultant, Analyst, Coordinator, Officer, Specialist.
MANDATORY behaviour for these terms: return multiple results each with a DIFFERENT real employing sector. Every result must have a distinct industry value. If all results share the same industry, that is always wrong.
- "Intern" must NOT all be filed under Government - return Intern across Healthcare, Finance, Technology, Marketing, Engineering, Legal etc.
- "Trainer" must NOT be filed under Education - return Corporate Trainer (Learning and Development), Safety Trainer (Manufacturing), Fitness Trainer (Sport and Wellness), Culinary Trainer (Hospitality), IT Trainer (Technology)
- "Trainee" must NOT all share one sector - return Trainee Accountant (Finance), Trainee Engineer (Engineering), Trainee Nurse (Healthcare), Trainee Chef (Hospitality)
- "Apprentice" must NOT be filed under Education - return Apprentice Electrician (Construction), Apprentice Chef (Hospitality), Apprentice Mechanic (Automotive)

Bad example: returning "Cook" or "Chef" for "Food Technologist" - wrong role category
Bad example: returning "Construction Worker" for "Civil Engineer" - confuses trade with profession
Bad example: all "Intern" results with industry "Government and Public Administration" - interns work everywhere
Bad example: "Trainer" with industry "Education" - trainers work in every sector
Bad example: multiple results all sharing the same industry for any cross-industry term
Good example: for "Food Technologist" return Food Technologist (ISCO 3133), Food Science Technician, Quality Control Technician - all science/technical roles
Good example: for "Admin" return healthcare admin, school admin, government admin, legal admin, construction admin - spread across sectors
Good example: for "Intern" return Marketing Intern (Marketing), Finance Intern (Finance), Engineering Intern (Engineering), Healthcare Intern (Healthcare), Legal Intern (Legal) - every result a different sector
Good example: for "Trainer" return Corporate Trainer (Learning and Development), Safety Trainer (Manufacturing and Safety), Fitness Trainer (Sport and Wellness), IT Trainer (Technology), Culinary Trainer (Hospitality)`;

  const raw = await claudeCall(
`Search term: ${keyword}
Return ${count} ESCO v1.2 occupations matching this term, ordered by relevance.
- The first result must be the closest semantic match to the exact search term - not a related but different role
- If the search term is a professional or technical title, return professional/technical roles - not trades or hands-on roles
- Spread across sectors only for generic terms; for specific titles prioritise precision
- If the search term is a cross-industry role (Apprentice, Trainee, Intern, Student, Graduate, Volunteer, Trainer, Coach, Coordinator), every result MUST have a different industry value - filing all results under one sector like Government, Education, or General is always wrong for these terms
- No invented occupations - only real ESCO v1.2 titles`, 2000, 1, SYSTEM_SEARCH);
  const arr = extractJSON(raw, "search");
  if (!Array.isArray(arr)) throw new Error("search: expected array");
  return arr.map(x => ({
    title:      (x.title || "").trim(),
    iscoCode:   x.iscoCode || "",
    iscoGroup:  x.iscoGroup || "",
    industry:   x.industry || x.iscoGroup || "Across industries",
    description:x.description || "",
    isAltLabel: x.isAltLabel || false,
  })).filter(x => x.title);
}

async function getSkills(title, group, iscoCode) {
  // 4A: ISCO-based skill target
  const firstDigit = parseInt((iscoCode || "0")[0], 10);
  let skillTarget = 25;
  if (firstDigit >= 4 && firstDigit <= 5) skillTarget = 18;
  if (firstDigit >= 6 && firstDigit <= 9) skillTarget = 14;

  const SYSTEM_SKILLS =
`You are a senior ESCO v1.2 skills taxonomy specialist. Your expertise is identifying the essential skills - technical and human - that define an occupation. You apply Singapore and ASEAN workforce context where relevant.
Return ONLY a JSON array. No text before or after. No markdown fences.
Format: [{"n":1,"skill":"Skill name under 7 words","type":"technical"}]
Field rules:
- n: sequential integer starting at 1
- skill: concise, specific to this occupation - not generic filler
- type: exactly "technical" or "soft-skill"
Thinking approach: Before listing skills, ask three questions for each candidate skill - (1) What specific task or decision does a practitioner in this role perform that requires this skill? (2) Could an AI tool be given a clear enough brief to perform this task? (3) Would a recruiter testing this person in an interview assess this specific capability? A skill name must be specific enough that a sophisticated AI prompt could be written around it. If a skill name is too broad to anchor a real prompt, it is too generic.
Quality rules:
- Include at least 4 skills that require human presence, judgment, or empathy
- Skill names must be specific enough to support a sophisticated AI prompt or a meaningful human development action. "Communication Skills" fails this test. "Client Objection Handling in Complex Sales" passes it.
- For technical skills: name the actual task or output, not the tool. "Excel" is not a skill. "Sales Pipeline Data Reconciliation" is.
- No duplicate skills or near-duplicates
- Only genuine ESCO v1.2 essential skills - never invent or pad
Bad example: "Communication Skills" for a Supply Chain Analyst - too generic, no prompt can be written around it
Bad example: "Microsoft Excel" for a Financial Analyst - names the tool, not the skill
Bad example: "Teamwork" for any role - not a discrete assessable capability
Good example: "Supplier Lead Time Variance Analysis" for a Supply Chain Analyst - specific, AI-promptable, interview-testable
Good example: "Financial Variance Reporting" for a Financial Analyst - names the task, not the tool
Good example: "Intraoperative Clinical Decision-Making" for a Surgeon - specific and genuinely human-led`;

  const raw = await claudeCall(
`Occupation: ${title}
ISCO group: ${group}
Return exactly ${skillTarget} essential ESCO v1.2 skills for this role. Cover both technical and soft-skill types. Ensure the list reflects what a practitioner in Singapore or ASEAN actually does in this role.`, 1200, 1, SYSTEM_SKILLS);
  const arr = extractJSON(raw, "skills");
  if (!Array.isArray(arr)) throw new Error("skills: expected array");
  return arr.map(x => ({
    n:    x.n || 0,
    skill:toTitleCase(x.skill || ""),
    type: x.type || "technical",
  })).filter(x => x.skill);
}

async function rateSkills(title, skills) {
  // Lean structural rating on Haiku - fast, fits within token limit
  const SYSTEM_RATE =
`You are a senior AI workforce analyst. Rate how AI affects each occupational skill. Apply Singapore and ASEAN context.
Return ONLY a JSON array with exactly the same number of items as skills provided. No text before or after. No markdown fences.
Format: [{"n":1,"l":"HIGH","a":"LLM","h":"how AI engages - 12 words max","k":"kickstart this week - 12 words max","st":"technical","pr":"","tw":false,"rd":"ready"}]
Automation levels:
- HIGH = Full Automation: AI performs autonomously with minimal human input
- MEDIUM = AI-Augmented: AI dramatically enhances speed or quality; human still directs
- LOW = AI-Assisted: AI supports but human judgment leads throughout
- HUMAN = Human-Led: presence, empathy, or physical action required - AI cannot meaningfully assist
AI tools (use exact code):
LLM=AI language tool, COPILOT=Microsoft Copilot, SEARCH=AI search tool, IMAGE=AI image tool, VOICE=AI voice tool, DATA=AI data analysis tool, AUTO=AI automation tool, CODE=AI coding tool, DOCS=AI document tool, SLIDES=AI presentation tool, VISION=AI vision tool, RESEARCH=AI research tool, VIDEO=AI video tool, NA=Not applicable
Field rules:
- h: calibrated to level. HIGH: name the technique e.g. "Automated via ReAct loop" or "Delegated using prompt chaining + reflexion". MEDIUM: describe human-AI split e.g. "Human sets criteria, AI uses tree-of-thoughts to evaluate options". LOW: frame AI as support e.g. "AI generates knowledge first; human applies judgment to decision". HUMAN: explain why e.g. "Requires physical presence and emotional attunement". No generic phrases.
- k: one specific achievable action this week. Do not name specific AI products.
- pr: if prompt needs real data first, start with "Have your..." or "Open your..." - else empty string
- tw: true only if multi-turn approach genuinely helps
- rd: "ready" if usable today, "prepare" if setup needed
OFFICE SUITE RULE: Microsoft Office, Excel, Word, PowerPoint, Spreadsheets = MEDIUM at most. Never HIGH.
CRITICAL: If a=NA then l MUST be HUMAN. No exceptions.
Bad example: "Patient Empathy" as LOW with LLM - must be HUMAN + NA
Good example: "Clinical Documentation" as MEDIUM with DOCS - AI drafts, clinician reviews`;

  const skillList = skills.map(s => `${s.n}:${s.skill}`).join(" | ");
  const raw = await claudeCall(
`Occupation: ${title}
Rate each skill for AI automation impact. Singapore and ASEAN context applies.
Skills to rate: ${skillList}`, 4500, 1, SYSTEM_RATE);
  const arr = extractJSON(raw, "ratings");
  if (!Array.isArray(arr)) throw new Error("ratings: expected array");
  const levelMap = { HIGH:"HIGH", MEDIUM:"MEDIUM", LOW:"LOW", HUMAN:"HUMAN" };
  return arr.map(x => {
    const tool = x.a || x.tool || "NA";
    const rawLevel = levelMap[x.l] || levelMap[x.level] || "HUMAN";
    const level = (tool === "NA" && rawLevel !== "HUMAN") ? "HUMAN" : rawLevel;
    return {
      n:         x.n,
      level,
      tool,
      how:       x.how || x.h || "",
      kickstart: x.kickstart || x.k || "",
      skillType: x.skillType || x.st || "technical",
      prep:      x.prep || x.pr || "",
      twoStep:   x.twoStep || x.tw || false,
      readiness: x.readiness || x.rd || "ready",
      prompt:    "",
      promptTech:"",
      nextPhase: "",
      promptLoading: false,
    };
  });
}

const PROMPT_BATCH_SIZE = 3;

// Technique taxonomy organised by automation level and skill type
// Used for deterministic pre-assignment before batching
const TECH_ASSIGN = {
  // HIGH (L9-12) - Full Automation skills
  HIGH: {
    technical:   ["agentic-task-spec","rag","prompt-chaining","react","reflexion","self-critique-loop","decomposition-scaffold","tree-of-thoughts","skeleton-of-thought","few-shot-anchor"],
    soft:        ["agentic-task-spec","prompt-chaining","react","reflexion","self-critique-loop","tree-of-thoughts","meta-prompting","few-shot-anchor","decomposition-scaffold","self-consistency"],
  },
  // MEDIUM (L7-8) - AI-Augmented skills
  MEDIUM: {
    technical:   ["tree-of-thoughts","decomposition-scaffold","reflexion","self-critique-loop","meta-prompting","self-consistency","react","least-to-most","output-contract","few-shot-anchor"],
    soft:        ["reflexion","self-critique-loop","meta-prompting","tree-of-thoughts","self-consistency","directional-stimulus","generate-knowledge","persona-injection","few-shot-anchor","least-to-most"],
  },
  // LOW (L4-6) - AI-Assisted skills
  LOW: {
    technical:   ["chain-of-thought","generate-knowledge","least-to-most","output-contract","skeleton-of-thought","few-shot-anchor","self-consistency","directional-stimulus","persona-injection","chain-of-thought"],
    soft:        ["directional-stimulus","generate-knowledge","persona-injection","chain-of-thought","output-contract","least-to-most","few-shot-anchor","skeleton-of-thought","self-consistency","directional-stimulus"],
  },
};

// Eligible roles for multimodal-cot (visual interpretation skills only)
const MULTIMODAL_ROLES = ["architect","radiologist","pathologist","civil engineer","quality inspector","ux researcher","fashion designer","interior designer","structural engineer","urban planner","graphic designer","industrial designer","cartographer","orthotist","prosthetist"];

// Session-level rotation tracker - ensures missing techniques appear in subsequent analyses
// Stored outside the function so it persists across multiple analyses in the same session
const _techRotation = { lastSkipped: [] };

function assignTechniques(actionable, occupationTitle) {
  const titleLower = occupationTitle.toLowerCase();
  const isVisualRole = MULTIMODAL_ROLES.some(r => titleLower.includes(r));

  // Build the full pool of 19 techniques in priority order by level
  const allTechs = [
    "agentic-task-spec","rag","prompt-chaining",           // L9-12 highest priority
    "react","reflexion","self-critique-loop",               // L7-8
    "tree-of-thoughts","decomposition-scaffold","meta-prompting","self-consistency", // L7-8
    "few-shot-anchor","output-contract","skeleton-of-thought","least-to-most",       // L5-6
    "chain-of-thought","generate-knowledge","directional-stimulus","persona-injection", // L3-4
    "multimodal-cot",                                       // conditional only
  ];

  // Start with techniques skipped in last analysis so they surface this time
  const priorityFirst = [..._techRotation.lastSkipped, ...allTechs.filter(t => !_techRotation.lastSkipped.includes(t))];

  const assigned = new Map(); // n -> technique code
  const usedInThisAnalysis = new Set();

  actionable.forEach(s => {
    const level = s.level; // HIGH / MEDIUM / LOW
    const sType = (s.skillType || "technical").toLowerCase().includes("soft") ? "soft" : "technical";
    const pool = TECH_ASSIGN[level]?.[sType] || TECH_ASSIGN[level]?.technical || [];

    // Check multimodal eligibility
    const canMultimodal = isVisualRole && sType === "technical";

    // Find the best unused technique from the pre-assignment pool
    // Fall back to priority-first global pool if pool is exhausted
    let chosen = null;
    for (const t of pool) {
      if (!usedInThisAnalysis.has(t) && (t !== "multimodal-cot" || canMultimodal)) {
        chosen = t; break;
      }
    }
    if (!chosen) {
      for (const t of priorityFirst) {
        if (!usedInThisAnalysis.has(t) && (t !== "multimodal-cot" || canMultimodal)) {
          chosen = t; break;
        }
      }
    }
    if (!chosen) chosen = pool[0] || "chain-of-thought"; // absolute fallback

    assigned.set(s.n, chosen);
    usedInThisAnalysis.add(chosen);
  });

  // Record which techniques were NOT used this analysis for next rotation
  _techRotation.lastSkipped = allTechs.filter(t => t !== "multimodal-cot" && !usedInThisAnalysis.has(t));

  return assigned;
}

async function generatePrompts(title, skills, ratedSkills, onBatch) {
  const actionable = ratedSkills.filter(s => s.level !== "HUMAN");
  if (actionable.length === 0) return [];

  // Pre-assign techniques deterministically before batching
  const techAssignment = assignTechniques(actionable, title);

  const SYSTEM_PROMPTS =
`You are a prompt engineering specialist. For each skill, write a sophisticated ready-to-use prompt using EXACTLY the technique code specified in the pt field of each input item. Do not choose a different technique - execute the assigned one.
Return ONLY a JSON array. No text before or after. No markdown fences.
Format: [{"n":1,"p":"full prompt text","pt":"SAME technique-code as assigned","nx":"next phase sentence"}]
Never name specific AI products inside p or nx - use "an AI language tool", "an AI automation tool" etc.
The pt field in your output MUST exactly match the technique code assigned in the input.

MULTIMODAL CoT RULE: Only write a multimodal-cot prompt when the skill genuinely involves interpreting images, diagrams, scans, blueprints, or visual data alongside text.

TECHNIQUE EXECUTION GUIDE - how to write each technique as a prompt:

persona-injection: Open with a specific expert identity (seniority + domain + years). Every sentence should reflect how that expert thinks. The persona shapes tone, vocabulary, and depth.
directional-stimulus: Embed a directing keyword or framing hint early that steers AI toward the right answer space without constraining output. The stimulus is subtle - a word, a framing, a perspective anchor.
chain-of-thought: Instruct AI to reason step by step, showing each reasoning stage before reaching a conclusion. Number the steps. Make the reasoning visible.
generate-knowledge: Ask AI to surface all relevant knowledge about the domain first, then apply that knowledge to the specific task. Two explicit phases: know, then do.
least-to-most: Break the problem into subproblems from simplest to most complex. Each subproblem must be solved before the next is attempted. Show the dependency chain explicitly.
output-contract: Specify exact output structure - field names, section headers, word count per section, format. Leave no ambiguity about what the output must look like.
skeleton-of-thought: Generate the full structural outline first (headings, key points, word targets per section). Review and confirm the skeleton. Then expand each section in full.
few-shot-anchor: Embed a complete worked example of ideal input and output before the actual task. The example calibrates AI to your quality standard.
multimodal-cot: Combine image/visual input with text and apply chain-of-thought reasoning across both modalities. Reference specific visual elements in the reasoning steps.
self-consistency: Run the same analytical task through three independent reasoning paths. Compare the conclusions. Select the most consistent answer and explain why it is more reliable.
meta-prompting: Before answering, describe what an excellent response looks like - its structure, depth, evaluation criteria. Then apply that standard to produce the response.
tree-of-thoughts: Explore 2-3 distinct reasoning branches before committing. For each branch: state the assumption, work through the logic, note where it might fail. Select the strongest branch and justify.
decomposition-scaffold: Break the task into numbered sub-steps. Execute each step in order. Show the output of each step before proceeding. The scaffold is visible in the prompt.
reflexion: Generate the initial output. Then reflect explicitly on what was weak, incomplete, or missing. Produce an improved version addressing each identified gap.
self-critique-loop: Generate output. Evaluate it against 3 named quality criteria. Identify the weakest point. Revise specifically to address it. Deliver the revised version.
react: Alternate Reason and Act cycles. Reason: what do I know and what do I need? Act: retrieve or calculate. Reason: what does this tell me? Act: update. Continue until no unresolved questions remain.
prompt-chaining: Structure the prompt as two linked stages. Stage 1 produces an intermediate output. Stage 2 takes that output as input and produces the final deliverable. Label both stages clearly.
rag: Specify the retrieval source material the user must paste in. AI reads only that material, cites specific sections for every claim, and states what is missing if the material is insufficient.
agentic-task-spec: Write a full autonomous brief: objective, available inputs, decision rules for each scenario, output format, verification step, and escalation condition if the output fails verification. Designed to run without human initiation per cycle.

WORKED EXAMPLES AT L9-12:

agentic-task-spec example (HIGH, automated workflow skill): "You are a senior [role] operating autonomously. Objective: [state the automated task]. Inputs available: [list data sources or files]. Decision rules: If [condition A] then [action A]. If [condition B] then [action B]. If neither condition applies, flag for human review. Output format: [specify exact format]. Verification: before delivering output, confirm all required fields are populated and no rule was skipped. Escalation: if output confidence is below threshold or a rule conflict is detected, pause and surface the conflict with a recommended resolution. Execute now using the inputs provided."

rag example (HIGH, knowledge/compliance skill): "You are a specialist [role]. I will provide the source material below. Read it in full before answering. Rules: cite the specific section, clause, or paragraph for every claim you make. Do not use knowledge from outside the provided material. If the material does not contain enough information to answer fully, list exactly what is missing and why it matters. Format your answer as: Finding | Source Reference | Confidence (High / Medium / Low - based on how explicitly the source addresses the point). Source material: [paste document, policy, or data extract here]. Question: [your specific question]."

prompt-chaining example (HIGH, multi-stage analytical skill): "Stage 1 - Analysis: You are a senior [role]. Analyse the following situation and produce a structured diagnostic: [describe situation]. Output: a numbered list of root causes, each with supporting evidence and estimated impact level. --- Stage 2 - Recommendation: Taking the diagnostic output from Stage 1 as your input, produce a prioritised action plan. For each action: state the objective, the specific steps, the owner, and the success metric. Do not repeat the diagnostic. Build directly on it."

WORD TARGETS - the prompt text must fall within these ranges:
For l=HIGH (280-440 words): Show the full technique structure explicitly - tool-use chains, retrieval sources, decision rules, verification steps, multi-stage scaffolds. Include: expert persona + full technique structure + output contract + 2 hard constraints + verification or escalation step.
For l=MEDIUM (180-280 words): Show the technique structure clearly. Include: expert persona + technique structure shown explicitly + output contract + technique applied with visible steps.
For l=LOW (100-160 words): Embed the technique clearly. Include: expert persona + technique applied + output contract + one constraint.

NX FIELD - plain language, no jargon, no technical terms:
For l=HIGH: 1-2 sentences describing what fully automated execution of this skill looks like - written for someone who has never used AI automation before. Example: "Once you are comfortable with this prompt, you can schedule it to run automatically every Monday morning so the report lands in your inbox before your team arrives." Start with "Next phase:"
For l=MEDIUM: 1-2 sentences describing the next step toward more automation on this skill. No jargon. Start with "Next phase:"
For l=LOW: 1 sentence describing the simplest next step. No jargon. Start with "Next phase:"`;

  // Build batches with pre-assigned techniques injected into each skill entry
  const batches = [];
  for (let i = 0; i < actionable.length; i += PROMPT_BATCH_SIZE) {
    batches.push(actionable.slice(i, i + PROMPT_BATCH_SIZE));
  }

  const allResults = [];

  await Promise.allSettled(batches.map(async (batch) => {
    const batchMsg =
`Occupation: ${title}
Write prompts for these skills. The technique (pt) is pre-assigned - use EXACTLY the technique specified for each skill. Format: n:level:skillType:ASSIGNED_TECHNIQUE:skillName
${batch.map(s => {
  const sk = skills.find(sk => sk.n === s.n);
  const assignedTech = techAssignment.get(s.n) || "chain-of-thought";
  return `${s.n}:${s.level}:${s.skillType||"technical"}:${assignedTech}:${sk?.skill || ""}`;
}).join(" | ")}
Return pt exactly as assigned above. Do not substitute a different technique.`;

    try {
      const raw = await claudeCall(batchMsg, 3100, 1, SYSTEM_PROMPTS, "claude-sonnet-4-6");
      const arr = extractJSON(raw, "prompts-batch");
      if (Array.isArray(arr)) {
        allResults.push(...arr);
        if (onBatch) onBatch(arr);
      }
    } catch(e) {
      console.warn("[generatePrompts] batch failed for skills", batch.map(s => s.n).join(","), e.message);
    }
  }));

  return allResults;
}
// Compact rating for comparison runs - skips prompt/prep/twoStep/readiness to reduce tokens and latency
async function rateSkillsCompact(title, skills) {
  const SYSTEM_COMPACT =
`You are a senior AI workforce analyst. Rate how AI affects each occupational skill. Apply Singapore and ASEAN context.
Return ONLY a JSON array with exactly the same number of items as skills provided. No text before or after.
Format: [{"n":1,"l":"HIGH","a":"LLM","h":"how AI helps under 8 words","st":"technical"}]
Automation levels: HIGH=Full Automation, MEDIUM=AI-Augmented, LOW=AI-Assisted, HUMAN=Human-Led
AI tools: LLM, COPILOT, SEARCH, IMAGE, VOICE, DATA, AUTO, CODE, DOCS, SLIDES, VISION, RESEARCH, VIDEO, NA
CRITICAL: If a=NA then l MUST be HUMAN. Physical, tactile, and face-to-face skills are always HUMAN + NA.
OFFICE SUITE RULE: Skills named "Microsoft Office", "Office Suite", "Spreadsheets", "Excel", "Word", "PowerPoint" or similar general productivity suite skills must be rated MEDIUM at most - never HIGH.`;

  const skillList = skills.map(s => `${s.n}:${s.skill}`).join(" | ");
  const raw = await claudeCall(
`Occupation: ${title}
Skills to rate: ${skillList}`, 2800, 2, SYSTEM_COMPACT);
  const arr = extractJSON(raw, "compact-ratings");
  if (!Array.isArray(arr)) throw new Error("compact-ratings: expected array");
  const levelMap = { HIGH:"HIGH", MEDIUM:"MEDIUM", LOW:"LOW", HUMAN:"HUMAN" };
  return arr.map(x => {
    const tool = x.a || "NA";
    const rawLevel = levelMap[x.l] || "HUMAN";
    const level = (tool === "NA" && rawLevel !== "HUMAN") ? "HUMAN" : rawLevel;
    return { n:x.n, level, tool, how:x.h||"", skillType:x.st||"technical",
             kickstart:"", prompt:"", prep:"", twoStep:false, readiness:"ready" };
  });
}

const LEVELS = {
  HIGH:  { label:"Full Automation", color:"#dc2626", bg:"#fef2f2", border:"#fecaca", icon:"⚡" },
  MEDIUM:{ label:"AI-Augmented",    color:"#d97706", bg:"#fffbeb", border:"#fcd9a0", icon:"~"  },
  LOW:   { label:"AI-Assisted",     color:"#2563eb", bg:"#eff6ff", border:"#bfdbfe", icon:"●"  },
  HUMAN: { label:"Human-Led",       color:"#166534", bg:"#f0fdf4", border:"#a7f3d0", icon:"♦"  },
};

const PERSONA_CONFIG = {
  fresh: {
    label:   "Fresh Graduate",
    icon:    "🎓",
    color:   "#166534",
    bg:      "#ecfdf5",
    border:  "#a7f3d0",
    context: "a fresh graduate with no prior work experience entering this field for the first time",
    horizon: "first 12 months of employment and beyond",
  },
  crossover: {
    label:   "Industry Crossover",
    icon:    "🔄",
    color:   "#7c3aed",
    bg:      "#f3e8ff",
    border:  "#ddd6fe",
    context: "an adult professional changing industries with transferable skills from a different field",
    horizon: "first 12 months of transition into this new field and beyond",
  },
};

const AI_USAGE = {
  LLM:       "AI language tool",
  COPILOT:   "Microsoft Copilot",
  SEARCH:    "AI search tool",
  IMAGE:     "AI image tool",
  VOICE:     "AI voice tool",
  DATA:      "AI data analysis tool",
  AUTO:      "AI automation tool",
  CODE:      "AI coding tool",
  DOCS:      "AI document tool",
  SLIDES:    "AI presentation tool",
  VISION:    "AI vision tool",
  RESEARCH:  "AI research tool",
  VIDEO:     "AI video tool",
  NA:        "No direct AI tool applicable at this time",
};

function toTitleCase(str) {
  if (!str) return "";
  const mixedCase = new Set(["MLOps","DevOps","DataOps","GitOps","SecOps","FinOps","AIOps","CloudOps","NetOps",
    "ChatGPT","GitHub","LinkedIn","WordPress","JavaScript","TypeScript","PowerPoint","HubSpot",
    "iPhone","iPad","macOS","iOS","OpenAI","MongoDB","PostgreSQL","MySQL","LaTeX",
    "PyTorch","TensorFlow","AutoCAD","QuickBooks","Salesforce","ServiceNow",
    "eCommerce","eLearning","eHealth","mHealth","fintech","RegTech","InsurTech","PropTech"]);
  const acronyms = new Set([
    // C-suite and leadership
    "CEO","CFO","COO","CTO","CMO","CHRO","CPO","CDO","CIO","CCO","CLO","CSO","CRO","CISO",
    "VP","SVP","EVP","AVP","MD","GM","GP","DGM",
    // HR and people
    "HR","HRM","HRD","HRBP","L&D","OD","TA",
    // Technology
    "IT","ICT","AI","ML","NLP","LLM","RPA","API","SQL","ETL","BI","ERP","CRM","SaaS","PaaS","IaaS",
    "ERP","MRP","SCM","WMS","TMS","LMS","HRIS","HRMS","ATS","CMS","DAM","CDP","DMP","MDM",
    "IoT","AR","VR","XR","UI","UX","UCD","SEO","SEM","PPC","CRO","A/B",
    "TV","POS","ATM","GPS","SMS","MMS","URL","USB","PDF","XML","JSON","HTML","CSS",
    // Finance and business
    "P&L","ROI","ROE","ROA","EBITDA","EBIT","NPV","IRR","DCF","WACC","KPI","OKR","SLA","NPS",
    "B2B","B2C","D2C","SME","SMB","MNC","IPO","M&A","PE","VC","LBO","MBO",
    "IFRS","GAAP","FASB","IASB","FRS","SSAP","IPSAS","XBRL","GST","VAT","WHT","MAS","SGX",
    // Operations and supply chain
    "FMCG","SKU","PO","SO","GRN","3PL","4PL","DC","WH","MOQ","EOQ","COGS","BOM","MPS","MRP",
    "SOP","SOW","RFP","RFQ","RFI","NDA","MSA","SLA","OLA","KPI","OTIF","DIFOT",
    // Professional and regulatory
    "NGO","NPO","IGO","UN","EU","ASEAN","MOU","MOA","AGM","EGM","AGM",
    "ISO","GDPR","PDPA","SOX","HIPAA","PCI","AML","KYC","ESG","CSR","GRI","SDG",
    // Healthcare
    "GP","A&E","ICU","CCU","ED","OT","OPD","IPD","GP","PHC","IHC",
    // Education
    "K12","STEM","STEAM","MBA","MBA","PhD","BSc","MSc","BA","MA","BEng","MEng",
    // Marketing and comms
    "PR","IR","GR","CSR","ATL","BTL","TTL","OOH","CTA","CTR","CPM","CPC","CPL","CAC","LTV","CLV",
    // Media, broadcast, entertainment
    "VFX","CGI","CG","3D","2D","HD","4K","8K","UHD","FPS","DJ","MC","FM","AM","EP","PR",
    // Project and quality
    "PM","PMO","PMP","PRINCE2","SCRUM","AGILE","LEAN","SIX","TQM","QA","QC","ISO",
  ]);
  const lowercase = new Set(["of","and","the","in","at","for","to","with","a","an","by","or","nor","but","from","on","into","as","via","per","vs"]);
  return str.trim().replace(/\b\w+/g, (w, offset, full) => {
    if (mixedCase.has(w)) return w;
    const up = w.toUpperCase();
    if (acronyms.has(up)) return up;
    // Keep connectors lowercase unless they are the first word
    if (lowercase.has(w.toLowerCase()) && offset > 0) return w.toLowerCase();
    return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
  });
}

function skillsMatch(a, b) {
  if (a === b) return true;
  const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, "");
  const na = norm(a), nb = norm(b);
  if (na === nb) return true;
  if (na.length > 5 && nb.length > 5) {
    if (na.startsWith(nb.slice(0,6)) || nb.startsWith(na.slice(0,6))) return true;
    const wa = na.split(/\s+/), wb = nb.split(/\s+/);
    const shared = wa.filter(w => wb.some(x => x.startsWith(w.slice(0,5)) || w.startsWith(x.slice(0,5))));
    if (shared.length >= Math.min(wa.length, wb.length) * 0.6) return true;
  }
  return false;
}

function track(event, props) {
  try { window._vtrack && window._vtrack(event, props); } catch(_) {}
}

async function getFoundationSkills(title, skills, persona) {
  const cfg = PERSONA_CONFIG[persona];
  const skillList = skills.map(s => `${s.n}:${s.skill}(${s.level},${s.tool})`).join(" | ");
  const SYSTEM_FOUND =
`You are a workforce readiness specialist with expertise in human skills development and AI transition planning. Your role is to identify the foundation skills that will keep a person relevant and employable as AI reshapes their occupation. You apply Singapore and ASEAN context - SkillsFuture frameworks, WSQ competencies, and local employer expectations inform your recommendations where relevant.
Return ONLY a JSON object. No text before or after. No markdown fences.
Format:
{
  "summary": "One sentence framing for this persona under 15 words",
  "foundations": [
    {
      "n": 1,
      "skill": "Foundation skill name under 7 words",
      "category": "one of: Critical Thinking | Communication | Ethical Judgment | Adaptability | Domain Knowledge | Collaboration | AI Literacy",
      "why": "Why AI cannot replace this for this persona under 12 words",
      "action": "One concrete learning action to build this skill under 10 words",
      "priority": "one of: Must-Have | High | Develop"
    }
  ]
}
Priority meaning:
- Must-Have: critical from day one - without this the person cannot perform in the role
- High: important within the first 12 months - builds competitive advantage early
- Develop: build progressively over time - deepens long-term resilience
Rules:
- foundations: exactly 8 items
- No double-quote characters inside any string value
- Each skill must be genuinely AI-resistant - not just soft or vague
- action must be specific enough to do this week, not just "read about it"
Bad example action: "Learn about communication" - too vague
Good example action: "Run a mock difficult conversation with a colleague and ask for feedback"`;

  const raw = await claudeCall(
`Occupation: ${title}
Persona: ${cfg.context}
Time horizon: ${cfg.horizon}
Existing skill automation ratings: ${skillList}
Identify exactly 8 foundation skills that will remain human-essential and AI-resistant for this persona over the next 12 months and beyond. Prioritise skills that are realistic to build given the persona context - a fresh graduate needs different foundations than an industry crossover professional.`, 900, 1, SYSTEM_FOUND);
  const obj = extractJSON(raw, "foundations");
  if (Array.isArray(obj)) throw new Error("foundations: expected object");
  return {
    summary:     obj.summary || "",
    foundations: (obj.foundations||[]).map(x => ({ n:x.n, skill:toTitleCase(x.skill||""), category:x.category||"", why:x.why||"", action:x.action||"", priority:x.priority||"Develop" })),
  };
}

async function getProgressionPaths(title, iscoGroup) {
  const SYSTEM_PROG =
`You are a senior career development adviser with deep knowledge of occupational pathways in Singapore and the ASEAN region. You understand how careers actually progress in organisations - not just what looks good on paper, but what is realistic given market structures, typical promotion timelines, and skill adjacencies.
Return ONLY a JSON array. No text before or after. No markdown fences.
Format: [{"r":"Role Title","dir":"up","note":"One line on what changes or grows","gap":["Skill 1","Skill 2","Skill 3","Skill 4"],"step":""}]
Direction codes:
- up: clear promotion or seniority increase - more responsibility, more people, or larger scope
- lateral: same seniority level, different function or specialisation - a pivot not a step up
- specialist: deeper technical or domain expertise - becoming the go-to expert rather than a manager
gap: exactly 4 skills this person would need to develop - new capabilities not already in the current role
step: for dir=up only - if the skill gap is large, name one realistic intermediate role as a stepping stone. Otherwise empty string.
Thinking approach: Before listing roles, consider - what do people in this role typically move into after 2 to 3 years? What does the hiring market in Singapore recognise as a natural next step? What specialist niches exist in this field?
Quality rules:
- Return exactly 6 items: at least 2 up, at least 1 lateral, at least 1 specialist
- Do not include the current role itself
- Roles must be realistic in Singapore and ASEAN - not US-specific titles or structures
- Keep all string values under 10 words. No quote characters inside string values.
Bad example: listing "VP of Everything" as an up path for a junior analyst - too large a jump
Good example: listing "Senior Analyst" then "Analytics Manager" as sequential up paths with a step between them`;

  const raw = await claudeCall(
`Current role: ${title}
ISCO group: ${iscoGroup||"general"}
Return exactly 6 realistic career progression paths for this role in Singapore and ASEAN context. Cover a genuine mix of promotion, lateral move, and specialist directions.`, 800, 1, SYSTEM_PROG);
  const arr = extractJSON(raw, "progression");
  if (!Array.isArray(arr)) throw new Error("Progression: expected array");
  return arr.map(x => ({ role:toTitleCase(x.r||x.role||""), dir:x.dir||"up", note:x.note||"", gap:(x.gap||[]).map(g => toTitleCase(g)), step:x.step ? toTitleCase(x.step) : "" }));
}

async function getCrossoverRoles(title, skills) {
  const topSkills = skills.slice(0,6).map(s => s.skill).join(", ");

  const SYSTEM_CROSS =
`You are a career transition specialist who helps working adults pivot into new sectors without starting from scratch. You identify roles in different industries where a person's existing skills transfer directly - giving them a credible entry point rather than a complete restart. You apply Singapore and ASEAN labour market context.
Return ONLY a JSON array. No text before or after. No markdown fences.
Format: [{"r":"Role Title","sector":"Industry or sector","bridge":"Key shared skill under 6 words","new":["New skill 1","New skill 2","New skill 3"]}]
Field rules:
- r: a real job title someone would search on MyCareersFuture or LinkedIn Singapore
- sector: plain English industry sector
- bridge: the single most transferable skill that makes this crossover credible
- new: exactly 2 to 3 skills the person would need to develop - genuine gaps, not just variations of what they already have
Thinking approach: For each crossover role, ask - could a recruiter in Singapore be persuaded to consider this person based on their transferable skills alone? If yes, it is a credible crossover.
Quality rules:
- Return exactly 5 items from genuinely different sectors - do not cluster in adjacent industries
- Each role must be a realistic pivot - not a stretch too far, not a trivial rename
- Keep all string values under 10 words. No quote characters inside string values.
Bad example: suggesting "Senior [Same Job Title]" as a crossover - that is progression not crossover
Good example: suggesting "Training Coordinator" as a crossover for an Operations Supervisor - shared facilitation and process skills, new L&D knowledge required`;

  const raw = await claudeCall(
`Current role: ${title}
Core transferable skills: ${topSkills}
Return exactly 5 crossover roles in different sectors where these skills transfer directly. Apply Singapore and ASEAN context - use job titles and sectors that are active in this market.`, 600, 1, SYSTEM_CROSS);
  const arr = extractJSON(raw, "crossover");
  if (!Array.isArray(arr)) throw new Error("Crossover: expected array");
  return arr.map(x => ({ role:toTitleCase(x.r||x.role||""), sector:x.sector||"", bridge:x.bridge||"", newSkills:(x.new||x.newSkills||[]).map(s => toTitleCase(s)) }));
}


async function getSkillExperts(skillName, currentRole) {
  const SYSTEM_EXPERTS =
`You are a labour market intelligence analyst who understands which occupations are defined by specific skills - not just roles that use a skill incidentally, but roles where it is a primary capability. You apply Singapore and ASEAN labour market context.
Return ONLY a JSON array. No text before or after. No markdown fences.
Format: [{"r":"Role Title","sector":"Industry or sector","why":"One line why this skill is central here under 10 words"}]
Rules:
- Return exactly 5 roles
- Each role must be from a different sector
- The skill must be a defining capability of the role - not peripheral
- Use job titles that appear on MyCareersFuture or LinkedIn Singapore
- Do not return the current role
- Keep all string values under 12 words. No quote characters inside values.`;

  const raw = await claudeCall(
`Skill: ${skillName}
Current role to exclude: ${currentRole}
Find 5 occupations where "${skillName}" is a primary defining capability, not just incidental. Apply Singapore and ASEAN context.`, 400, 1, SYSTEM_EXPERTS);
  const arr = extractJSON(raw, "experts");
  if (!Array.isArray(arr)) return [];
  return arr.map(x => ({
    role: toTitleCase(x.r || x.role || ""),
    sector: x.sector || "",
    why: x.why || "",
  })).filter(x => x.role).slice(0, 5);
}

async function getComparisonSummary(roles) {
  const rolesDesc = roles.map(r =>
    `${r.title}: ${r.humanLed} Human-Led skills, ${r.highCount} Full Automation skills, shared: ${r.sharedSkills.join(", ")||"none"}, development gaps: ${r.gapSkills.join(", ")||"none"}, unique: ${r.uniqueSkills.join(", ")||"none"}`
  ).join("\n");
  const SYSTEM_COMP =
`You are a thoughtful career reflection partner - like a senior colleague who has seen many career decisions and knows how to share an observation without telling someone what to do. Your tone is warm, humble, and specific to the data in front of you. You never prescribe. You invite reflection.
Return ONLY a JSON object. No text before or after. No markdown fences.
Format:
{
  "observation": "One paragraph of 2 to 3 sentences on what stands out across these roles - patterns, differences, or something worth noticing. Humble and specific to the data provided.",
  "nextstep": "One sentence suggesting a concrete next step grounded in the data. Frame as an invitation. Start with: If... or One approach worth considering... or It might be worth...",
  "warning": "One honest observation only if the data genuinely warrants it - e.g. all roles have high automation exposure, or one role has a significantly larger skill gap. Leave as empty string if nothing stands out."
}
Tone rules:
- Use hedging phrases: it appears, you might find, one thing worth reflecting on, the data suggests
- Never use: you should, you must, the best choice is, clearly, obviously
- Be specific to the actual skill data - do not give generic career advice
- Keep all values under 60 words each. No quote characters inside string values.
Bad example observation: "These are all great roles with good career prospects" - generic, not data-specific
Good example observation: "It appears the two analyst roles share a similar automation exposure, while the management role shows notably more Human-Led skills - which may reflect the shift toward people coordination that comes with seniority"`;

  const raw = await claudeCall(
`Roles being compared:
${rolesDesc}

Write a reflection on what stands out across these roles based only on the data provided. Do not invent information not in the data.`, 400, 1, SYSTEM_COMP);
  const obj = extractJSON(raw, "summary");
  if (!obj) return { observation: raw.trim(), nextstep: "", warning: "" };
  return {
    observation: obj.observation || "",
    nextstep: obj.nextstep || "",
    warning: obj.warning || "",
  };
}

async function getRoleContext(title, skills, iscoGroup) {
  const skillList = skills.map(s => `${s.n}:${s.skill}`).join(" | ");

  const SYSTEM_CTX =
`You are a labour market intelligence analyst specialising in how occupations operate across different industries and organisational contexts. You understand where roles are commonly found, how the same job title functions differently depending on sector, and what department structures typically look like in Singapore and ASEAN organisations.
Return ONLY a JSON object. No text before or after. No markdown fences.
Format:
{
  "sectors": [
    {"name":"Sector name","note":"One line on how this role operates in this sector under 12 words","skills":[1,3,5]}
  ],
  "department": "typically sits within [specific function 1] or [specific function 2] - e.g. Finance and FP&A, or HR and Organisational Development"
}
Field rules:
- sectors: return 5 to 6 sectors where this role genuinely exists and is commonly hired
- name: plain English sector name - not jargon
- note: specific to how this role operates in this sector - not generic
- skills: array of skill n numbers most relevant to this sector - minimum 3, include all that apply
- department: specific functional department name as it would appear on an org chart in Singapore - not vague
Thinking approach: For each sector, ask - would a recruiter in this sector recognise and hire this role? What would the day-to-day look like differently here compared to another sector?
Quality rules:
- Do not repeat the same sector under different names
- Each sector must genuinely employ this role - not a stretch
- Keep all string values concise. No quote characters inside string values.
Bad example note: "Works in this sector" - too vague
Good example note: "Manages compliance documentation and audit trails for financial products"`;

  const raw = await claudeCall(
`Role: ${title}
ISCO group: ${iscoGroup||"general"}
Skills (referenced by number): ${skillList}
Identify 5 to 6 sectors where this role is commonly found in Singapore and ASEAN. For each sector, map which skills from the list are most relevant to how this role operates there.`, 800, 1, SYSTEM_CTX);
  const obj = extractJSON(raw, "context");
  if (!obj || !Array.isArray(obj.sectors)) throw new Error("Context: invalid response");
  return {
    sectors: obj.sectors.map(s => ({
      name: toTitleCase(s.name||""),
      note: s.note||"",
      skills: Array.isArray(s.skills) ? s.skills : []
    })),
    department: obj.department||""
  };
}

function Tag({ level, small }) {
  const c = LEVELS[level] || LEVELS.HUMAN;
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:3, padding:small?"2px 7px":"3px 9px", borderRadius:20, fontSize:small?10:11, fontWeight:700, color:c.color, background:c.bg, border:`1px solid ${c.border}`, whiteSpace:"nowrap", flexShrink:0 }}>
      {c.icon} {c.label}
    </span>
  );
}

function Spinner({ label, step, total }) {
  return (
    <div style={{ textAlign:"center", padding:"48px 0" }}>
      <div style={{ width:36, height:36, margin:"0 auto 14px", border:`3px solid ${C.border}`, borderTop:`3px solid ${C.accent}`, borderRadius:"50%", animation:"sp 0.7s linear infinite" }} />
      <style>{`@keyframes sp{to{transform:rotate(360deg)}} @keyframes slideUp{from{opacity:0;transform:translateX(-50%) translateY(16px)}to{opacity:1;transform:translateX(-50%) translateY(0)}} @keyframes fadeInUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}`}</style>
      <p style={{ color:C.text, fontSize:13, margin:"0 0 4px", fontWeight:600 }}>{label}</p>
      <p style={{ color:C.muted, fontSize:11, margin:"0 0 8px", lineHeight:1.5 }}>Your full skills breakdown and career paths are on the way.</p>
      {step && total && (
        <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, marginTop:4 }}>
          <div style={{ display:"flex", gap:4 }}>
            {Array.from({length:total}).map((_,i) => (
              <div key={i} style={{ width:8, height:8, borderRadius:"50%", background: i < step ? C.accent : C.border, transition:"background 0.3s" }} />
            ))}
          </div>
          <span style={{ fontSize:11, color:C.muted }}>{step} of {total}</span>
        </div>
      )}
    </div>
  );
}

function FeedbackLink() {
  return (
    <a href="mailto:feedback@takearoundabout.com?subject=Feedback - AI Skills Analyser"
      style={{ display:"inline-flex", alignItems:"center", gap:5, fontSize:11, color:C.teal, fontWeight:600, textDecoration:"none", background:C.tealBg, border:`1px solid ${C.tealBdr}`, borderRadius:20, padding:"5px 12px", marginTop:10 }}>
      ✉ feedback@takearoundabout.com
    </a>
  );
}

function ErrBox({ msg, query }) {
  const isNotFound = msg && msg.toLowerCase().includes("no occup");
  const isInvalid  = msg && msg.toLowerCase().includes("does not look like");
  const isTooLong  = msg && msg.toLowerCase().includes("too long");
  const isBusy     = msg && (msg.toLowerCase().includes("busy day") || msg.toLowerCase().includes("reached our limit"));
  const isOverload = msg && msg.toLowerCase().includes("overwhelmed");
  const isDowntime = !isNotFound && !isInvalid && !isTooLong && !isBusy && !isOverload && msg?.toLowerCase().includes("went wrong");

  if (isBusy) {
    return (
      <div style={{ background:"#f0fdf4", border:"1px solid #a7f3d0", borderRadius:8, padding:"12px 16px", marginBottom:12 }}>
        <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:600, color:C.green }}>The analyser has had a wonderful day</p>
        <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.75 }}>
          So many searches today that it has reached its daily limit - which is a good thing, really. It resets overnight, so please do come back tomorrow. Thank you for your patience and interest - it genuinely means a lot.
        </p>
      </div>
    );
  }

  if (isOverload) {
    return (
      <div style={{ background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:8, padding:"12px 16px", marginBottom:12 }}>
        <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:600, color:C.amber }}>The analyser is catching its breath</p>
        <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.75 }}>
          A few too many requests at once - please give it a minute and try again. It should be back with you shortly.
        </p>
      </div>
    );
  }

  if (isDowntime) {
    return (
      <div style={{ background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:8, padding:"12px 16px", marginBottom:12 }}>
        <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:600, color:C.amber }}>Something unexpected happened</p>
        <p style={{ margin:"0 0 4px", fontSize:12, color:C.textSub, lineHeight:1.75 }}>
          Apologies for the inconvenience. Please try again in a moment - this is usually a brief hiccup. If it keeps happening, we would genuinely appreciate a note so we can look into it.
        </p>
        <FeedbackLink />
      </div>
    );
  }

  if (isNotFound) {
    return (
      <div style={{ background:"#fdecea", border:"1px solid #f5c6c2", borderRadius:8, padding:"12px 16px", marginBottom:12 }}>
        <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:600, color:"#c0392b" }}>
          No match found for "{query}"
        </p>
        <p style={{ margin:"0 0 8px", fontSize:12, color:"#78350f", lineHeight:1.65 }}>A few things that often help:</p>
        <ul style={{ margin:"0 0 4px", paddingLeft:18, fontSize:12, color:"#78350f", lineHeight:1.8 }}>
          <li>Check the spelling - e.g. <em>Physician</em> not <em>Physicain</em></li>
          <li>Use a shorter title - e.g. <em>Manager</em> instead of <em>Senior HR Business Partner</em></li>
          <li>Try a more common job title - e.g. <em>Nurse</em> instead of <em>Ward Sister</em></li>
          <li>Use 1 to 3 words only</li>
        </ul>
      </div>
    );
  }

  if (isInvalid || isTooLong) {
    return (
      <div style={{ background:"#fdecea", border:"1px solid #f5c6c2", borderRadius:8, padding:"12px 16px", marginBottom:12 }}>
        <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:600, color:"#c0392b" }}>
          {isTooLong ? "That job title is a little long" : "That does not quite look like a job title"}
        </p>
        <p style={{ margin:0, fontSize:12, color:"#78350f", lineHeight:1.65 }}>
          {isTooLong
            ? "Please keep it to 1 to 3 words and under 140 characters - e.g. HR Manager, Nurse, Chief Executive Officer."
            : "Please enter a role such as HR Manager, Nurse, or Software Developer. Avoid symbols or special characters."
          }
        </p>
      </div>
    );
  }

  // Generic fallback - always show actual error for diagnosing
  return (
    <div style={{ background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:8, padding:"12px 16px", marginBottom:12 }}>
      <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:600, color:C.amber }}>Something went wrong</p>
      <p style={{ margin:"0 0 6px", fontSize:12, color:C.textSub, lineHeight:1.65 }}>
        Please try again in a moment. If it keeps happening, we would appreciate a quick note.
      </p>
      {msg && <p style={{ margin:"0 0 6px", fontSize:10, color:C.muted, fontFamily:"monospace", wordBreak:"break-all" }}>{msg}</p>}
      <FeedbackLink />
    </div>
  );
}

function Tab({ label, active, onClick, colour }) {
  return (
    <button onClick={onClick} className="tab-label" style={{ padding:"8px 13px", fontSize:13, fontWeight:700, cursor:"pointer", border:"none", borderBottom:`3px solid ${active ? colour : "transparent"}`, background:"transparent", color:active ? colour : C.muted, transition:"colour 0.15s", whiteSpace:"nowrap" }}>
      {label}
    </button>
  );
}

// ── Intro screen ──────────────────────────────────────────────────────────────
const AUDIENCE = [
  { icon:"🏢", label:"Leaders",            line:"Map AI exposure across roles. Compare up to 3 roles side by side.", persona:null },
  { icon:"👤", label:"Employees",          line:"See which skills AI is reshaping in a role, with prompts for each skill and a view of career progression.", persona:null },
  { icon:"🎓", label:"Fresh Graduates",    line:"Find out which skills in a field remain human, with a foundation plan.", persona:"fresh" },
  { icon:"🔄", label:"Industry Crossover", line:"See which skills carry across to a new field, with a foundation plan.", persona:"crossover" },
];

function IntroCard({ onPersonaSelect, toggleRef }) {
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ padding:"10px 4px 8px" }}>
        <p className="t-heading" style={{ margin:0, fontSize:17, color:C.text, fontWeight:800, lineHeight:1.3, letterSpacing:"-0.01em" }}>Explore how AI fits into role skills - and where humans still lead.</p>
      </div>
      <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"14px 18px", marginBottom:0 }}>
        <p style={{ margin:"0 0 10px", fontSize:12, fontWeight:600, color:C.muted, letterSpacing:"0.03em", textTransform:"uppercase" }}>
          Who is this most useful for?
        </p>
        <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
          {AUDIENCE.map((a, i) => {
            const clickable = !!a.persona;
            return (
              <div key={i}
                onClick={clickable ? () => {
                  onPersonaSelect(a.persona);
                  setTimeout(() => toggleRef.current?.scrollIntoView({ behavior:"smooth", block:"center" }), 50);
                } : undefined}
                style={{ display:"flex", alignItems:"flex-start", gap:10, padding:"7px 10px", borderRadius:7, border: clickable ? `1px solid ${C.border}` : "none", background: clickable ? C.bg : "transparent", cursor: clickable ? "pointer" : "default", transition:"border-color 0.15s, background 0.15s" }}
                onMouseEnter={clickable ? e => { e.currentTarget.style.borderColor = a.persona === "fresh" ? PERSONA_CONFIG.fresh.border : PERSONA_CONFIG.crossover.border; e.currentTarget.style.background = a.persona === "fresh" ? PERSONA_CONFIG.fresh.bg : PERSONA_CONFIG.crossover.bg; } : undefined}
                onMouseLeave={clickable ? e => { e.currentTarget.style.borderColor = C.border; e.currentTarget.style.background = C.bg; } : undefined}
              >
                <span style={{ fontSize:15, flexShrink:0, marginTop:1 }}>{a.icon}</span>
                <div style={{ flex:1 }}>
                  <span style={{ fontSize:12, fontWeight:700, color:C.text }}>{a.label} </span>
                  <span style={{ fontSize:12, color:C.textSub }}>{a.line}</span>
                </div>
                {clickable && <span style={{ fontSize:11, color:C.mutedLight, flexShrink:0, marginTop:2 }}>&#8595;</span>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function OccupationPicker({ occs, grouped, singleSector, query, persona, pickerFullLoading, noExactMatch, onSelect, onSearchAgain }) {
  const [localQuery, setLocalQuery] = useState(query);
  const [showAllSectors, setShowAllSectors] = useState(false);
  const [expandedSectors, setExpandedSectors] = useState({});
  const [nudgeDismissed, setNudgeDismissed] = useState(false);
  const browseRef = useRef(null);
  const toggleSector = (sector) => setExpandedSectors(p => ({ ...p, [sector]: !p[sector] }));

  const topPicks = occs.slice(0, 8);
  const additionalCount = Math.max(0, occs.length - 8);
  const showNudge = !pickerFullLoading && additionalCount > 0 && !nudgeDismissed;

  const sectorMap = {};
  occs.forEach(o => {
    const rawSector = toTitleCase(o.industry || o.iscoGroup || "General");
    const key = rawSector === "General" ? "Across industries" : rawSector;
    if (!sectorMap[key]) sectorMap[key] = [];
    sectorMap[key].push(o);
  });
  const sectorGroups = Object.entries(sectorMap)
    .map(([sector, items]) => ({ sector, items }))
    .sort((a, b) => a.sector.localeCompare(b.sector));

  return (
    <div style={{ paddingBottom: showNudge ? 80 : 0 }}>
      {/* Editable search input - pre-filled, user can correct and re-search */}
      <div style={{ display:"flex", gap:8, marginBottom:12 }}>
        <input type="text" value={localQuery} onChange={e => setLocalQuery(e.target.value)}
          onKeyDown={e => e.key === "Enter" && localQuery.trim() && onSearchAgain(localQuery.trim())}
          style={{ flex:1, background:C.surface, border:`1.5px solid ${C.accent}`, borderRadius:7, color:C.text, padding:"10px 13px", fontSize:15, outline:"none", fontFamily:"inherit" }} autoFocus />
        <button onClick={() => localQuery.trim() && onSearchAgain(localQuery.trim())}
          style={{ background:C.eu, border:"none", borderRadius:7, color:"#fff", padding:"10px 18px", fontSize:13, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>
          Search
        </button>
      </div>
      {/* Heading only - no redundant instructions */}
      <div style={{ background:C.surface, border:`2px solid ${C.accent}`, borderRadius:10, padding:"12px 16px", marginBottom:12 }}>
        <p style={{ margin:0, fontSize:16, fontWeight:800, color:C.text, lineHeight:1.3 }}>
          {pickerFullLoading
            ? <>First 8 roles for <span style={{ color:C.accent }}>"{query}"</span> <span style={{ fontSize:12, fontWeight:500, color:C.muted }}>- loading more...</span></>
            : <>{occs.length} role{occs.length!==1?"s":""} found for <span style={{ color:C.accent }}>"{query}"</span></>
          }
        </p>
        {noExactMatch && (
          <div style={{ margin:"8px 0 0", padding:"8px 10px", background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:6 }}>
            <p style={{ margin:0, fontSize:12, fontWeight:600, color:"#92400e", lineHeight:1.5 }}>
              We could not find an exact match for "{noExactMatch}" in our database.
            </p>
            <p style={{ margin:"3px 0 0", fontSize:11, color:"#92400e", lineHeight:1.5 }}>
              These are the closest roles we found. Please select the one that best fits what you were looking for.
            </p>
          </div>
        )}
        {!noExactMatch && occs.some(o => o.isAltLabel) && (
          <p style={{ margin:"6px 0 0", fontSize:11, color:C.mutedLight, fontStyle:"italic" }}>
            "{query}" is an alternative title - the preferred ESCO term is shown below.
          </p>
        )}
        <p style={{ margin:"8px 0 0", fontSize:11, color:C.muted, lineHeight:1.5 }}>
          Not finding the right match? Try a more specific title - e.g. add your sector or specialisation.
        </p>
      </div>

      {/* Persona reminder if set */}
      {persona && (
        <div style={{ background:safePersona(persona).bg, border:`1px solid ${safePersona(persona).border}`, borderRadius:7, padding:"8px 14px", marginBottom:10, fontSize:12, color:safePersona(persona).color }}>
          {safePersona(persona).icon} Foundation skills will be generated for: <strong>{safePersona(persona).label}</strong>
        </div>
      )}

      {/* Section A - Top picks */}
      {topPicks.length > 0 && (
        <div style={{ marginBottom:14 }}>
          {topPicks.map((o) => <OccCard key={o.title} o={o} onSelect={onSelect} />)}
        </div>
      )}

      {/* Section B - All results by sector */}
      {occs.length > 0 && (
        <div ref={browseRef}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom: pickerFullLoading ? 6 : 8, paddingTop: topPicks.length > 0 ? 4 : 0, borderTop: topPicks.length > 0 ? `1px solid ${C.border}` : "none" }}>
            <p style={{ margin:0, fontSize:11, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>
              Browse all roles
            </p>
            {sectorGroups.length > 1 && (
              <button onClick={() => {
                const allOpen = sectorGroups.every(g => expandedSectors[g.sector]);
                const s = {};
                sectorGroups.forEach(g => { s[g.sector] = !allOpen; });
                setExpandedSectors(s);
              }} style={{ background:"transparent", border:`1px solid ${C.border}`, borderRadius:5, fontSize:10, color:C.accent, cursor:"pointer", padding:"3px 10px", fontWeight:600, flexShrink:0 }}>
                {sectorGroups.every(g => expandedSectors[g.sector]) ? "Collapse all" : "Expand all"}
              </button>
            )}
          </div>
          {pickerFullLoading && (
            <div style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 14px", marginBottom:10, background:"#f0fdf4", border:"1px solid #86efac", borderRadius:7 }}>
              <div style={{ width:12, height:12, borderRadius:"50%", border:"2px solid #86efac", borderTop:"2px solid #16a34a", animation:"sp 0.7s linear infinite", flexShrink:0 }} />
              <p style={{ margin:0, fontSize:13, fontWeight:500, color:"#166534", lineHeight:1.5 }}>
                Loading more roles - please wait.
              </p>
            </div>
          )}
          {showNudge && (
            <div style={{ position:"fixed", bottom:20, left:"50%", transform:"translateX(-50%)", zIndex:200, maxWidth:340, width:"calc(100% - 32px)", background:"#166534", borderRadius:12, padding:"12px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, boxShadow:"0 4px 20px rgba(0,0,0,0.25)" }}>
              <button
                onClick={() => { browseRef.current?.scrollIntoView({ behavior:"smooth", block:"start" }); setNudgeDismissed(true); }}
                style={{ flex:1, background:"transparent", border:"none", cursor:"pointer", textAlign:"left", padding:0 }}>
                <p style={{ margin:0, fontSize:13, fontWeight:700, color:"#fff", lineHeight:1.4 }}>
                  {additionalCount} more roles loaded below
                </p>
                <p style={{ margin:"2px 0 0", fontSize:11, color:"#bbf7d0", lineHeight:1.3 }}>
                  Tap to browse by industry ↓
                </p>
              </button>
              <button
                onClick={() => setNudgeDismissed(true)}
                style={{ background:"rgba(255,255,255,0.15)", border:"none", borderRadius:8, color:"#fff", fontSize:16, lineHeight:1, padding:"4px 8px", cursor:"pointer", flexShrink:0 }}>
                ✕
              </button>
            </div>
          )}
          {sectorGroups.map(g => (
            <div key={g.sector} style={{ marginBottom:8 }}>
              <button onClick={() => toggleSector(g.sector)}
                style={{ width:"100%", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"9px 13px", background:C.surface, border:`1px solid ${C.border}`, borderRadius:expandedSectors[g.sector] ? "7px 7px 0 0" : 7, cursor:"pointer", textAlign:"left" }}>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <span style={{ fontSize:12, fontWeight:700, color:C.text }}>{g.sector}</span>
                  <span style={{ fontSize:11, color:C.muted, background:C.bg, border:`1px solid ${C.border}`, borderRadius:10, padding:"1px 8px" }}>{g.items.length}</span>
                </div>
                <span style={{ fontSize:10, color:C.muted }}>{expandedSectors[g.sector] ? "▲" : "▼"}</span>
              </button>
              {expandedSectors[g.sector] && (
                <div style={{ border:`1px solid ${C.border}`, borderTop:"none", borderRadius:"0 0 7px 7px", padding:"6px 6px 2px" }}>
                  {g.items.map((o) => <OccCard key={o.title} o={o} onSelect={onSelect} />)}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function OccCard({ o, onSelect }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div onClick={() => onSelect(o)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ background: hovered ? C.accentSoft : C.surface, border:`1px solid ${hovered ? C.accent : C.border}`, borderRadius:7, padding:"11px 14px", marginBottom:5, cursor:"pointer", transition:"all 0.15s" }}>
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:8 }}>
        <p className="t-body" style={{ margin:"0 0 2px", fontSize:14, fontWeight:600, color: hovered ? C.accent : C.text, flex:1 }}>{toTitleCase(o.title)}</p>
        {o.isAltLabel && <span style={{ fontSize:9, fontWeight:700, color:C.accent, background:C.accentSoft, border:`1px solid #c3d3f5`, borderRadius:8, padding:"2px 6px", whiteSpace:"nowrap", flexShrink:0 }}>alt label</span>}
      </div>
      <p style={{ margin:0, fontSize:11, color:C.muted, lineHeight:1.5 }}>
        {o.iscoCode && <span style={{ color:C.mutedLight }}>ISCO-08: {o.iscoCode} · </span>}
        {(o.description||"").slice(0,110)}{(o.description||"").length>110?"...":""}
      </p>
    </div>
  );
}

function CommunityNote() {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ marginTop:8 }}>
      <button onClick={() => setOpen(o => !o)}
        style={{ background:"transparent", border:"none", fontSize:12, color:C.accent, cursor:"pointer", padding:0, textDecoration:"underline", textDecorationStyle:"dotted", fontWeight:600 }}>
        {open ? "▲ close" : "▼ Note by builder"}
      </button>
      {open && (
        <div style={{ marginTop:10, background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"16px 20px" }}>
          <p style={{ margin:"0 0 10px", fontSize:12, color:C.textSub, lineHeight:1.75 }}>
            This tool is completely free to use. The underlying sources I draw from are openly available, and it did not feel right to charge for something built on public knowledge.
          </p>
          <p style={{ margin:"0 0 10px", fontSize:12, color:C.textSub, lineHeight:1.75 }}>
            That said, each query does carry a small cost on my end - so if you ever run into a slow response or a brief hiccup, please do bear with me. I top up the credits as I go, and your patience genuinely means a lot.
          </p>
          <p style={{ margin:"0 0 14px", fontSize:12, color:C.textSub, lineHeight:1.75 }}>
            If you find it useful - or even if you do not - I would love to hear from you. A quiet DM here on LinkedIn with where you are from and a line of feedback. No pressure at all, just a conversation.
          </p>
          <p style={{ margin:"0 0 14px", fontSize:11, color:C.muted, fontStyle:"italic", lineHeight:1.65 }}>
            P.S. This is a side hobby - built in spare moments out of genuine curiosity about where work is heading. I hope it is useful to someone out there.
          </p>
          <a href="https://www.linkedin.com/in/angadrian" target="_blank" rel="noreferrer"
            style={{ display:"inline-flex", alignItems:"center", gap:6, fontSize:12, color:"#0a66c2", fontWeight:600, textDecoration:"none", background:"#e8f0fe", border:"1px solid #c3d3f5", borderRadius:20, padding:"6px 14px" }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="#0a66c2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
            Adrian K. L. Ang - linkedin.com/in/angadrian
          </a>
        </div>
      )}
    </div>
  );
}

function Tagline() {
  return (
    <p style={{ margin:"10px 0 0", fontSize:11, color:C.muted, fontStyle:"italic", textAlign:"center", letterSpacing:"0.02em" }}>
      Sometimes the scenic route is the right one.
    </p>
  );
}

function DeviceNote() {
  return (
    <div style={{ display:"flex", alignItems:"flex-start", gap:8, background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:8, padding:"8px 13px", marginTop:8 }}>
      <span style={{ fontSize:14, flexShrink:0 }}>💡</span>
      <p style={{ margin:0, fontSize:11, color:"#78350f", lineHeight:1.6 }}>
        Best explored on a wider screen - results span multiple tabs and detailed breakdowns.
      </p>
    </div>
  );
}

// Persona toggle
const PERSONA_SHORT = { fresh: "Foundation skills plan for entering a new field", crossover: "See which skills travel across to a new field" };
const safePersona = (p) => PERSONA_CONFIG[p] || { label:"", icon:"", color:C.muted, bg:C.bg, border:C.border };

function PersonaToggle({ persona, onChange }) {
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"10px 14px" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
          <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.text }}>Adds a foundation skills plan to the analysis</p>
          <span style={{ fontSize:11, color:C.mutedLight, fontStyle:"italic" }}>optional</span>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(min(200px, 100%), 1fr))", gap:8 }}>
          {Object.entries(PERSONA_CONFIG).map(([key, cfg]) => {
            const active = persona === key;
            return (
              <div key={key} onClick={() => onChange(active ? null : key)}
                style={{ display:"flex", alignItems:"center", gap:9, padding:"10px 11px", borderRadius:7, border:`1.5px solid ${active ? cfg.border : C.border}`, background:active ? cfg.bg : C.bg, cursor:"pointer", transition:"border-color 0.15s, background 0.15s", userSelect:"none" }}>
                <div style={{ width:20, height:20, borderRadius:"50%", border:`2px solid ${active ? cfg.color : C.border}`, flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", background: active ? cfg.bg : "transparent", transition:"all 0.15s" }}>
                  {active && <div style={{ width:10, height:10, borderRadius:"50%", background:cfg.color }} />}
                </div>
                <span style={{ fontSize:16, flexShrink:0, lineHeight:1 }}>{cfg.icon}</span>
                <div style={{ minWidth:0 }}>
                  <p style={{ margin:0, fontSize:12, fontWeight:700, color:active ? cfg.color : C.text, wordBreak:"break-word" }}>{cfg.label}</p>
                  <p style={{ margin:"1px 0 0", fontSize:10, color:C.muted }}>{PERSONA_SHORT[key]}</p>
                </div>
              </div>
            );
          })}
        </div>
        {persona && (
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginTop:10, padding:"6px 10px", borderRadius:6, background:safePersona(persona).bg, border:`1px solid ${safePersona(persona).border}` }}>
            <p style={{ margin:0, fontSize:11, color:safePersona(persona).color }}>
              <strong>{safePersona(persona).label}</strong> selected - foundation skills plan will be included in the analysis.
            </p>
            <span onClick={e => { e.stopPropagation(); onChange(null); }}
              style={{ fontSize:11, color:C.muted, cursor:"pointer", textDecoration:"underline", textUnderlineOffset:2, marginLeft:12, whiteSpace:"nowrap", flexShrink:0 }}>
              remove
            </span>
          </div>
        )}
      </div>

    </div>
  );
}


function ExposureBar({ skills }) {
  const cnt = { HIGH:0, MEDIUM:0, LOW:0, HUMAN:0 };
  skills.forEach(s => { if (cnt[s.level] !== undefined) cnt[s.level]++; });
  const total = skills.length || 1;
  return (
    <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"14px 18px", marginBottom:16 }}>
      <p style={{ margin:"0 0 4px", fontSize:10, color:C.muted, textTransform:"uppercase", letterSpacing:"0.07em" }}>AI Exposure Overview</p>
      <p style={{ margin:"0 0 10px" }}>
        <span style={{ fontSize:26, fontWeight:800, color:C.accent }}>{cnt.HIGH + cnt.MEDIUM}</span>
        <span style={{ fontSize:13, color:C.textSub, marginLeft:8 }}>of {total} skills have some level of AI involvement today</span>
      </p>
      {/* Stacked bar with 2px white gaps between segments */}
      <div style={{ display:"flex", gap:2, borderRadius:4, overflow:"hidden", height:8, marginBottom:10 }}>
        {Object.entries(cnt).map(([l,n]) => n > 0 && (
          <div key={l} title={`${LEVELS[l].label}: ${n}`}
            style={{ width:`calc(${(n/total)*100}% - 2px)`, background:LEVELS[l].color, borderRadius:3, transition:"width 0.3s" }} />
        ))}
      </div>
      {/* Inline legend - aligned */}
      <div style={{ display:"flex", gap:14, flexWrap:"wrap" }}>
        {Object.entries(cnt).map(([l,n]) => (
          <div key={l} style={{ display:"flex", alignItems:"center", gap:5 }}>
            <span style={{ fontSize:12, lineHeight:1, width:14, textAlign:"center" }}>{LEVELS[l].icon}</span>
            <span style={{ fontSize:11, color:LEVELS[l].color, fontWeight:600 }}>{n} {LEVELS[l].label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function SkillSegments({ skills, hasNoHuman }) {
  const groups = { HIGH:[], MEDIUM:[], LOW:[], HUMAN:[] };
  skills.forEach(s => { if (groups[s.level]) groups[s.level].push(s); });
  return (
    <div style={{ marginBottom:20 }}>
      <p style={{ margin:"0 0 10px", fontSize:11, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.07em" }}>Skills by Automation Segment</p>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))", gap:10 }}>
        {Object.entries(groups).map(([lvl, items]) => {
          const c = LEVELS[lvl];
          return (
            <div key={lvl} style={{ background:c.bg, border:`1px solid ${c.border}`, borderRadius:8, padding:"10px 12px" }}>
              <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:7 }}>
                <span>{c.icon}</span>
                <span style={{ fontSize:11, fontWeight:700, color:c.color }}>{c.label}</span>
                <span style={{ marginLeft:"auto", fontSize:12, fontWeight:800, color:c.color }}>{items.length}</span>
              </div>
              {items.length === 0
                ? <p style={{ margin:0, fontSize:11, color:C.mutedLight, fontStyle:"italic" }}>None assessed at this level</p>
                : items.map((s,i) => (
                  <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:6, marginBottom:4 }}>
                    <span style={{ width:4, height:4, borderRadius:"50%", background:c.color, flexShrink:0, marginTop:5 }} />
                    <span style={{ fontSize:11, color:C.textSub, lineHeight:1.5 }}>{s.skill}</span>
                  </div>
                ))
              }
            </div>
          );
        })}
      </div>
      {hasNoHuman && (
        <div style={{ display:"flex", alignItems:"flex-start", gap:8, marginTop:10, padding:"8px 12px", background:"#f8fafc", border:"1px solid #e2e8f0", borderRadius:7 }}>
          <span style={{ fontSize:13, flexShrink:0 }}>♦</span>
          <p style={{ margin:0, fontSize:11, color:C.textSub, lineHeight:1.65 }}>
            <strong style={{ color:C.text }}>No Human-Led skills shown?</strong> For this role, all essential skills were assessed as having some level of AI involvement today. Human-Led only applies where AI genuinely cannot help - think crisis judgment, physical care, or building trust with real people at stake. If that does not feel right, check the Skill Detail tab for the full reasoning.
          </p>
        </div>
      )}
    </div>
  );
}

// Prompt example block with copy button
function extractActAsRole(text) {
  // Extract role name from "Act as [role]." or "Act as a [role]." pattern
  const m = text.match(/^Act as (?:a |an )?([^.]+?)[.,]/i);
  if (!m) return null;
  const role = m[1].trim();
  // Filter out generic phrases that are not job titles
  const skip = ["expert","specialist","professional","advisor","consultant","coach","mentor"];
  const lower = role.toLowerCase();
  if (skip.some(s => lower === s)) return null;
  return role;
}

function PromptBlock({ text, onSearch, prep, twoStep, readiness, promptTech, nextPhase, automationLevel }) {
  const [copied, setCopied] = useState(false);
  const [techTooltipVisible, setTechTooltipVisible] = useState(false);
  const fallbackCopy = () => {
    try {
      const el = document.createElement("textarea");
      el.value = text;
      el.style.cssText = "position:fixed;top:0;left:0;opacity:0;pointer-events:none;";
      document.body.appendChild(el);
      el.focus();
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    } catch(_) {}
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const handleCopy = (e) => {
    e.stopPropagation();
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(() => {
        setCopied(true);
        track("prompt_copied");
        setTimeout(() => setCopied(false), 2000);
      }).catch(() => fallbackCopy());
    } else {
      fallbackCopy();
    }
  };

  // Prompt technique display config
  const TECH_META = {
    "persona-injection":    { label:"Persona injection",    desc:"AI is assigned a specific expert identity with seniority and domain context. Improves accuracy, tone, and domain specificity.", level:"L1-2", color:"#374151", bg:"#f3f4f6", border:"#d1d5db" },
    "directional-stimulus": { label:"Directional stimulus", desc:"A keyword, hint, or framing nudge steers AI toward the right answer space without constraining the output.", level:"L2-3", color:"#3B6D11", bg:"#f7fee7", border:"#bef264" },
    "chain-of-thought":     { label:"Chain of thought",     desc:"AI reasons step by step before answering. Surfaces logic so you can check reasoning, not just output.", level:"L3-4", color:"#92400e", bg:"#fffbeb", border:"#fcd9a0" },
    "generate-knowledge":   { label:"Generate knowledge",   desc:"AI surfaces relevant knowledge first, then applies it to the task. Reduces hallucination on knowledge-intensive work.", level:"L3-4", color:"#0e7490", bg:"#ecfeff", border:"#a5f3fc" },
    "least-to-most":        { label:"Least-to-most",        desc:"Complex problem broken into simpler subproblems, solved in order. Each answer builds the next. Good for dependent reasoning chains.", level:"L4-5", color:"#0f766e", bg:"#f0fdfa", border:"#99f6e4" },
    "output-contract":      { label:"Output contract",      desc:"Explicit output structure with field names, section headers, and word or count targets. Eliminates vague responses.", level:"L4-5", color:"#1e40af", bg:"#dbeafe", border:"#bfdbfe" },
    "skeleton-of-thought":  { label:"Skeleton of thought",  desc:"Generate a structured outline first, then expand each section. Faster for long structured documents where sections are independent.", level:"L4-5", color:"#1e3a8a", bg:"#eff6ff", border:"#bfdbfe" },
    "few-shot-anchor":      { label:"Few-shot anchor",       desc:"A worked example of ideal input-output is embedded before the task. AI calibrates to your quality standard, not its default.", level:"L5-6", color:"#065f46", bg:"#d1fae5", border:"#a7f3d0" },
    "multimodal-cot":       { label:"Multimodal CoT",        desc:"Combines image and text inputs with chain-of-thought reasoning. AI reasons across both modalities. Applicable when the task involves interpreting a visual alongside text.", level:"L5-6", color:"#9a3412", bg:"#fff7ed", border:"#fed7aa" },
    "self-consistency":     { label:"Self-consistency",      desc:"Same prompt run multiple times; the most consistent answer selected. Best for high-stakes analytical tasks where a single answer may be unreliable.", level:"L5-6", color:"#6b21a8", bg:"#faf5ff", border:"#e9d5ff" },
    "meta-prompting":       { label:"Meta prompting",        desc:"Describe the shape and evaluation criteria of the ideal answer before asking. AI knows what good looks like before it starts.", level:"L6-7", color:"#0f766e", bg:"#f0fdfa", border:"#99f6e4" },
    "tree-of-thoughts":     { label:"Tree of thoughts",      desc:"AI explores 2-3 reasoning branches before committing. Catches weak paths early. Good for complex decisions with multiple viable routes.", level:"L7-8", color:"#b45309", bg:"#fef3c7", border:"#fde68a" },
    "decomposition-scaffold":{ label:"Decomposition scaffold", desc:"Task broken into numbered sub-steps before execution. AI reasons across stages rather than in a single pass.", level:"L7-8", color:"#0369a1", bg:"#e0f2fe", border:"#bae6fd" },
    "reflexion":            { label:"Reflexion",             desc:"Generate output, reflect on what was weak or missing, then produce an improved version. Deeper than self-critique - evaluates reasoning, not just output.", level:"L7-8", color:"#7c3aed", bg:"#f3e8ff", border:"#d8b4fe" },
    "self-critique-loop":   { label:"Self-critique loop",    desc:"Generate, evaluate against 3 named criteria, revise, deliver. Removes one full review cycle from your workflow.", level:"L7-8", color:"#7c3aed", bg:"#f3e8ff", border:"#d8b4fe" },
    "react":                { label:"ReAct",                 desc:"Alternate reason-then-act cycles. Each action informs the next reasoning step. Powerful for multi-step analytical tasks.", level:"L7-8", color:"#9a3412", bg:"#fff7ed", border:"#fed7aa" },
    "prompt-chaining":      { label:"Prompt chaining",       desc:"Output of one prompt feeds the next. Each step refines the result. Enables complex multi-stage workflows.", level:"L9-10", color:"#be185d", bg:"#fdf2f8", border:"#fbcfe8" },
    "rag":                  { label:"RAG",                   desc:"Retrieval augmented generation. Retrieved documents or data are injected into the prompt before generating. Grounds AI in real source material, not training knowledge.", level:"L9-10", color:"#0f766e", bg:"#f0fdfa", border:"#99f6e4" },
    "agentic-task-spec":    { label:"Agentic task spec",     desc:"Full autonomous brief with decision rules, output verification, and escalation conditions. Designed to run without human initiation.", level:"L11-12", color:"#be185d", bg:"#fdf2f8", border:"#fbcfe8" },
  };
  const tech = TECH_META[promptTech] || null;

  // Next phase colours by automation level
  const NX_STYLE = {
    HIGH:   { bg:"#fdf4ff", border:"#e879f9", color:"#86198f", icon:"⚡" },
    MEDIUM: { bg:"#f0fdf4", border:"#4ade80", color:"#166534", icon:"🔼" },
    LOW:    { bg:"#eff6ff", border:"#93c5fd", color:"#1e40af", icon:"🔼" },
  };
  const nxStyle = NX_STYLE[automationLevel] || NX_STYLE.MEDIUM;

  return (
    <div style={{ marginTop:8, background:"#f0f9ff", border:"1px solid #bae6fd", borderRadius:7, padding:"10px 12px" }}>
      {prep && (
        <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:8, padding:"6px 10px", background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:5 }}>
          <span style={{ fontSize:13, flexShrink:0, lineHeight:1 }}>📋</span>
          <p style={{ margin:0, fontSize:10, color:"#92400e", lineHeight:1.5, fontStyle:"italic" }}>{prep}</p>
        </div>
      )}
      {twoStep && (
        <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:8, padding:"6px 10px", background:"#f3e8ff", border:"1px solid #d8b4fe", borderRadius:5 }}>
          <span style={{ fontSize:13, flexShrink:0, lineHeight:1 }}>💬</span>
          <p style={{ margin:0, fontSize:10, color:"#7c3aed", lineHeight:1.5 }}><strong>Multi-turn prompt</strong> - continue the conversation after the first response. Each follow-up sharpens the output further.</p>
        </div>
      )}
      <div style={{ display:"flex", alignItems:"center", gap:6, flexWrap:"wrap", marginBottom:6 }}>
          <p style={{ margin:0, fontSize:10, fontWeight:700, color:"#0369a1", textTransform:"uppercase", letterSpacing:"0.06em" }}>Prompt</p>
          {readiness === "ready"                           && <span style={{ fontSize:9, fontWeight:600, color:"#166534", background:"#dcfce7", border:"1px solid #a7f3d0", borderRadius:4, padding:"1px 6px", whiteSpace:"nowrap", letterSpacing:"0.02em" }}>Copy and go</span>}
          {(readiness === "quick-prep" || readiness === "prepare") && <span style={{ fontSize:9, fontWeight:600, color:"#b45309", background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:4, padding:"1px 6px", whiteSpace:"nowrap", letterSpacing:"0.02em" }}>Quick prep first</span>}
          {readiness === "deep-prep"                       && <span style={{ fontSize:9, fontWeight:600, color:"#7c3aed", background:"#f3e8ff", border:"1px solid #d8b4fe", borderRadius:4, padding:"1px 6px", whiteSpace:"nowrap", letterSpacing:"0.02em" }}>Prep needed</span>}
          {tech && (
            <div style={{ position:"relative", display:"inline-flex" }}>
              <span
                onMouseEnter={() => setTechTooltipVisible(true)}
                onMouseLeave={() => setTechTooltipVisible(false)}
                onTouchStart={e => { e.stopPropagation(); setTechTooltipVisible(v => !v); }}
                style={{ fontSize:9, fontWeight:700, color:tech.color, background:tech.bg, border:`1px solid ${tech.border}`, borderRadius:10, padding:"1px 7px", whiteSpace:"nowrap", cursor:"help" }}>
                {tech.level} {tech.label}
              </span>
              {techTooltipVisible && (
                <div style={{ position:"absolute", bottom:"calc(100% + 6px)", left:0, zIndex:99, background:"#1e293b", color:"#f1f5f9", fontSize:10, lineHeight:1.55, padding:"8px 11px", borderRadius:7, width:220, boxShadow:"0 4px 16px rgba(0,0,0,0.25)", pointerEvents:"none" }}>
                  <strong style={{ display:"block", marginBottom:3, color:"#e2e8f0" }}>{tech.label}</strong>
                  {tech.desc}
                </div>
              )}
            </div>
          )}
      </div>
      <p className="t-meta" style={{ margin:"0 0 8px", fontSize:11, color:"#0c4a6e", lineHeight:1.65, fontFamily:"monospace", background:"#e0f2fe", borderRadius:5, padding:"6px 9px" }}>{text}</p>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8, marginBottom:6 }}>
        <p style={{ margin:0, fontSize:10, color:"#0369a1", lineHeight:1.5, opacity:0.8, flex:1 }}>
          Paste into any AI tool. Edit <strong>[bracketed]</strong> parts to fit your context.
          {tech && <span> This prompt uses a <strong>{tech.label.toLowerCase()}</strong> - hover the badge above to learn why.</span>}
        </p>
        <button onClick={handleCopy}
          style={{ flexShrink:0, padding:"5px 14px", fontSize:11, fontWeight:700, color: copied ? "#166534" : "#0369a1", background: copied ? "#dcfce7" : "#e0f2fe", border:`1.5px solid ${copied ? "#a7f3d0" : "#bae6fd"}`, borderRadius:6, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.2s" }}>
          {copied ? "Copied ✓" : "Copy prompt"}
        </button>
      </div>
      {nextPhase && (() => {
        const nxText = nextPhase.replace(/^Next phase:\s*/i, "");
        const nxDisplay = nxText.charAt(0).toUpperCase() + nxText.slice(1);
        return (
          <div style={{ marginTop:10, padding:"11px 14px", background:nxStyle.bg, border:`1px solid ${nxStyle.border}`, borderRadius:7 }}>
            <p style={{ margin:"0 0 5px", fontSize:13, fontWeight:700, color:nxStyle.color }}>What to do next</p>
            <p style={{ margin:0, fontSize:13, color:nxStyle.color, lineHeight:1.7 }}>{nxDisplay}</p>
          </div>
        );
      })()}
      {onSearch && extractActAsRole(text) && (() => {
        const role = toTitleCase(extractActAsRole(text));
        return (
          <button
            onClick={e => { e.stopPropagation(); onSearch(role); }}
            style={{ marginTop:8, padding:"5px 12px", fontSize:11, fontWeight:700, color:"#fff", background:"#0369a1", border:"none", borderRadius:6, cursor:"pointer", display:"flex", alignItems:"center", gap:5, textAlign:"left", width:"100%" }}>
            <span>Similar roles to {role} &#8594;</span>
          </button>
        );
      })()}
    </div>
  );
}

function SkillExpertOverlay({ skillName, currentRole, onQueue, queueCount, onClose }) {
  const [experts, setExperts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [queued, setQueued] = useState({});

  useEffect(() => {
    setLoading(true);
    getSkillExperts(skillName, currentRole)
      .then(r => { setExperts(r); setLoading(false); })
      .catch(() => setLoading(false));
  }, [skillName, currentRole]);

  const handleQueue = (role) => {
    if (queueCount >= 3) return;
    onQueue(role);
    setQueued(q => ({ ...q, [role]: true }));
  };

  const handleOpenTab = (role) => {
    const url = `${window.location.origin}${window.location.pathname}?role=${encodeURIComponent(role)}`;
    window.open(url, "_blank");
  };

  return (
    <div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", zIndex:9000, display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
      <div onClick={e => e.stopPropagation()}
        style={{ background:C.bg, borderRadius:12, width:"100%", maxWidth:480, boxShadow:"0 8px 32px rgba(0,0,0,0.22)", overflow:"hidden" }}>
        {/* Header */}
        <div style={{ padding:"14px 16px 10px", borderBottom:`1px solid ${C.border}`, display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:10 }}>
          <div>
            <p style={{ margin:0, fontSize:13, fontWeight:700, color:C.text }}>Who uses this skill?</p>
            <p style={{ margin:"3px 0 0", fontSize:12, color:C.textSub }}>Roles where <strong style={{ color:C.accent }}>{skillName}</strong> is a primary defining capability</p>
          </div>
          <button onClick={onClose} style={{ background:"transparent", border:"none", fontSize:18, color:C.muted, cursor:"pointer", lineHeight:1, padding:0, flexShrink:0 }}>✕</button>
        </div>

        {/* Body */}
        <div style={{ padding:"10px 16px 16px" }}>
          {loading ? (
            <div style={{ display:"flex", alignItems:"center", gap:8, padding:"20px 0" }}>
              <span style={{ width:14, height:14, border:`2px solid ${C.border}`, borderTop:`2px solid ${C.accent}`, borderRadius:"50%", display:"inline-block", animation:"sp 0.7s linear infinite" }} />
              <p style={{ margin:0, fontSize:12, color:C.muted }}>Finding roles where this skill defines the job...</p>
            </div>
          ) : experts.length === 0 ? (
            <p style={{ margin:"16px 0", fontSize:12, color:C.muted, textAlign:"center" }}>Could not load expert roles. Try again.</p>
          ) : (
            experts.map((ex, i) => {
              const isQueued = queued[ex.role];
              const queueFull = queueCount >= 3 && !isQueued;
              return (
                <div key={i} style={{ border:`1px solid ${C.border}`, borderRadius:8, marginBottom:8, padding:"10px 12px", background:C.surface }}>
                  <div style={{ display:"flex", alignItems:"flex-start", gap:10, marginBottom:8 }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:7, flexWrap:"wrap", marginBottom:3 }}>
                        <p style={{ margin:0, fontSize:13, fontWeight:700, color:C.text }}>{ex.role}</p>
                        <span style={{ fontSize:10, fontWeight:600, color:C.muted, background:C.bg, border:`1px solid ${C.border}`, borderRadius:12, padding:"1px 8px", flexShrink:0 }}>{ex.sector}</span>
                      </div>
                      <p style={{ margin:0, fontSize:12, color:C.textSub }}>{ex.why}</p>
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
                    <button
                      onClick={() => handleQueue(ex.role)}
                      disabled={queueFull || isQueued}
                      style={{ flex:"1 1 auto", padding:"5px 10px", fontSize:12, fontWeight:700,
                        color: isQueued ? "#166534" : queueFull ? C.muted : C.accent,
                        background: isQueued ? "#f0fdf4" : queueFull ? C.surface : C.accentSoft,
                        border: `1.5px solid ${isQueued ? "#a7f3d0" : queueFull ? C.border : "#c3d3f5"}`,
                        borderRadius:6, cursor: queueFull || isQueued ? "not-allowed" : "pointer" }}>
                      {isQueued ? "✓ Queued for compare" : queueFull ? "Comparison full" : "+ Compare"}
                    </button>
                    <button
                      onClick={() => handleOpenTab(ex.role)}
                      style={{ flex:"1 1 auto", padding:"5px 10px", fontSize:12, fontWeight:700,
                        color:C.textSub, background:C.surface,
                        border:`1.5px solid ${C.border}`, borderRadius:6, cursor:"pointer" }}>
                      Explore similar role ↗
                    </button>
                  </div>
                </div>
              );
            })
          )}
          {queueCount >= 3 && (
            <p style={{ margin:"8px 0 0", fontSize:11, color:C.muted, fontStyle:"italic", textAlign:"center" }}>
              Comparison full - run the comparison first to free a slot.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function SkillGroupedView({ grouped, result, onSearch, skillInputResult, skillInputQuery, onSkillSearch, onSkillQueryChange, firstAnalysis, onQueue, queueCount, currentRole }) {
  // Find the first group that is not Human-Led - open its first skill on debut
  const firstAiGroupIdx = grouped.findIndex(g => g.level !== "HUMAN");
  const [expandedGroups, setExpandedGroups] = useState(() => {
    const s = {}; grouped.forEach(g => { s[g.level] = true; }); return s;
  });
  const matchedSkillRef = useRef(null);
  const jumpToMatch = () => {
    const matchName = skillInputResult?.match || skillInputResult?.close || "";
    if (!matchName) return;
    // Find which group contains the match
    const targetGroup = grouped.find(g =>
      g.skills.some(s => s.skill.toLowerCase() === matchName.toLowerCase())
    );
    if (targetGroup) {
      // Expand the group if collapsed
      setExpandedGroups(prev => ({ ...prev, [targetGroup.level]: true }));
    }
    // Scroll after a brief delay to allow expand render
    setTimeout(() => {
      matchedSkillRef.current?.scrollIntoView({ behavior:"smooth", block:"center" });
    }, 120);
  };
  const allExpanded = grouped.every(g => expandedGroups[g.level]);
  const toggleAll = () => {
    const next = !allExpanded;
    const s = {}; grouped.forEach(g => { s[g.level] = next; }); setExpandedGroups(s);
  };
  const toggleGroup = (level) => setExpandedGroups(p => ({ ...p, [level]: !p[level] }));
  return (
    <div>
      <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:8, padding:"10px 14px", marginBottom:12 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
          <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.muted }}>Skill Analysis ({result.skills?.length||0} skills)</p>
          <button onClick={toggleAll} style={{ background:"transparent", border:`1px solid ${C.border}`, borderRadius:5, fontSize:12, color:C.accent, cursor:"pointer", padding:"3px 10px", fontWeight:600 }}>
            {allExpanded ? "Collapse all" : "Expand all"}
          </button>
        </div>
        <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.6 }}>Sorted by your strengths first. Tap any group header to expand or collapse.</p>
        <p style={{ margin:"5px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>Ratings reflect general role exposure, not seniority level.</p>
      </div>
      <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:8, padding:"10px 14px", marginBottom:14 }}>
        <p style={{ margin:"0 0 4px", fontSize:12, fontWeight:700, color:C.text }}>Where does your skill fit in this role?</p>
        <p style={{ margin:"0 0 8px", fontSize:12, color:C.muted, lineHeight:1.5 }}>Type a skill you have and we will show you how it maps here. In English for best results.</p>
        <div style={{ display:"flex", gap:8 }}>
          <input type="text" value={skillInputQuery} onChange={e => onSkillQueryChange(e.target.value)} onKeyDown={e => e.key === "Enter" && onSkillSearch(skillInputQuery)} placeholder="e.g. facilitation, Excel, managing conflict..."
            style={{ flex:1, background:C.bg, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, padding:"8px 11px", fontSize:14, outline:"none", fontFamily:"inherit" }} />
          <button onClick={() => onSkillSearch(skillInputQuery)} disabled={!skillInputQuery.trim()}
            style={{ padding:"8px 16px", fontSize:11, fontWeight:700, color:"#fff", background:skillInputQuery.trim() ? C.accent : C.border, border:"none", borderRadius:6, cursor:skillInputQuery.trim() ? "pointer" : "not-allowed", whiteSpace:"nowrap", flexShrink:0 }}>
            Search
          </button>
        </div>
        {skillInputResult && skillInputResult.status === "loading" && (
          <div style={{ display:"flex", alignItems:"center", gap:7, marginTop:8 }}>
            <span style={{ width:10, height:10, border:`1.5px solid ${C.border}`, borderTop:`1.5px solid ${C.accent}`, borderRadius:"50%", display:"inline-block", animation:"sp 0.7s linear infinite" }} />
            <p style={{ margin:0, fontSize:12, color:C.muted }}>Interpreting your skill...</p>
          </div>
        )}
        {skillInputResult && skillInputResult.status === "match" && (
          <div style={{ marginTop:8, padding:"8px 11px", background:C.accentSoft, border:`1px solid #c3d3f5`, borderRadius:6 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8 }}>
              <div>
                <p style={{ margin:"0 0 3px", fontSize:12, fontWeight:700, color:C.accent }}>Found in this role - <strong>{skillInputResult.match}</strong></p>
                <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.5 }}>{skillInputResult.explanation}</p>
              </div>
              <button onClick={jumpToMatch} style={{ flexShrink:0, padding:"4px 12px", fontSize:11, fontWeight:700, color:"#fff", background:C.accent, border:"none", borderRadius:6, cursor:"pointer", whiteSpace:"nowrap" }}>
                Jump to skill ↓
              </button>
            </div>
          </div>
        )}
        {skillInputResult && skillInputResult.status === "close" && (
          <div style={{ marginTop:8, padding:"8px 11px", background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:6 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8 }}>
              <div>
                <p style={{ margin:"0 0 3px", fontSize:12, fontWeight:700, color:"#b45309" }}>Closest match - <strong>{skillInputResult.close}</strong></p>
                <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.5 }}>{skillInputResult.explanation}</p>
              </div>
              <button onClick={jumpToMatch} style={{ flexShrink:0, padding:"4px 12px", fontSize:11, fontWeight:700, color:"#fff", background:"#b45309", border:"none", borderRadius:6, cursor:"pointer", whiteSpace:"nowrap" }}>
                Jump to skill ↓
              </button>
            </div>
          </div>
        )}
        {skillInputResult && skillInputResult.status === "unrelated" && (
          <div style={{ marginTop:8, padding:"8px 11px", background:C.surface, border:`1px solid ${C.border}`, borderRadius:6 }}>
            <p style={{ margin:"0 0 3px", fontSize:12, fontWeight:600, color:C.muted }}>This skill is not in the profile for this role.</p>
            <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.5 }}>{skillInputResult.explanation}</p>
          </div>
        )}
        {skillInputResult && skillInputResult.status === "suggestion" && (
          <div style={{ marginTop:8, padding:"8px 11px", background:C.surface, border:`1px solid ${C.border}`, borderRadius:6 }}>
            <p style={{ margin:"0 0 3px", fontSize:12, fontWeight:600, color:C.muted }}>Could not quite place that.</p>
            <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.5 }}>{skillInputResult.suggestion || skillInputResult.explanation}</p>
          </div>
        )}
      </div>
      {grouped.map((g, gIdx) => (
        <div key={g.level} style={{ marginBottom:10 }}>
          <button onClick={() => toggleGroup(g.level)}
            style={{ width:"100%", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"9px 13px", background:g.bg, border:`1px solid ${g.border}`, borderRadius:expandedGroups[g.level] ? "7px 7px 0 0" : 7, cursor:"pointer", textAlign:"left" }}>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:13 }}>{g.icon}</span>
              <span style={{ fontSize:13, fontWeight:700, color:g.color }}>{g.label}</span>
              <span style={{ fontSize:12, color:g.color, opacity:0.7 }}>{g.skills.length} skill{g.skills.length !== 1 ? "s" : ""}</span>
            </div>
            <span style={{ fontSize:10, color:g.color, opacity:0.7 }}>{expandedGroups[g.level] ? "▲ collapse" : "▼ expand"}</span>
          </button>
          {expandedGroups[g.level] && (
            <div style={{ border:`1px solid ${g.border}`, borderTop:"none", borderRadius:"0 0 7px 7px", padding:"8px 8px 4px", background:C.bg }}>
              <p style={{ margin:"0 0 8px", fontSize:12, color:g.color, lineHeight:1.5, padding:"0 5px", fontStyle:"italic" }}>{g.sub}</p>
              {g.skills.map((s, i) => {
                const isHighlighted = !!(skillInputResult && (skillInputResult.match?.toLowerCase()===s.skill.toLowerCase()||skillInputResult.close?.toLowerCase()===s.skill.toLowerCase()));
                return (
                <SkillRow key={i} item={s} idx={i}
                  highlight={isHighlighted}
                  matchRef={isHighlighted ? matchedSkillRef : null}
                  onSearch={onSearch}
                  autoOpen={firstAnalysis && gIdx === firstAiGroupIdx && i === 0}
                  onQueue={onQueue}
                  queueCount={queueCount}
                  currentRole={currentRole} />
                );
              })}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// Skill detail row
function SkillRow({ item, idx, onSearch, highlight, autoOpen, matchRef, onQueue, queueCount, currentRole }) {
  const [open, setOpen] = useState(!!autoOpen);
  const [showExperts, setShowExperts] = useState(false);
  // Auto-open when this row becomes highlighted via skill search
  useEffect(() => { if (highlight && matchRef) setOpen(true); }, [highlight]);
  const c = LEVELS[item.level] || LEVELS.HUMAN;
  return (
    <>
      {showExperts && (
        <SkillExpertOverlay
          skillName={item.skill}
          currentRole={currentRole || ""}
          onQueue={onQueue}
          queueCount={queueCount || 0}
          onClose={() => setShowExperts(false)}
        />
      )}
      <div ref={matchRef || null} onClick={() => setOpen(o => !o)} style={{ border:`2px solid ${highlight ? c.border : open ? c.border : C.border}`, borderRadius:7, marginBottom:5, background: highlight ? c.bg : open ? c.bg : C.surface, cursor:"pointer", transition:"all 0.15s", boxShadow: highlight ? `0 0 0 3px ${c.bg}` : "none" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 13px" }}>
          <span style={{ minWidth:18, height:18, borderRadius:"50%", background:C.border, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:C.muted, fontWeight:700, flexShrink:0 }}>{idx+1}</span>
          <div style={{ flex:1, minWidth:0 }}>
            <p className="t-body" style={{ margin:0, fontSize:13, color:C.text, fontWeight:500 }}>{item.skill}</p>
            <p style={{ margin:"1px 0 0", fontSize:12, color:C.muted }}>{item.type} - {item.skillType === "soft-skill" ? "Soft Skill" : "Technical Skill"}</p>
          </div>
          <Tag level={item.level} small />
          <span style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0 }}>
            {autoOpen && open && <span style={{ fontSize:9, color:C.accent, fontStyle:"italic", opacity:0.8 }}>tap any skill to explore</span>}
            <span style={{ fontSize:10, color:C.mutedLight }}>{open ? "▲" : "▼"}</span>
          </span>
        </div>
        {open && (
          <div style={{ padding:"2px 13px 11px 41px", borderTop:`1px solid ${c.border}` }}>
            <p style={{ margin:"8px 0 7px", fontSize:12, color:c.color, fontWeight:600 }}>
              {c.icon} {item.tool === "NA" ? "Note:" : "Kickstart:"} {item.kickstart || AI_USAGE[item.tool] || ""}
            </p>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, padding:"6px 11px", flex:"1 1 110px" }}>
                <p style={{ margin:"0 0 2px", fontSize:10, color:C.muted, textTransform:"uppercase" }}>AI Tool</p>
                <p style={{ margin:0, fontSize:12, color:C.accent, fontWeight:600 }}>{item.tool}</p>
              </div>
              <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, padding:"6px 11px", flex:"3 1 200px" }}>
                <p style={{ margin:"0 0 2px", fontSize:10, color:C.muted, textTransform:"uppercase" }}>Approach</p>
                <p style={{ margin:0, fontSize:12, color:C.textSub }}>{item.how}</p>
              </div>
            </div>
            {item.level !== "HUMAN" && (
              item.promptLoading
                ? <div style={{ marginTop:8, padding:"10px 12px", background:"#f0f9ff", border:"1px solid #bae6fd", borderRadius:7, display:"flex", alignItems:"center", gap:8 }}>
                    <div style={{ width:12, height:12, borderRadius:"50%", border:"2px solid #bae6fd", borderTop:"2px solid #0369a1", animation:"sp 0.7s linear infinite", flexShrink:0 }} />
                    <p style={{ margin:0, fontSize:11, color:"#0369a1", fontStyle:"italic" }}>Generating sophisticated prompt...</p>
                  </div>
                : item.promptFailed
                  ? <div style={{ marginTop:8, padding:"8px 12px", background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:7 }}>
                      <p style={{ margin:0, fontSize:11, color:"#92400e" }}>Prompt generation {item.promptFailed === "timeout" ? "timed out" : "failed"} - expand this skill and try again later.</p>
                    </div>
                  : item.prompt
                    ? <PromptBlock text={item.prompt} onSearch={onSearch} prep={item.prep||""} twoStep={item.twoStep||false} readiness={item.readiness||"ready"} promptTech={item.promptTech||""} nextPhase={item.nextPhase||""} automationLevel={item.level} />
                    : null
            )}
            {/* Who uses this skill */}
            <button
              onClick={e => { e.stopPropagation(); setShowExperts(true); }}
              style={{ marginTop:10, display:"inline-flex", alignItems:"center", gap:5, padding:"5px 12px", fontSize:11, fontWeight:700, color:C.textSub, background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, cursor:"pointer" }}>
              <span style={{ fontSize:13 }}>🔍</span> Who uses this skill?
            </button>
          </div>
        )}
      </div>
    </>
  );
}

// Foundation skills panel
function FoundationCard({ item }) {
  const [open, setOpen] = useState(false);
  const pc = PRIORITY_CFG[item.priority] || PRIORITY_CFG["Develop"];
  const catIcon = CATEGORY_ICONS[item.category] || "📌";
  return (
    <div onClick={() => setOpen(o => !o)}
      style={{ border:`1px solid ${open ? pc.border : C.border}`, borderRadius:8, marginBottom:7, background:open ? pc.bg : C.surface, cursor:"pointer", transition:"all 0.15s" }}>
      <div style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 14px" }}>
        <span style={{ fontSize:18, flexShrink:0 }}>{catIcon}</span>
        <div style={{ flex:1, minWidth:0 }}>
          <p style={{ margin:0, fontSize:13, fontWeight:600, color:C.text }}>{item.skill}</p>
          <p style={{ margin:"2px 0 0", fontSize:12, color:C.muted }}>{item.category}</p>
        </div>
        <span style={{ fontSize:11, fontWeight:700, color:pc.color, background:pc.bg, border:`1px solid ${pc.border}`, borderRadius:12, padding:"2px 9px", whiteSpace:"nowrap", flexShrink:0 }}>
          {pc.icon} {item.priority}
        </span>
        <span style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0 }}>
          <span style={{ fontSize:10, color:C.mutedLight }}>{open ? "▲" : "▼"}</span>
        </span>
      </div>
      {open && (
        <div style={{ padding:"4px 14px 12px 42px", borderTop:`1px solid ${pc.border}` }}>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginTop:8 }}>
            <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, padding:"7px 12px", flex:"2 1 180px" }}>
              <p style={{ margin:"0 0 2px", fontSize:10, color:C.muted, textTransform:"uppercase" }}>Why AI Cannot Replace This</p>
              <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.5 }}>{item.why}</p>
            </div>
            <div style={{ background:"#f0fdf4", border:"1px solid #a7f3d0", borderRadius:6, padding:"7px 12px", flex:"2 1 180px" }}>
              <p style={{ margin:"0 0 2px", fontSize:10, color:C.green, textTransform:"uppercase", fontWeight:700 }}>Learning Action</p>
              <p style={{ margin:0, fontSize:12, color:"#166534", fontWeight:600, lineHeight:1.5 }}>{item.action}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FoundationPanel({ data, persona }) {
  if (!data) return null;
  const cfg = PERSONA_CONFIG[persona];
  const grouped = { "Must-Have":[], "High":[], "Develop":[] };
  data.foundations.forEach(f => { if (grouped[f.priority]) grouped[f.priority].push(f); });
  return (
    <div>
      <div style={{ background:cfg.bg, border:`1px solid ${cfg.border}`, borderRadius:10, padding:"12px 16px", marginBottom:16, display:"flex", gap:12, alignItems:"flex-start" }}>
        <span style={{ fontSize:22, flexShrink:0 }}>{cfg.icon}</span>
        <div>
          <p style={{ margin:"0 0 3px", fontSize:12, fontWeight:700, color:cfg.color }}>Foundation Skills for: {cfg.label}</p>
          <p style={{ margin:0, fontSize:12, color:C.textSub, lineHeight:1.55 }}>{data.summary}</p>
        </div>
      </div>
      <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:14 }}>
        {Object.entries(PRIORITY_CFG).map(([p, pc]) => (
          <div key={p} style={{ display:"flex", alignItems:"center", gap:5, fontSize:12 }}>
            <span>{pc.icon}</span>
            <strong style={{ color:pc.color }}>{p}</strong>
            <span style={{ color:C.muted }}>{p==="Must-Have" ? "- critical from day one" : p==="High" ? "- build within 12 months" : "- develop progressively"}</span>
          </div>
        ))}
      </div>
      {Object.entries(grouped).map(([prio, items]) => items.length > 0 && (
        <div key={prio} style={{ marginBottom:18 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8, paddingBottom:6, borderBottom:`1px solid ${C.border}` }}>
            <span>{PRIORITY_CFG[prio].icon}</span>
            <span style={{ fontSize:12, fontWeight:700, color:PRIORITY_CFG[prio].colour }}>{prio}</span>
            <span style={{ fontSize:12, color:C.muted }}>({items.length} skill{items.length!==1?"s":""})</span>
          </div>
          {items.map((item, i) => <FoundationCard key={i} item={item} />)}
        </div>
      ))}
    </div>
  );
}


// Skill category tab
function AutomationBar({ skills, small }) {
  const counts = { HIGH:0, MEDIUM:0, LOW:0, HUMAN:0 };
  skills.forEach(s => { if (counts[s.level] !== undefined) counts[s.level]++; });
  const total = skills.length || 1;
  const bars = [
    { key:"HIGH",   label:"Full Automation", color:"#dc2626", bg:"#fef2f2" },
    { key:"MEDIUM", label:"AI-Augmented",color:"#d97706", bg:"#fffbeb" },
    { key:"LOW",    label:"AI-Assisted", color:"#2563eb", bg:"#eff6ff" },
    { key:"HUMAN",  label:"Human-Led",   color:"#166534", bg:"#f0fdf4" },
  ];
  return (
    <div>
      <div style={{ display:"flex", gap:2, borderRadius:4, overflow:"hidden", height:small?6:10, marginBottom:small?4:8 }}>
        {bars.map(b => counts[b.key] > 0 && (
          <div key={b.key} style={{ flex:counts[b.key]/total, background:b.color, transition:"flex 0.3s" }} />
        ))}
      </div>
      <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
        {bars.map(b => counts[b.key] > 0 && (
          <span key={b.key} style={{ fontSize:12, color:b.color, fontWeight:700 }}>
            {counts[b.key]} {b.label}
          </span>
        ))}
      </div>
    </div>
  );
}

// Rules-based insight line
function roleInsight(skills, humanLedCount, sharedCount, totalSkills) {
  const highCount = skills.filter(s => s.level === "HIGH").length;
  const humanRatio = humanLedCount / totalSkills;
  const highRatio = highCount / totalSkills;
  const sharedRatio = sharedCount / totalSkills;
  if (humanRatio >= 0.4) return { text:"Strong human-led profile - distinctly resilient to automation", color:"#166534", bg:"#f0fdf4", border:"#a7f3d0" };
  if (highRatio >= 0.5) return { text:"High automation exposure - AI tools play a central role here", color:"#b45309", bg:"#fffbeb", border:"#fcd9a0" };
  if (sharedRatio >= 0.5) return { text:"Builds closely on your transferable strengths", color:"#1a56db", bg:"#e8f0fe", border:"#c3d3f5" };
  if (humanRatio >= 0.25 && highRatio <= 0.25) return { text:"Balanced profile - human judgement leads with moderate AI support", color:"#0e7490", bg:"#ecfeff", border:"#a5f3fc" };
  return { text:"Mixed automation profile - AI tools available alongside human-led work", color:"#4a5568", bg:C.surface, border:C.border };
}

function ComparisonPanel({ comparisons, onRemove, onAnalyse, onAddThird, currentTitle }) {
  const ready = comparisons.filter(c => c.result && c.result.skills && c.result.skills.length > 0);
  if (ready.length < 2) return null;
  const [activeRoleIdx, setActiveRoleIdx] = useState(0);
  // On narrow screens show one role at a time; on wide screens show all side by side
  // useRef to detect actual rendered width rather than relying on media query
  const panelRef = useRef(null);
  const [isNarrow, setIsNarrow] = useState(false);
  useEffect(() => {
    const el = panelRef.current;
    if (!el) return;
    const obs = new ResizeObserver(([entry]) => {
      setIsNarrow(entry.contentRect.width < 560);
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  // Clamp activeRoleIdx when roles removed
  const safeIdx = Math.min(activeRoleIdx, ready.length - 1);
  const skillSets = ready.map(c => c.result.skills.map(s => s.skill.toLowerCase()));

  // Fuzzy match - two skills are similar if they share 2+ significant words
  const stopWords = new Set(["and","or","the","a","an","in","of","to","with","for","by","as","on","at","is","be","are","from","into","that","this","through","using","their","these","those"]);
  const sigWords = (s) => s.toLowerCase().split(/\s+/).filter(w => w.length > 3 && !stopWords.has(w));
  const skillsMatch = (a, b) => {
    if (a === b) return true;
    const wa = sigWords(a), wb = sigWords(b);
    const shared = wa.filter(w => wb.some(x => x.startsWith(w.slice(0,5)) || w.startsWith(x.slice(0,5))));
    return shared.length >= 2;
  };
  // For each skill in role 0, check if a similar skill exists in every other role
  // Check from ALL roles as anchor - skill shared across all roles regardless of which role "owns" it
  const allSharedSets = ready.map((anchor, ai) =>
    anchor.result.skills.filter(s0 =>
      ready.filter((_, ri) => ri !== ai).every(c =>
        c.result.skills.some(s1 => skillsMatch(s0.skill.toLowerCase(), s1.skill.toLowerCase()))
      )
    ).map(s => s.skill.toLowerCase())
  );
  // Deduplicate - merge all anchor findings and remove duplicates by fuzzy match
  const allShared = allSharedSets.flat().filter((s, i, arr) =>
    arr.findIndex(x => skillsMatch(x, s)) === i
  );

  const humanLed = ready.map(c => c.result.skills.filter(s => s.level === "HUMAN"));

  // Pairwise shared - skills from role i that match something in role j but not in allShared
  const pairShared = ready.length === 3 ? [
    { label:`${ready[0].title} & ${ready[1].title}`, skills: ready[0].result.skills.filter(s0 => !allShared.some(a => skillsMatch(a, s0.skill.toLowerCase())) && ready[1].result.skills.some(s1 => skillsMatch(s0.skill.toLowerCase(), s1.skill.toLowerCase()))).map(s => s.skill.toLowerCase()) },
    { label:`${ready[0].title} & ${ready[2].title}`, skills: ready[0].result.skills.filter(s0 => !allShared.some(a => skillsMatch(a, s0.skill.toLowerCase())) && ready[2].result.skills.some(s2 => skillsMatch(s0.skill.toLowerCase(), s2.skill.toLowerCase()))).map(s => s.skill.toLowerCase()) },
    { label:`${ready[1].title} & ${ready[2].title}`, skills: ready[1].result.skills.filter(s1 => !allShared.some(a => skillsMatch(a, s1.skill.toLowerCase())) && ready[2].result.skills.some(s2 => skillsMatch(s1.skill.toLowerCase(), s2.skill.toLowerCase()))).map(s => s.skill.toLowerCase()) },
  ] : [];
  const prioritySkills = (skills) => {
    const order = { HUMAN:0, LOW:1, MEDIUM:2, HIGH:3 };
    const count = skills.length >= 18 ? 5 : 4;
    return [...skills].sort((a,b) => order[a.level] - order[b.level]).slice(0, count);
  };
  const devGap = (result) => {
    if (!result.progressionData) return [];
    const gaps = result.progressionData.filter(p => p.dir === "up").flatMap(p => p.gap || []);
    return [...new Set(gaps)].slice(0, 3);
  };
  const uniqueSkills = (i) => {
    const others = ready.filter((_, j) => j !== i).flatMap(o => o.result.skills);
    return ready[i].result.skills.filter(s => !others.some(o => skillsMatch(s.skill.toLowerCase(), o.skill.toLowerCase())));
  };
  const mostHuman = ready.reduce((best, c, i) => humanLed[i].length > humanLed[best].length ? i : best, 0);
  const gapLengths = ready.map((c) => devGap(c.result).length);
  const mostGap = gapLengths.indexOf(Math.max(...gapLengths));
  // AI-generated summary - fetch once when ready roles change
  const [aiSummary, setAiSummary] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const summaryKey = ready.map(r => r.title).sort().join("|");

  useEffect(() => {
    if (ready.length < 2) return;
    let cancelled = false;
    setSummaryLoading(true);
    setAiSummary(null);
    const rolesData = ready.map((r, i) => ({
      title: r.title,
      humanLed: humanLed[i].length,
      highCount: r.result.skills.filter(s => s.level === "HIGH").length,
      sharedSkills: allShared.slice(0, 3).map(s => toTitleCase(s)),
      gapSkills: devGap(r.result).slice(0, 2),
      uniqueSkills: uniqueSkills(i).slice(0, 2).map(s => s.skill),
    }));
    getComparisonSummary(rolesData)
      .then(text => { if (!cancelled) { setAiSummary(text); setSummaryLoading(false); } })
      .catch(() => { if (!cancelled) setSummaryLoading(false); });
    return () => { cancelled = true; };
  }, [summaryKey]);

  const levelBar = [
    { key:"HIGH",   color:"#dc2626", label:"Full Automation" },
    { key:"MEDIUM", color:"#d97706", label:"AI-Augmented" },
    { key:"LOW",    color:"#2563eb", label:"AI-Assisted" },
    { key:"HUMAN",  color:"#166534", label:"Human-Led" },
  ];
  return (
    <div style={{ marginTop:0 }}>
      <div style={{ background:"#f0f9ff", border:"1px solid #bae6fd", borderRadius:8, padding:"10px 14px", marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <p style={{ margin:0, fontSize:12, color:"#0369a1" }}>Commonalities, differences and development needs across your selected roles.</p>
        <span style={{ fontSize:11, fontWeight:600, color:"#0369a1", flexShrink:0, marginLeft:10 }}>{ready.length} of 3 roles</span>
      </div>
      {/* Section 1 - Overlap */}
      <div style={{ background:"#f0fdf4", border:"1px solid #a7f3d0", borderRadius:8, padding:"12px 14px", marginBottom:14 }}>
        <p style={{ margin:"0 0 8px", fontSize:13, fontWeight:800, color:"#166534", lineHeight:1.3 }}>
          {allShared.length > 0 ? `Transferable strengths - shared across all ${ready.length} roles` : `Transferable strengths across all ${ready.length} roles`}
        </p>
        {allShared.length > 0
          ? <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom: pairShared.length > 0 ? 10 : 0 }}>
              {allShared.map((s, i) => <span key={i} style={{ fontSize:12, color:"#166534", background:"#dcfce7", border:"1px solid #a7f3d0", borderRadius:12, padding:"2px 9px" }}>{toTitleCase(s)}</span>)}
            </div>
          : <p style={{ margin:"0 0 10px", fontSize:12, color:C.muted, fontStyle:"italic" }}>No skills shared across all roles - each draws on a distinct skill set.</p>
        }
        {pairShared.filter(p => p.skills.length > 0).map((pair, i) => (
          <div key={i} style={{ marginTop:8, paddingTop:8, borderTop:"1px dashed #a7f3d0" }}>
            <p style={{ margin:"0 0 6px", fontSize:12, fontWeight:700, color:"#0e7490" }}>{pair.label} also share</p>
            <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
              {pair.skills.map((s, j) => <span key={j} style={{ fontSize:12, color:"#0e7490", background:"#ecfeff", border:"1px solid #a5f3fc", borderRadius:12, padding:"2px 8px" }}>{toTitleCase(s)}</span>)}
            </div>
          </div>
        ))}
      </div>
      {/* Section 2 - Automation bars */}
      <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:8, padding:"12px 14px", marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
          <p style={{ margin:0, fontSize:11, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>How AI touches each role</p>
          <div style={{ display:"flex", gap:10, flexWrap:"wrap", justifyContent:"flex-end" }}>
            {levelBar.map(b => (
              <span key={b.key} style={{ display:"flex", alignItems:"center", gap:4 }}>
                <span style={{ width:10, height:10, borderRadius:2, background:b.color, flexShrink:0, display:"inline-block" }} />
                <span style={{ fontSize:9, color:b.color, fontWeight:700 }}>{b.label}</span>
              </span>
            ))}
          </div>
        </div>
        {ready.map((c, i) => {
          const counts = { HIGH:0, MEDIUM:0, LOW:0, HUMAN:0 };
          c.result.skills.forEach(s => { if (counts[s.level] !== undefined) counts[s.level]++; });
          const total = c.result.skills.length || 1;
          return (
            <div key={i} style={{ marginBottom: i < ready.length - 1 ? 14 : 0 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.text, flex:1 }}>{c.title}</p>
                <span style={{ fontSize:10, flexShrink:0, marginLeft:8,
                  color: c.result.skills.length < 25 ? "#b45309" : C.muted,
                  fontWeight: c.result.skills.length < 25 ? 700 : 400 }}>
                  {c.result.skills.length}{c.result.skills.length < 25 ? " skills ↓" : " skills"}
                </span>
              </div>
              <div style={{ display:"flex", gap:2, borderRadius:4, overflow:"hidden", height:12, marginBottom:4 }}>
                {levelBar.map(b => counts[b.key] > 0 && <div key={b.key} style={{ flex:counts[b.key]/total, background:b.color, minWidth:4 }} />)}
              </div>
              <div style={{ display:"flex", gap:8, flexWrap:"nowrap", overflowX:"auto" }}>
                {levelBar.map(b => counts[b.key] > 0 && (
                  <span key={b.key} style={{ fontSize:10, color:b.color, fontWeight:700, whiteSpace:"nowrap", flexShrink:0 }}>
                    {counts[b.key]} <span style={{ fontWeight:500, opacity:0.85 }}>{b.label}</span>
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      {ready.some(c => c.result.skills.length < 25) && (() => {
        const counts = ready.map(c => c.result.skills.length);
        const max = Math.max(...counts);
        const roles = ready.filter(c => c.result.skills.length < max).map(c => c.title);
        return (
        <div style={{ margin:"-4px 0 14px", padding:"7px 12px", background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:6 }}>
          <p style={{ margin:"0 0 2px", fontSize:10, fontWeight:700, color:"#b45309", textTransform:"uppercase", letterSpacing:"0.05em" }}>Skill count varies across roles</p>
          <p style={{ margin:0, fontSize:12, color:"#92400e", lineHeight:1.5 }}>
            {roles.join(" and ")} {roles.length === 1 ? "has" : "have"} fewer skills assessed than the others — ESCO lists fewer essential skills for {roles.length === 1 ? "this occupation type" : "these occupation types"}. The comparison still reflects each role's full profile.
          </p>
        </div>
        );
      })()}
      {/* Section 3 - Role cards */}
      {/* Per-section row grid - each sub-section aligns horizontally across all role columns */}
      {(() => {
        // Pre-compute all per-role data once
        const roleData = ready.map((c, i) => {
          const insight = roleInsight(c.result.skills, humanLed[i].length, allShared.length, c.result.skills.length);
          const priority = prioritySkills(c.result.skills);
          const gap = devGap(c.result);
          const unique = uniqueSkills(i);
          const levelOrd = { HUMAN:0, LOW:1, MEDIUM:2, HIGH:3 };
          const sortedUnique = [...unique].sort((a,b) => (levelOrd[a.level]??2)-(levelOrd[b.level]??2));
          const others = ready.filter((_, j) => j !== i);
          const missingVsOthers = others.map(o => ({
            title: o.title,
            skills: [...o.result.skills.filter(s => !ready[i].result.skills.some(si => skillsMatch(si.skill.toLowerCase(), s.skill.toLowerCase()))).slice(0, 3)]
              .sort((a,b) => (levelOrd[a.level]??2)-(levelOrd[b.level]??2))
          })).filter(o => o.skills.length > 0);
          return { c, i, insight, priority, gap, sortedUnique, missingVsOthers };
        });

        const cols = `repeat(${ready.length},minmax(0,1fr))`;
        const rowStyle = (border) => ({
          display:"grid", gridTemplateColumns:cols, gap:10, marginBottom:0,
          ...(border ? { borderTop:`2px solid ${C.border}`, paddingTop:11, marginTop:14 } : {})
        });
        const cellStyle = { background:C.surface, border:`1px solid ${C.border}`, borderRadius:8, padding:"12px 14px" };

        return (
          <div ref={panelRef}>
            {/* Narrow: stacked role selector - all roles visible, active highlighted */}
            {isNarrow && (
              <div style={{ marginTop:16, marginBottom:20, padding:"12px 0 4px", borderTop:`2px solid ${C.border}` }}>
                <p style={{ margin:"0 0 10px", fontSize:10, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                  Select a role to view details below
                </p>
                {ready.map((c, i) => {
                  const isActive = safeIdx === i;
                  const isCurrent = c.title === currentTitle;
                  return (
                    <div key={i} style={{
                      display:"flex", alignItems:"center", justifyContent:"space-between",
                      padding:"10px 14px", marginBottom:6, borderRadius:8,
                      border:`2px solid ${isActive ? C.accent : C.border}`,
                      background: isActive ? C.accentSoft : C.surface,
                      cursor: isActive ? "default" : "pointer",
                    }}
                    onClick={() => !isActive && setActiveRoleIdx(i)}>
                      <div style={{ flex:1, minWidth:0 }}>
                        <p style={{ margin:0, fontSize:13, fontWeight:700,
                          color: isActive ? C.accent : C.text,
                          lineHeight:1.3 }}>
                          {c.title}
                        </p>
                        {!isActive && !isCurrent && (
                          <p style={{ margin:"2px 0 0", fontSize:12, color:C.accent,
                            textDecoration:"underline", textDecorationStyle:"dotted" }}>
                            Analyse this role
                          </p>
                        )}
                        {isActive && (
                          <p style={{ margin:"2px 0 0", fontSize:12, color:C.accent, fontWeight:600 }}>
                            Viewing now
                          </p>
                        )}
                      </div>
                      {!isActive && (
                        <span style={{ fontSize:11, color:C.mutedLight, flexShrink:0, marginLeft:8 }}>→</span>
                      )}
                      {isActive && !isCurrent && (
                        <button
                          onClick={e => { e.stopPropagation(); onAnalyse && onAnalyse(c.title, "compare"); }}
                          style={{ background:C.accent, border:"none", borderRadius:6,
                            color:"#fff", padding:"3px 10px", fontSize:12, fontWeight:700,
                            cursor:"pointer", flexShrink:0, marginLeft:8 }}>
                          Analyse →
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {/* Row 0 - Role titles */}
            <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:0 }}>
              {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i }) => {
                const isCurrent = c.title === currentTitle;
                return (
                <div key={i} style={{ ...cellStyle, display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8, paddingBottom:8, borderBottomLeftRadius:0, borderBottomRightRadius:0, borderBottom:"none" }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    {isCurrent ? (
                      <p className="t-body" style={{ margin:0, fontSize:13, fontWeight:700, color:C.text, lineHeight:1.4 }}>{c.title}</p>
                    ) : (
                      <button onClick={() => onAnalyse && onAnalyse(c.title, "compare")}
                        style={{ background:"transparent", border:"none", padding:0, margin:0, textAlign:"left", cursor:"pointer", display:"block", width:"100%" }}>
                        <p className="t-body" style={{ margin:0, fontSize:13, fontWeight:700, color:C.accent, lineHeight:1.4, textDecoration:"underline", textDecorationStyle:"dotted", textUnderlineOffset:3 }}>{c.title}</p>
                      </button>
                    )}
                  </div>
                  {!isNarrow && <button onClick={() => onRemove(c.title)} style={{ background:"transparent", border:"none", fontSize:16, color:C.mutedLight, cursor:"pointer", flexShrink:0, padding:0, lineHeight:1 }}>x</button>}
                </div>
                );
              })}
            </div>

            {/* Row 1 - Insight badge */}
            <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:0 }}>
              {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i, insight }) => (
                <div key={i} style={{ ...cellStyle, borderTop:"none", borderBottom:"none", borderRadius:0, paddingTop:0, paddingBottom:8 }}>
                  <div style={{ background:insight.bg, border:`1px solid ${insight.border}`, borderRadius:6, padding:"5px 9px" }}>
                    <p className="result-text-sm" style={{ margin:0, fontSize:12, color:insight.color, fontWeight:600, lineHeight:1.4 }}>{insight.text}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Row 2 - Priority core skills */}
            {/* On narrow: only show if there are AI-involved priority skills (Human-Led already has its own section) */}
            {(() => {
              const showRow = isNarrow
                ? (roleData[safeIdx]?.priority || []).some(s => s.level !== "HUMAN")
                : true;
              if (!showRow) return null;
              return (
                <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:0 }}>
                  {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i, priority }) => {
                    const displayPriority = isNarrow ? priority.filter(s => s.level !== "HUMAN") : priority;
                    if (displayPriority.length === 0) return null;
                    return (
                      <div key={i} style={{ ...cellStyle, borderTop:"none", borderBottom:"none", borderRadius:0, paddingTop:8, paddingBottom:8 }}>
                        <p style={{ margin:"0 0 6px", fontSize:10, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                          Priority core skills{isNarrow ? " (AI-involved)" : ""}
                        </p>
                        {displayPriority.map((s, j) => (
                          <div key={j} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:3 }}>
                            <Tag level={s.level} small />
                            <span className="result-text-sm" style={{ fontSize:12, color:C.textSub, minWidth:0, wordBreak:"break-word" }}>{s.skill}</span>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              );
            })()}

            {/* Row 3 - Human-Led */}
            <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:0 }}>
              {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i }) => (
                <div key={i} style={{ ...cellStyle, borderTop:`2px solid ${C.border}`, borderBottom:"none", borderRadius:0, paddingTop:11, paddingBottom:8 }}>
                  <p style={{ margin:"0 0 6px", fontSize:10, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>Human-Led ({humanLed[i].length})</p>
                  {humanLed[i].length > 0
                    ? humanLed[i].map((s, j) => (
                        <div key={j} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:5 }}>
                          <span style={{ width:5, height:5, borderRadius:"50%", background:"#166534", flexShrink:0 }} />
                          <span className="result-text-sm" style={{ fontSize:12, color:C.textSub, wordBreak:"break-word" }}>{s.skill}</span>
                        </div>
                      ))
                    : <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic" }}>None identified</p>
                  }
                </div>
              ))}
            </div>

            {/* Row 4 - Unique to this role */}
            <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:0 }}>
              {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i, sortedUnique }) => (
                <div key={i} style={{ ...cellStyle, borderTop:`2px solid ${C.border}`, borderBottom:"none", borderRadius:0, paddingTop:11, paddingBottom:8 }}>
                  <p style={{ margin:"0 0 6px", fontSize:10, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                    Unique to this role <span style={{ fontWeight:400, opacity:0.7 }}>({sortedUnique.length})</span>
                  </p>
                  {sortedUnique.length > 0
                    ? sortedUnique.map((s, j) => (
                        <div key={j} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:5 }}>
                          <Tag level={s.level} small />
                          <span className="result-text-sm" style={{ fontSize:12, color:C.textSub, wordBreak:"break-word" }}>{s.skill}</span>
                        </div>
                      ))
                    : <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic" }}>No skills unique to this role</p>
                  }
                </div>
              ))}
            </div>

            {/* Row 5 - Only in other roles */}
            <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:0 }}>
              {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i, missingVsOthers }) => (
                <div key={i} style={{ ...cellStyle, borderTop:`2px solid ${C.border}`, borderBottom:"none", borderRadius:0, paddingTop:11, paddingBottom:8 }}>
                  <p style={{ margin:"0 0 2px", fontSize:10, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>Only in other roles</p>
                  <p style={{ margin:"0 0 6px", fontSize:9, color:C.mutedLight, lineHeight:1.4, fontStyle:"italic" }}>Skills those roles need that this one does not</p>
                  {missingVsOthers.length > 0
                    ? missingVsOthers.map((o, j) => (
                        <div key={j} style={{ marginBottom:10 }}>
                          <p style={{ margin:"0 0 4px", fontSize:12, fontWeight:600, color:C.textSub }}>vs {o.title}</p>
                          {o.skills.map((s, k) => (
                            <div key={k} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:2 }}>
                              <Tag level={s.level} small />
                              <span className="result-text-sm" style={{ fontSize:12, color:C.textSub, wordBreak:"break-word" }}>{s.skill}</span>
                            </div>
                          ))}
                        </div>
                      ))
                    : <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic" }}>All skills in this role are shared</p>
                  }
                </div>
              ))}
            </div>

            {/* Row 6 - Skills to develop */}
            <div style={{ display:"grid", gridTemplateColumns: isNarrow ? "1fr" : cols, gap:10, marginBottom:10 }}>
              {(isNarrow ? [roleData[safeIdx]] : roleData).map(({ c, i, gap }) => (
                <div key={i} style={{ ...cellStyle, borderTop:`2px solid ${C.border}`, borderTopLeftRadius:0, borderTopRightRadius:0, paddingTop:11 }}>
                  <p style={{ margin:"0 0 6px", fontSize:10, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                    Skills to develop <span style={{ fontWeight:400, opacity:0.7 }}>({gap.length})</span>
                  </p>
                  {gap.length > 0
                    ? gap.map((g, j) => (
                        <div key={j} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:5 }}>
                          <span style={{ width:5, height:5, borderRadius:"50%", background:"#b45309", flexShrink:0 }} />
                          <span className="result-text-sm" style={{ fontSize:12, color:C.textSub, wordBreak:"break-word" }}>{g}</span>
                        </div>
                      ))
                    : <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic" }}>No development gaps identified</p>
                  }
                </div>
              ))}
            </div>
          </div>
        );
      })()}
      {/* Section 4 - AI comparison summary - teal, humble tone */}
      <div style={{ background:"#ecfeff", border:"1px solid #a5f3fc", borderRadius:8, padding:"14px 16px", marginBottom:14 }}>
        <p style={{ margin:"0 0 6px", fontSize:14, fontWeight:800, color:"#0e7490", letterSpacing:"-0.01em", lineHeight:1.3 }}>Comparing these roles</p>
        <div style={{ display:"flex", flexWrap:"wrap", gap:6, marginBottom:14 }}>
          {ready.map((c, i) => (
            <span key={i} style={{ fontSize:12, fontWeight:700, color:"#0e7490", background:"#fff", border:"1.5px solid #0e7490", borderRadius:12, padding:"3px 10px" }}>
              {toTitleCase(c.title)}
            </span>
          ))}
        </div>
        {summaryLoading && (
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ width:11, height:11, border:"2px solid #a5f3fc", borderTop:"2px solid #0e7490", borderRadius:"50%", display:"inline-block", animation:"sp 0.7s linear infinite", flexShrink:0 }} />
            <p style={{ margin:0, fontSize:12, color:"#0e7490" }}>Putting the comparison together...</p>
          </div>
        )}
        {aiSummary && (
          <>
            {/* Observation paragraph */}
            {aiSummary.observation && (
              <>
                <p style={{ margin:"0 0 4px", fontSize:10, fontWeight:700, color:"#0e7490", textTransform:"uppercase", letterSpacing:"0.06em" }}>What stands out</p>
                <p className="t-sub" style={{ margin:"0 0 14px", fontSize:12, color:"#0c4a6e", lineHeight:1.85 }}>{aiSummary.observation}</p>
              </>
            )}
            {/* Next step */}
            {aiSummary.nextstep && (
              <div style={{ background:"#fff", border:"1px solid #a5f3fc", borderRadius:6, padding:"7px 10px", marginBottom: aiSummary.warning ? 8 : 0 }}>
                <p style={{ margin:"0 0 2px", fontSize:10, fontWeight:700, color:"#0e7490", textTransform:"uppercase", letterSpacing:"0.06em" }}>A suggested next step</p>
                <p className="t-sub" style={{ margin:0, fontSize:12, color:"#0c4a6e", lineHeight:1.6 }}>{aiSummary.nextstep}</p>
              </div>
            )}
            {/* Warning - only shown if present */}
            {aiSummary.warning && (
              <div style={{ background:"#fffbeb", border:"1px solid #fcd9a0", borderRadius:6, padding:"7px 10px", marginTop:8 }}>
                <p style={{ margin:"0 0 2px", fontSize:10, fontWeight:700, color:"#b45309", textTransform:"uppercase", letterSpacing:"0.06em" }}>Worth being aware of</p>
                <p className="t-sub" style={{ margin:0, fontSize:12, color:"#92400e", lineHeight:1.6 }}>{aiSummary.warning}</p>
              </div>
            )}
          </>
        )}
        {!summaryLoading && !aiSummary && (
          <p style={{ margin:0, fontSize:12, color:"#0e7490", fontStyle:"italic" }}>
            {ready[mostHuman] ? `${ready[mostHuman].title} appears to have the most human-led skills across this comparison.` : ""}
          </p>
        )}
        {aiSummary && (
          <div style={{ margin:"12px 0 0", borderTop:"1px solid #a5f3fc", paddingTop:10 }}>
            <p style={{ margin:"0 0 6px", fontSize:12, fontWeight:700, color:"#0e7490" }}>Ready to act on this?</p>
            <p style={{ margin:0, fontSize:12, color:"#0c4a6e", lineHeight:1.65 }}>
              Each role has AI prompts in the <strong>Skills tab</strong> - select a role above, then tap any skill to see what you can do with it today.
            </p>
          </div>
        )}

      </div>
      {ready.length < 3 && onAddThird && (
        <button onClick={onAddThird} style={{ width:"100%", padding:"10px 14px", fontSize:12, fontWeight:700, color:C.accent, background:C.accentSoft, border:"2px dashed #c3d3f5", borderRadius:8, cursor:"pointer", textAlign:"center" }}>
          + Add a third role to compare
        </button>
      )}
    </div>
  );
}

function RoleContextPanel({ data, skills, firstAnalysis }) {
  const [open, setOpen] = useState(firstAnalysis ? 0 : null);
  if (!data) return null;
  return (
    <div>
      <div style={{ background:"#ecfeff", border:"1px solid #a5f3fc", borderRadius:8, padding:"10px 14px", marginBottom:14 }}>
        <p style={{ margin:0, fontSize:12, fontWeight:700, color:"#0e7490" }}>Role Context</p>
        <p style={{ margin:"3px 0 0", fontSize:12, color:C.textSub, lineHeight:1.6 }}>
          Common sectors where this role appears and the skills most valued in each context.
        </p>
        {data.department && (
          <p style={{ margin:"6px 0 0", fontSize:12, color:C.textSub }}>
            <strong style={{ color:"#0e7490" }}>Department:</strong> {data.department.charAt(0).toUpperCase() + data.department.slice(1)}.
          </p>
        )}
        <p style={{ margin:"6px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>
          AI automation exposure may vary by sector, organisation size, and seniority level. These sectors are indicative - your specific context may differ.
        </p>
      </div>
      {data.sectors.map((sector, i) => {
        const sectorSkills = skills.filter(s => sector.skills.includes(s.n));
        const isOpen = open === i;
        return (
          <div key={i} onClick={() => setOpen(isOpen ? null : i)}
            style={{ border:`1px solid ${isOpen ? "#a5f3fc" : C.border}`, borderRadius:8, marginBottom:8, background:isOpen ? "#ecfeff" : C.surface, cursor:"pointer", transition:"all 0.15s" }}>
            <div style={{ display:"flex", alignItems:"center", gap:12, padding:"11px 16px" }}>
              <div style={{ width:32, height:32, borderRadius:"50%", background:"#ecfeff", border:"1px solid #a5f3fc", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontSize:15 }}>
                🏢
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <p style={{ margin:0, fontSize:13, fontWeight:700, color:C.text }}>{sector.name}</p>
                <p style={{ margin:"1px 0 0", fontSize:12, color:C.textSub }}>{sector.note}</p>
              </div>
              <span style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0 }}>
                {firstAnalysis && i === 0 && isOpen && <span style={{ fontSize:9, color:"#0e7490", fontStyle:"italic", opacity:0.8 }}>tap to explore</span>}
                <span style={{ fontSize:10, color:C.mutedLight }}>{isOpen ? "▲" : `▼ ${sectorSkills.length} skills`}</span>
              </span>
            </div>
            {isOpen && (
              <div style={{ padding:"4px 16px 12px 60px", borderTop:"1px solid #a5f3fc" }}>
                <p style={{ margin:"8px 0 6px", fontSize:10, fontWeight:700, color:"#0e7490", textTransform:"uppercase", letterSpacing:"0.06em" }}>
                  Skills from your role relevant to this sector
                </p>
                {sectorSkills.length > 0
                  ? (() => {
                      const lvlOrd = { HIGH:0, MEDIUM:1, LOW:2, HUMAN:3 };
                      return [...sectorSkills].sort((a,b) => (lvlOrd[a.level]??2)-(lvlOrd[b.level]??2)).map((s, j) => (
                        <div key={j} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5 }}>
                          <div style={{ width:112, flexShrink:0 }}><Tag level={s.level} small /></div>
                          <span style={{ fontSize:12, color:C.textSub }}>{s.skill}</span>
                        </div>
                      ));
                    })()
                  : <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic" }}>See Skill Detail tab for the full breakdown.</p>
                }
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function CategoryPanel({ skills }) {
  const lvlOrd = { HIGH:0, MEDIUM:1, LOW:2, HUMAN:3 };
  const soft = [...skills.filter(s => s.skillType === "soft-skill")].sort((a,b) => (lvlOrd[a.level]??2)-(lvlOrd[b.level]??2));
  const tech = [...skills.filter(s => s.skillType === "technical")].sort((a,b) => (lvlOrd[a.level]??2)-(lvlOrd[b.level]??2));
  return (
    <div>
      {/* Header */}
      <div style={{ background:C.tealBg, border:`1px solid ${C.tealBdr}`, borderRadius:8, padding:"10px 14px", marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:3 }}>
          <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.teal }}>Skill Categories</p>
          <div style={{ display:"flex", gap:12 }}>
            <span style={{ fontSize:12, color:C.accent, fontWeight:600 }}>{tech.length} Technical</span>
            <span style={{ fontSize:12, color:C.purple, fontWeight:600 }}>{soft.length} Soft</span>
          </div>
        </div>
        <p style={{ margin:"3px 0 0", fontSize:12, color:C.textSub, lineHeight:1.6 }}>
          Skills grouped by their primary nature. Most roles blend both - technical skills tend to be more exposed to AI automation, while soft skills are generally more resilient.
        </p>
        <p style={{ margin:"6px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>
          Some skills have characteristics of both categories - the grouping here reflects the dominant nature of each skill.
        </p>
      </div>
      {/* Two column skill list */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(min(260px, 100%), 1fr))", gap:14 }}>
        <div>
          <p style={{ margin:"0 0 8px", fontSize:11, fontWeight:700, color:C.accent, textTransform:"uppercase", letterSpacing:"0.06em" }}>
            Technical Skills ({tech.length})
          </p>
          {tech.length === 0
            ? <p style={{ fontSize:12, color:C.mutedLight, fontStyle:"italic" }}>None identified</p>
            : tech.map((s,i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5, padding:"6px 10px", background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, minWidth:0 }}>
                <div style={{ width:112, flexShrink:0 }}><Tag level={s.level} small /></div>
                <span style={{ fontSize:12, color:C.textSub, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{s.skill}</span>
              </div>
            ))
          }
        </div>
        <div>
          <p style={{ margin:"0 0 8px", fontSize:11, fontWeight:700, color:C.purple, textTransform:"uppercase", letterSpacing:"0.06em" }}>
            Soft Skills ({soft.length})
          </p>
          {soft.length === 0
            ? <p style={{ fontSize:12, color:C.mutedLight, fontStyle:"italic" }}>None identified</p>
            : soft.map((s,i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5, padding:"6px 10px", background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, minWidth:0 }}>
                <div style={{ width:112, flexShrink:0 }}><Tag level={s.level} small /></div>
                <span style={{ fontSize:12, color:C.textSub, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{s.skill}</span>
              </div>
            ))
          }
        </div>
      </div>
    </div>
  );
}

function Disclaimer() {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ marginTop:16, paddingTop:10, borderTop:`1px solid ${C.border}` }}>
      <button onClick={() => setOpen(o => !o)}
        style={{ background:"transparent", border:"none", padding:0, cursor:"pointer", display:"flex", alignItems:"center", gap:6 }}>
        <span style={{ fontSize:12, color:C.mutedLight, textDecoration:"underline", textDecorationStyle:"dotted", textUnderlineOffset:2 }}>
          A note on how to use this
        </span>
        <span style={{ fontSize:9, color:C.mutedLight }}>{open ? "▲" : "▼"}</span>
      </button>
      {open && (
        <div style={{ marginTop:8, padding:"10px 12px", background:C.surface, border:`1px solid ${C.border}`, borderRadius:7 }}>
          <p style={{ margin:"0 0 6px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            Results are AI-generated, indicative, and may vary between searches. They are a starting point for reflection and do not constitute professional career, legal, employment, or HR advice. Ratings reflect general occupational trends, not individual performance or seniority level.
          </p>
          <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic", lineHeight:1.6 }}>
            The best use of this tool is as a conversation starter - with yourself, your team, or someone who knows your work well.
          </p>
        </div>
      )}
    </div>
  );
}


// ── Subtle result footer with About panel ─────────────────────────────────────
function ResultFooter() {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ marginTop:14, paddingTop:12, borderTop:`1px solid ${C.border}` }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:8 }}>
        <p style={{ margin:0, fontSize:12, color:C.mutedLight }}>
          ESCO v1.2 (aligned to v1.2.1) European Commission DG EMPL CC BY 4.0. Powered by AI (Anthropic).
        </p>
        <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
          <a href="mailto:feedback@takearoundabout.com?subject=Feedback - AI Skills Analyser"
            style={{ fontSize:12, color:C.teal, textDecoration:"none", textDecorationStyle:"dotted", textUnderlineOffset:2 }}>
            Share feedback
          </a>
          <button onClick={() => setOpen(o => o === "method" ? false : "method")}
            style={{ background:"transparent", border:"none", fontSize:12, color:C.mutedLight, cursor:"pointer", padding:"2px 6px", textDecoration:"underline", textDecorationStyle:"dotted" }}>
            Methodology
          </button>
          <button onClick={() => setOpen(o => o === "legal" ? false : "legal")}
            style={{ background:"transparent", border:"none", fontSize:12, color:C.mutedLight, cursor:"pointer", padding:"2px 6px", textDecoration:"underline", textDecorationStyle:"dotted" }}>
            Legal
          </button>
          <a href="/terms.html" target="_blank" rel="noreferrer"
            style={{ fontSize:12, color:C.mutedLight, textDecoration:"underline", textDecorationStyle:"dotted" }}>
            Terms
          </a>
        </div>
      </div>
      {open === "legal" && (
        <div style={{ marginTop:12, background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"16px 20px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
            <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.text }}>Legal notice</p>
            <button onClick={() => setOpen(false)} style={{ background:"transparent", border:"none", fontSize:16, color:C.muted, cursor:"pointer", lineHeight:1, padding:0 }}>×</button>
          </div>
          <p style={{ margin:"0 0 8px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            Results are AI-generated and indicative only. They do not constitute professional career, legal, employment, or HR advice. The builder accepts no liability for decisions made based on these outputs.
          </p>
          <p style={{ margin:"0 0 8px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            <strong style={{ color:C.text }}>Singapore</strong> - governed by Singapore law. No personal data collected. Aligns with IMDA Model AI Governance Framework.
          </p>
          <p style={{ margin:"0 0 10px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            <strong style={{ color:C.text }}>European Union</strong> - minimal risk classification under EU AI Act. Not a high-risk system. No automated decisions made about individuals.
          </p>
          <a href="/terms.html" target="_blank" rel="noreferrer"
            style={{ display:"inline-flex", alignItems:"center", gap:5, fontSize:12, color:C.accent, fontWeight:600, textDecoration:"none", background:C.accentSoft, border:`1px solid #c3d3f5`, borderRadius:20, padding:"5px 14px" }}>
            Read full Terms of Use &#8599;
          </a>
        </div>
      )}
      {open === "method" && (
        <div style={{ marginTop:12, background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"16px 20px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:12 }}>
            <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.text }}>Methodology</p>
            <button onClick={() => setOpen(false)} style={{ background:"transparent", border:"none", fontSize:16, color:C.muted, cursor:"pointer", lineHeight:1, padding:0 }}>×</button>
          </div>
          <p style={{ margin:"0 0 10px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            <strong style={{ color:C.text }}>Data source</strong> - Occupation and skills taxonomy drawn from ESCO v1.2 (aligned to v1.2.1), the European Classification of Skills, Competences, Qualifications and Occupations. Published by the European Commission DG Employment, Social Affairs and Inclusion. Licensed CC BY 4.0.
          </p>
          <p style={{ margin:"0 0 10px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            <strong style={{ color:C.text }}>How ratings are generated</strong> - Each skill is assessed by Claude (Anthropic) against current AI capability research. This is AI-generated analysis, not a lookup from a fixed classification table. Results reflect general occupational patterns and will vary between searches.
          </p>
          <p style={{ margin:"0 0 10px", fontSize:12, color:C.textSub, lineHeight:1.7 }}>
            <strong style={{ color:C.text }}>Known limitations</strong> - Ratings reflect broad occupational trends, not your specific organisation, industry sector, or seniority level. The tool may carry anchoring bias - the first rating seen tends to anchor subsequent interpretation. Results are most useful as a structured starting point for reflection, not as a definitive assessment.
          </p>
          <p style={{ margin:0, fontSize:12, color:C.muted, lineHeight:1.6, borderTop:`1px solid ${C.border}`, paddingTop:10 }}>
            For authoritative occupation and skills data, refer to <a href="https://esco.ec.europa.eu" target="_blank" rel="noreferrer" style={{ color:C.accent }}>esco.ec.europa.eu</a>
          </p>
        </div>
      )}
    </div>
  );
}

// ── Progression paths panel ───────────────────────────────────────────────────
const DIR_CFG = {
  up:         { label:"Promotion",   color:"#1a56db", bg:"#e8f0fe", border:"#c3d3f5", icon:"⬆️" },
  lateral:    { label:"Lateral",     color:"#7c3aed", bg:"#f3e8ff", border:"#ddd6fe", icon:"↔️" },
  specialist: { label:"Specialist",  color:"#0e7490", bg:"#ecfeff", border:"#a5f3fc", icon:"🎯" },
};

function ProgressionCard({ item, skills, onAnalyse, onQueue, onQueueCount, autoOpen }) {
  const [open, setOpen] = useState(!!autoOpen);
  const d = DIR_CFG[item.dir] || DIR_CFG.up;
  // Match skills from the role's skill list that are relevant to progression
  // Use HIGH and MEDIUM rated skills as the most transferable
  const relevantSkills = skills.filter(s => s.level === "HIGH" || s.level === "MEDIUM").slice(0, 4);
  return (
    <div onClick={() => setOpen(o => !o)}
      style={{ border:`1px solid ${open ? d.border : C.border}`, borderRadius:8, marginBottom:8, background:open ? d.bg : C.surface, cursor:"pointer", transition:"all 0.15s" }}>
      <div style={{ display:"flex", alignItems:"center", gap:12, padding:"12px 16px" }}>
        <div style={{ width:34, height:34, borderRadius:"50%", background:d.bg, border:`1px solid ${d.border}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontSize:16 }}>
          {d.icon}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:2 }}>
            <p style={{ margin:0, fontSize:13, fontWeight:700, color:C.text }}>{item.role}</p>
            <span style={{ fontSize:10, fontWeight:700, color:d.colour, background:d.bg, border:`1px solid ${d.border}`, borderRadius:12, padding:"1px 8px", flexShrink:0 }}>{d.label}</span>
          </div>
          <p style={{ margin:0, fontSize:12, color:C.textSub }}>{item.note}</p>
        </div>
        <span style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0 }}>
          {autoOpen && open && <span style={{ fontSize:9, color:C.accent, fontStyle:"italic", opacity:0.8 }}>tap to explore</span>}
          <span style={{ fontSize:10, color:C.mutedLight }}>{open ? "▲" : "▼ skills"}</span>
        </span>
      </div>
      {open && (
        <div style={{ padding:"4px 16px 12px 62px", borderTop:`1px solid ${d.border}` }}>
          <p style={{ margin:"8px 0 6px", fontSize:10, fontWeight:700, color:d.colour, textTransform:"uppercase", letterSpacing:"0.06em" }}>
            Skills from your current role that will transfer
          </p>
          {relevantSkills.length > 0
            ? (() => {
                const lvlOrd = { HIGH:0, MEDIUM:1, LOW:2, HUMAN:3 };
                return [...relevantSkills].sort((a,b) => (lvlOrd[a.level]??2)-(lvlOrd[b.level]??2)).map((s, i) => (
                  <div key={i} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5 }}>
                    <div style={{ width:112, flexShrink:0 }}><Tag level={s.level} small /></div>
                    <span style={{ fontSize:12, color:C.textSub }}>{s.skill}</span>
                  </div>
                ));
              })()
            : <p style={{ margin:0, fontSize:12, color:C.muted, fontStyle:"italic" }}>See Skill Detail tab for the full skills breakdown.</p>
          }
          <p style={{ margin:"8px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>
            Based on your current role's highest-automation skills. See Skill Detail tab for the full breakdown.
          </p>
          {item.gap && item.gap.length > 0 && (
            <div style={{ marginTop:10, padding:"7px 10px", background:C.surface, border:`1px solid ${d.border}`, borderRadius:6 }}>
              <p style={{ margin:"0 0 5px", fontSize:10, fontWeight:700, color:d.color, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                Skills to develop for this role
              </p>
              {item.gap.map((g, i) => (
                <div key={i} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:4 }}>
                  <span style={{ width:6, height:6, borderRadius:"50%", background:d.color, flexShrink:0 }} />
                  <span style={{ fontSize:12, color:C.textSub }}>{g}</span>
                </div>
              ))}
              {item.step && (
                <div style={{ marginTop:8, paddingTop:7, borderTop:`1px dashed ${d.border}`, display:"flex", alignItems:"flex-start", gap:6 }}>
                  <span style={{ fontSize:13, flexShrink:0 }}>🪜</span>
                  <p style={{ margin:0, fontSize:12, color:d.color, lineHeight:1.5 }}>
                    Consider stepping through <strong>{item.step}</strong> first - it bridges the gap more gradually.
                  </p>
                </div>
              )}
            </div>
          )}
          <div style={{ display:"flex", gap:8, marginTop:10, flexWrap:"wrap" }}>
            <button
              onClick={e => { e.stopPropagation(); onAnalyse(item.role); }}
              style={{ padding:"5px 14px", fontSize:12, fontWeight:700, color:"#fff", background:d.color, border:"none", borderRadius:6, cursor:"pointer", display:"inline-flex", alignItems:"center", gap:5 }}>
              Analyse this role &#8594;
            </button>
            {onQueue && onQueueCount < 3 && (
              <button
                onClick={e => { e.stopPropagation(); onQueue(item.role); }}
                style={{ padding:"5px 12px", fontSize:12, fontWeight:700, color:d.color, background:"transparent", border:`1.5px solid ${d.border}`, borderRadius:6, cursor:"pointer", display:"inline-flex", alignItems:"center", gap:4 }}>
                ＋ Compare
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ProgressionPanel({ items, skills, onAnalyse, onQueue, onQueueCount, firstAnalysis }) {
  const dirOrder = { up: 0, specialist: 1, lateral: 2 };
  const sorted = [...items].sort((a, b) => (dirOrder[a.dir] ?? 1) - (dirOrder[b.dir] ?? 1));
  return (
    <div>
      <div style={{ background:C.accentSoft, border:"1px solid #c3d3f5", borderRadius:8, padding:"10px 14px", marginBottom:14 }}>
        <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.accent }}>Career Progression within This Sphere</p>
        <p style={{ margin:"3px 0 0", fontSize:12, color:C.textSub, lineHeight:1.6 }}>
          Natural next steps - upward, lateral, or deeper specialist - within the same functional or professional hierarchy. Expand each role to see which of your current skills transfer directly.
        </p>
        <p style={{ margin:"6px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>
          These are indicative starting points. Your actual options depend on your organisation, sector, and experience.
        </p>
      </div>
      {sorted.map((item, i) => <ProgressionCard key={i} item={item} skills={skills} onAnalyse={onAnalyse} onQueue={onQueue} onQueueCount={onQueueCount} autoOpen={firstAnalysis && i === 0} />)}
    </div>
  );
}

// ── Crossover roles panel ─────────────────────────────────────────────────────
function CrossoverCard({ item, skills, onAnalyse, onQueue, onQueueCount, autoOpen }) {
  const [open, setOpen] = useState(!!autoOpen);
  // Find skills that match the bridge skill keyword
  const bridgeSkills = skills.filter(s =>
    s.skill.toLowerCase().includes(item.bridge.toLowerCase().split(" ")[0]) ||
    s.level === "LOW" || s.level === "HUMAN"
  ).slice(0, 4);
  const fallback = skills.filter(s => s.level === "LOW" || s.level === "HUMAN").slice(0, 3);
  const displaySkills = bridgeSkills.length > 0 ? bridgeSkills : fallback;
  return (
    <div onClick={() => setOpen(o => !o)}
      style={{ border:`1px solid ${open ? C.greenBdr : C.border}`, borderRadius:8, marginBottom:8, background:open ? C.greenBg : C.surface, cursor:"pointer", transition:"all 0.15s" }}>
      <div style={{ display:"flex", alignItems:"center", gap:12, padding:"12px 16px" }}>
        <div style={{ width:34, height:34, borderRadius:"50%", background:C.greenBg, border:`1px solid ${C.greenBdr}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontSize:16 }}>
          🔄
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:2 }}>
            <p style={{ margin:0, fontSize:13, fontWeight:700, color:C.text }}>{item.role}</p>
            <span style={{ fontSize:10, fontWeight:600, color:C.muted, background:C.bg, border:`1px solid ${C.border}`, borderRadius:12, padding:"1px 8px", flexShrink:0 }}>{item.sector}</span>
          </div>
          <p style={{ margin:0, fontSize:12, color:C.textSub }}>
            Bridge skill: <strong style={{ color:C.green }}>{item.bridge}</strong>
          </p>
        </div>
        <span style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0 }}>
          {autoOpen && open && <span style={{ fontSize:9, color:C.accent, fontStyle:"italic", opacity:0.8 }}>tap to explore</span>}
          <span style={{ fontSize:10, color:C.mutedLight }}>{open ? "▲" : "▼ skills"}</span>
        </span>
      </div>
      {open && (
        <div style={{ padding:"4px 16px 12px 62px", borderTop:`1px solid ${C.greenBdr}` }}>
          <p style={{ margin:"8px 0 6px", fontSize:10, fontWeight:700, color:C.green, textTransform:"uppercase", letterSpacing:"0.06em" }}>
            Skills from your current role most useful here
          </p>
          {(() => {
              const lvlOrd = { HIGH:0, MEDIUM:1, LOW:2, HUMAN:3 };
              return [...displaySkills].sort((a,b) => (lvlOrd[a.level]??2)-(lvlOrd[b.level]??2)).map((s, i) => (
                <div key={i} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5 }}>
                  <div style={{ width:112, flexShrink:0 }}><Tag level={s.level} small /></div>
                  <span style={{ fontSize:12, color:C.textSub }}>{s.skill}</span>
                </div>
              ));
            })()}
          <p style={{ margin:"8px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>
            Human-led and AI-assisted skills tend to transfer best across sectors. See Skill Detail tab for the full breakdown.
          </p>
          {item.newSkills && item.newSkills.length > 0 && (
            <div style={{ marginTop:10, padding:"7px 10px", background:C.surface, border:`1px solid ${C.greenBdr}`, borderRadius:6 }}>
              <p style={{ margin:"0 0 5px", fontSize:10, fontWeight:700, color:C.green, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                New skills this role may require
              </p>
              {item.newSkills.map((s, i) => (
                <div key={i} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:4 }}>
                  <span style={{ width:6, height:6, borderRadius:"50%", background:C.green, flexShrink:0 }} />
                  <span style={{ fontSize:12, color:C.textSub }}>{s}</span>
                </div>
              ))}
            </div>
          )}
          <div style={{ display:"flex", gap:8, marginTop:10, flexWrap:"wrap" }}>
            <button
              onClick={e => { e.stopPropagation(); onAnalyse(item.role); }}
              style={{ padding:"5px 14px", fontSize:12, fontWeight:700, color:"#fff", background:C.green, border:"none", borderRadius:6, cursor:"pointer", display:"inline-flex", alignItems:"center", gap:5 }}>
              Analyse this role &#8594;
            </button>
            {onQueue && onQueueCount < 3 && (
              <button
                onClick={e => { e.stopPropagation(); onQueue(item.role); }}
                style={{ padding:"5px 12px", fontSize:12, fontWeight:700, color:C.green, background:"transparent", border:`1.5px solid ${C.greenBdr}`, borderRadius:6, cursor:"pointer", display:"inline-flex", alignItems:"center", gap:4 }}>
                ＋ Compare
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function CrossoverPanel({ items, skills, onAnalyse, onQueue, onQueueCount, firstAnalysis }) {
  const sorted = [...items].sort((a, b) => a.role.localeCompare(b.role));
  return (
    <div>
      <div style={{ background:C.greenBg, border:`1px solid ${C.greenBdr}`, borderRadius:8, padding:"10px 14px", marginBottom:14 }}>
        <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.green }}>Career Crossover to Other Roles</p>
        <p style={{ margin:"3px 0 0", fontSize:12, color:C.textSub, lineHeight:1.6 }}>
          Roles in different sectors or functions where your existing skills transfer directly - helping you pivot without starting from scratch. Expand each role to see which skills carry over.
        </p>
        <p style={{ margin:"6px 0 0", fontSize:12, color:C.muted, fontStyle:"italic" }}>
          These are indicative starting points. Your actual options depend on your background, sector, and experience.
        </p>
      </div>
      {sorted.map((item, i) => <CrossoverCard key={i} item={item} skills={skills} onAnalyse={onAnalyse} onQueue={onQueue} onQueueCount={onQueueCount} autoOpen={firstAnalysis && i === 0} />)}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
// Run once on load - lock --app-height to initial viewport before keyboard opens
// Compare warning modal
function CompareWarningModal({ onConfirm, onCancel }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
      <div style={{ background:"#fff", borderRadius:12, padding:"20px 22px", maxWidth:340, width:"100%", boxShadow:"0 8px 32px rgba(0,0,0,0.18)" }}>
        <p style={{ margin:"0 0 6px", fontSize:14, fontWeight:700, color:"#1a202c" }}>Start a new analysis?</p>
        <p style={{ margin:"0 0 16px", fontSize:12, color:"#4a5568", lineHeight:1.6 }}>
          You have an active role comparison below. Starting a new analysis will clear it and begin fresh.
        </p>
        <div style={{ display:"flex", gap:8 }}>
          <button onClick={onConfirm}
            style={{ flex:1, padding:"8px 14px", fontSize:12, fontWeight:700, color:"#fff", background:"#dc2626", border:"none", borderRadius:7, cursor:"pointer" }}>
            Yes, start fresh
          </button>
          <button onClick={onCancel}
            style={{ flex:1, padding:"8px 14px", fontSize:12, fontWeight:700, color:"#1a56db", background:"#e8f0fe", border:"1px solid #c3d3f5", borderRadius:7, cursor:"pointer" }}>
            Keep comparison
          </button>
        </div>
      </div>
    </div>
  );
}

// 100svh (small viewport height) handles keyboard resize natively on iOS and Android

export default function App() {
  const [query,     setQuery]     = useState("");
  const [persona,   setPersona]   = useState(null);
  const [occs,      setOccs]      = useState([]);
  const [pickerLoading, setPickerLoading] = useState(false); // v6: progressive picker
  const [pickerFullLoading, setPickerFullLoading] = useState(false); // v1.3.0: background full search
  const [noExactMatch, setNoExactMatch] = useState(null); // v1.4.7: original search term when no exact ESCO match
  const [sel,       setSel]       = useState(null);
  const [result,    setResult]    = useState(null);
  const [step,      setStep]      = useState("idle");
  const [showExpect, setShowExpect] = useState(false);
  const [skillInputQuery, setSkillInputQuery] = useState("");
  const [skillInputResult, setSkillInputResult] = useState(null);
  const [compareStatus, setCompareStatus] = useState(""); // v6: live step narrative
  const [compareStep,   setCompareStep]   = useState(0);  // v6: current step 1-8
  const [sub,       setSub]       = useState("");
  const [subStep,   setSubStep]   = useState(0);
  const [err,       setErr]       = useState("");
  const [activeTab, setActiveTab] = useState("skills");
  const [comparisons, setComparisons] = useState([]); // [{title, result}] max 3
  const [compareCue, setCompareCue] = useState(false);
  const [toast, setToast]           = useState(null);   // { msg, action? }
  const [showBackTop, setShowBackTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowBackTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const showToast = (msg, action) => {
    setToast({ msg, action });
    setTimeout(() => setToast(null), 5000);
  };
  const [fromPath, setFromPath] = useState(null); // "progression" | "crossover" | null
  const [isRunningComparison, setIsRunningComparison] = useState(false);
  const [compareElapsed, setCompareElapsed] = useState(0);  // seconds elapsed during comparison
  const [compareWarning, setCompareWarning] = useState(null); // { onConfirm } | null
  const toggleRef       = useRef(null);
  const compareRef      = useRef(null);
  const tabBarRef       = useRef(null);
  const hasAnalysedOnce = useRef(false);
  const queueBannerRef = useRef(null);
  const comparisonsRef = useRef([]);
  const debounceRef    = useRef(null); // v6: debounce timer for picker
  const pickerCancelRef = useRef(false); // v1.4.0: cancel in-flight background full search

  // URL param auto-trigger - handles ?role=RoleName from "Explore similar role" in SkillExpertOverlay
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const roleParam = params.get("role");
    if (roleParam) {
      const tidyRole = toTitleCase(decodeURIComponent(roleParam));
      setQuery(tidyRole);
      window.history.replaceState({}, "", window.location.pathname);
      setStep("searching");
      searchOccupations(tidyRole, "8")
        .then(res => {
          if (!res.length) { setStep("idle"); return; }
          const exact = res.find(r => r.title.toLowerCase() === tidyRole.toLowerCase());
          if (exact) {
            // Exact ESCO match - go straight to analysis
            doAnalyse(exact);
          } else {
            // No exact match - show picker with a notice so user can choose the closest role
            setOccs(res);
            setNoExactMatch(tidyRole);
            setStep("picking");
          }
          window.scrollTo({ top: 0, behavior: "smooth" });
        })
        .catch(() => {
          // Search failed - fall back to bare title analysis
          doAnalyse({ title: tidyRole, iscoCode: "", iscoGroup: "", description: "" });
        });
    }
  }, []);

  // v6: debounced instant-search — fires 420ms after user stops typing
  // Only active on idle/error step so it doesn't fire during analysis
  // Uses quick 8-result search only - full search is doSearch's responsibility
  // cancelled flag prevents stale results from a superseded call writing to state
  useEffect(() => {
    if (step !== "idle" && step !== "error") return;
    const q = query.trim();
    if (q.length < 3) { setOccs([]); setPickerLoading(false); return; }
    clearTimeout(debounceRef.current);
    setPickerLoading(true);
    let cancelled = false;
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await searchOccupations(q, "8");
        if (!cancelled) setOccs(res);
      } catch(_) { if (!cancelled) setOccs([]); }
      if (!cancelled) setPickerLoading(false);
    }, 420);
    return () => { cancelled = true; clearTimeout(debounceRef.current); };
  }, [query, step]);

  const reset = () => { pickerCancelRef.current = true; setNoExactMatch(null); setStep("idle"); setOccs([]); setSel(null); setResult(null); setErr(""); setQuery(""); setSub(""); setSubStep(0); setActiveTab("skills"); comparisonsRef.current = []; setComparisons([]); setCompareCue(false); setFromPath(null); };
  // softReset preserves comparison cache - used when adding a role to compare
  const softReset = (savedComparisons) => {
    const readyCount = savedComparisons.filter(c => c.result && c.result.skills).length;
    setStep("idle"); setOccs([]); setSel(null); setResult(null); setErr("");
    setQuery(""); setSub(""); setSubStep(0); setCompareCue(false);
    // Preserve compare tab if comparison is ready - don't snap back to skills
    if (readyCount < 2) setActiveTab("skills");
    comparisonsRef.current = savedComparisons; setComparisons(savedComparisons); setFromPath(null);
  };

  // Show warning before clearing comparison - only if comparison has ready results
  const confirmIfComparing = (onConfirm) => {
    const hasReadyComparisons = comparisonsRef.current.filter(c => c.result && c.result.skills).length >= 2;
    if (hasReadyComparisons) {
      setCompareWarning({ onConfirm });
    } else {
      onConfirm();
    }
  };

  const addToComparison = (title, res) => {
    setComparisons(prev => {
      if (prev.find(c => c.title === title)) return prev;
      if (prev.length >= 3) return prev;
      const next = [...prev, { title, result: res }];
      comparisonsRef.current = next;
      return next;
    });
  };

  const removeFromComparison = (title) => {
    setComparisons(prev => prev.filter(c => c.title !== title));
  };

  const doSearch = useCallback(async () => {
    if (!query.trim()) return;
    const tidyQuery = toTitleCase(query.trim());
    setQuery(tidyQuery);
    setShowExpect(true);
    setTimeout(() => setShowExpect(false), 2200);
    setErr("");
    track("occupation_searched");
    // v6: if debounce already fetched results, use them immediately
    if (occs.length > 0 && !pickerLoading) {
      if (occs.length === 1) { track("occupation_selected", { auto: true }); doAnalyse(occs[0]); return; }
      setStep("picking"); return;
    }
    setStep("searching");
    pickerCancelRef.current = true; // cancel any in-flight background full search
    setNoExactMatch(null);
    try {
      // v1.3.0: quick search returns 8 results fast - show picker immediately
      const quick = await searchOccupations(tidyQuery, "8");
      if (!quick.length) { setErr("no occupations found"); setStep("error"); return; }
      if (quick.length === 1) { setOccs(quick); track("occupation_selected", { auto: true }); doAnalyse(quick[0]); return; }
      setOccs(quick); setStep("picking");
      // Background: load full results (15-20) and merge into picker
      pickerCancelRef.current = false; // new search started, allow this background load
      const thisCancel = pickerCancelRef;
      setPickerFullLoading(true);
      searchOccupations(tidyQuery, "15 to 20").then(full => {
        if (thisCancel.current) { setPickerFullLoading(false); return; }
        if (full.length > quick.length) {
          const quickTitles = new Set(quick.map(o => o.title.toLowerCase()));
          const additional = full.filter(o => !quickTitles.has(o.title.toLowerCase()));
          setOccs([...quick, ...additional]);
        }
        setPickerFullLoading(false);
      }).catch(() => setPickerFullLoading(false));
    } catch(e) { setErr(e.message); setStep("error"); }
  }, [query, occs, pickerLoading]);

  const doAnalyse = useCallback(async (occ) => {
    setSel(occ); setStep("loading"); setSub(`Finding the essential skills for ${toTitleCase(occ.title)}...`); setSubStep(1); setResult(null); setErr("");
    setShowExpect(false);
    const total = persona ? 4 : 3;

    // Safety timeout: if the full analysis has not completed in 120s, surface an error
    // rather than leaving the user on an infinite spinner
    let analysisComplete = false;
    const safetyTimer = setTimeout(() => {
      if (!analysisComplete) {
        setErr("This one is taking longer than expected. Please try again - it usually resolves on the second attempt.");
        setStep("error");
      }
    }, 120000);

    try {
      const skills = await getSkills(occ.title, occ.iscoGroup || "", occ.iscoCode || "");
      setSub(`Rating ${skills.length} skills against current AI capability...`); setSubStep(2);

      // Fire rateSkills and progression/crossover/context in parallel after getSkills
      // Progression/crossover/context only need the title and group - no dependency on ratings
      setSub(`Analysing skills and mapping career paths for ${toTitleCase(occ.title)}...`); setSubStep(2);
      const [ratings, progressionData, crossoverData, contextData] = await Promise.all([
        rateSkills(occ.title, skills),
        getProgressionPaths(occ.title, occ.iscoGroup),
        getCrossoverRoles(occ.title, skills),
        getRoleContext(occ.title, skills, occ.iscoGroup),
      ]);

      const merged = skills.map(s => {
        const r = ratings.find(x => x.n === s.n) || {};
        return { n:s.n, skill:s.skill, type:s.type, level:r.level||"HUMAN", tool:r.tool||"NA", how:r.how||"", kickstart:r.kickstart||"", prompt:"", promptTech:"", nextPhase:"", promptLoading:r.level !== "HUMAN", promptFailed:false, skillType:r.skillType||"technical", prep:r.prep||"", twoStep:r.twoStep||false, readiness:r.readiness||"ready" };
      });
      let foundationData = null;
      if (persona) {
        setSub("Building your personalised foundation skills plan..."); setSubStep(3);
        foundationData = await getFoundationSkills(occ.title, merged, persona);
      }
      const newResult = { iscoGroup:occ.iscoGroup||"", description:occ.description||"", skills:merged, foundationData, progressionData, crossoverData, contextData };
      setResult(newResult);
      track("analysis_completed", { occupation: occ.title });
      if (comparisonsRef.current.length > 0) {
        addToComparison(toTitleCase(occ.title), newResult);
        setTimeout(() => {
          setCompareCue(true);
          setTimeout(() => setCompareCue(false), 3000);
          setTimeout(() => compareRef.current?.scrollIntoView({ behavior:"smooth", block:"start" }), 800);
        }, 400);
      }
      setActiveTab("skills");
      analysisComplete = true;
      clearTimeout(safetyTimer);
      setStep("results");

      // Background prompt enrichment - 3 skills at a time, patches UI progressively
      const promptTimeout = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("prompt_timeout")), 60000)
      );

      const patchBatch = (batchResults) => {
        if (!batchResults.length) return;
        setResult(prev => {
          if (!prev) return prev;
          const enriched = prev.skills.map(s => {
            const px = batchResults.find(p => p.n === s.n);
            if (!px) return s;
            return { ...s, prompt: px.p || px.prompt || "", promptTech: px.pt || px.promptTech || "", nextPhase: px.nx || px.nextPhase || "", promptLoading: false };
          });
          return { ...prev, skills: enriched };
        });
      };

      Promise.race([generatePrompts(occ.title, skills, ratings, patchBatch), promptTimeout]).then(() => {
        // Final pass: clear any remaining promptLoading flags
        setResult(prev => {
          if (!prev) return prev;
          return { ...prev, skills: prev.skills.map(s => ({ ...s, promptLoading: false })) };
        });
      }).catch(e => {
        const isTimeout = e.message === "prompt_timeout";
        console.warn("[generatePrompts] background enrichment", isTimeout ? "timed out" : "failed:", e.message);
        setResult(prev => {
          if (!prev) return prev;
          return { ...prev, skills: prev.skills.map(s => ({
            ...s,
            promptLoading: false,
            promptFailed: s.promptLoading ? (isTimeout ? "timeout" : "error") : s.promptFailed,
          })) };
        });
      });
      // hasAnalysedOnce is set in useEffect after first render - see below
    } catch(e) { analysisComplete = true; clearTimeout(safetyTimer); setErr(e.message); setStep("error"); }
  }, [persona]);

  // Called when user clicks "Analyse this role" on a progression or crossover card
  const handleAnalyseRole = useCallback(async (roleTitle, pathType) => {
    const doIt = async () => {
      const tidyRole = toTitleCase(roleTitle.trim());
      setQuery(tidyRole);
      setFromPath(pathType || "progression");
      window.scrollTo({ top: 0, behavior: "smooth" });
      setResult(null); setOccs([]); setErr("");
      setActiveTab("skills");
      setStep("searching");
      try {
        const res = await searchOccupations(tidyRole);
        const exact = res.find(r => r.title.toLowerCase() === tidyRole.toLowerCase());
        const occ = exact || res[0] || { title: tidyRole, iscoCode: "", iscoGroup: "", description: "" };
        occ.title = tidyRole;
        doAnalyse(occ);
      } catch(e) {
        doAnalyse({ title: tidyRole, iscoCode: "", iscoGroup: "", description: "" });
      }
    };
    confirmIfComparing(doIt);
  }, [doAnalyse]);

  // Queue a role for comparison without running analysis yet
  const handleQueueRole = useCallback((roleTitle) => {
    track("comparison_queued");
    const tidyRole = toTitleCase(roleTitle.trim());
    setComparisons(prev => {
      const currentTitle = sel ? toTitleCase(sel.title) : null;
      const currentResult = result;
      let base = [...prev];
      if (currentTitle && currentResult && !base.find(c => c.title === currentTitle)) {
        base = [{ title: currentTitle, result: currentResult }, ...base];
      }
      if (base.find(c => c.title === tidyRole)) return base;
      if (base.length >= 3) return base;
      const next = [...base, { title: tidyRole, result: null }];
      comparisonsRef.current = next;
      // If this is the 3rd role, scroll to run button after state updates
      if (next.length >= 3) {
        setTimeout(() => {
          queueBannerRef.current?.scrollIntoView({ behavior:"smooth", block:"center" });
        }, 150);
      }
      return next;
    });
  }, [sel, result]);

  // Elapsed timer during comparison - messages are set directly in runQueuedComparisons
  useEffect(() => {
    if (!isRunningComparison) { setCompareStatus(""); setCompareStep(0); setCompareElapsed(0); return; }
    let secs = 0;
    const tick = setInterval(() => { secs++; setCompareElapsed(secs); }, 1000);
    return () => clearInterval(tick);
  }, [isRunningComparison]);

  // Set hasAnalysedOnce AFTER the first result renders
  // Using useEffect ensures components receive firstAnalysis=true on first render,
  // then false from the second search onward
  useEffect(() => {
    if (step === "results" && !hasAnalysedOnce.current) {
      const id = setTimeout(() => { hasAnalysedOnce.current = true; }, 800);
      return () => clearTimeout(id);
    }
  }, [step]);

  // Back-to-top: show button after scrolling 400px
  useEffect(() => {
    const onScroll = () => setShowBackTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleSkillSearch = async (query) => {
    if (!query.trim() || !result) return;
    setSkillInputResult({ status:"loading" });
    const skills = result.skills || [];
    const raw = await claudeCall(
`User typed: "${query.trim()}"
Role: ${sel?.title || "unknown"}
Skills in this role: ${skills.map(s => `${s.skill} (${s.level})`).join(", ")}
Identify if the input matches or relates to any skill in the list.
Return ONLY a JSON object. No text before or after. No markdown.
{"match":"exact skill name from list or empty string","close":"closest skill name if no exact match or empty","explanation":"one sentence about this skill in this role context","suggestion":"if input unclear or not in English - a gentle plain English clarification request","unrelated":false}
Keep all values under 30 words. No quote characters inside values.`, 280);
    const obj = extractJSON(raw, "skillsearch");
    if (!obj) { setSkillInputResult({ status:"error" }); return; }
    setSkillInputResult({
      status: obj.match ? "match" : obj.unrelated ? "unrelated" : obj.close ? "close" : "suggestion",
      match: obj.match || "",
      close: obj.close || "",
      explanation: obj.explanation || "",
      suggestion: obj.suggestion || "",
    });
  };

  const runQueuedComparisons = useCallback(async () => {
    const pending = comparisonsRef.current.filter(c => !c.result);
    if (!pending.length) return;
    setIsRunningComparison(true);
    setTimeout(() => compareRef.current?.scrollIntoView({ behavior:"smooth", block:"start" }), 100);

    const totalRoles = pending.length;
    let globalStep = 0;
    const totalSteps = totalRoles * 3 + 2; // 3 steps per role + career paths + comparison

    const step = (msg) => { globalStep++; setCompareStep(globalStep); setCompareStatus(msg); };

    const analyseOne = async (c, roleIndex) => {
      try {
        const roleLabel = toTitleCase(c.title);
        step(`Finding essential skills for ${roleLabel}...`);
        const res = await searchOccupations(c.title);
        const exact = res.find(r => r.title.toLowerCase() === c.title.toLowerCase());
        const occ = exact || res[0] || { title: c.title, iscoCode: "", iscoGroup: "", description: "" };
        occ.title = c.title;
        const skills = await getSkills(occ.title, occ.iscoGroup || "", occ.iscoCode || "");
        step(`Rating ${skills.length} skills for ${roleLabel} against AI...`);
        // Use compact rater for comparison - skips prompt/prep/twoStep to reduce latency ~40%
        const ratings = await rateSkillsCompact(occ.title, skills);
        const merged = skills.map(s => {
          const r = ratings.find(x => x.n === s.n) || {};
          return { n:s.n, skill:s.skill, type:s.type, level:r.level||"HUMAN", tool:r.tool||"NA", how:r.how||"", kickstart:"", prompt:"", skillType:r.skillType||"technical", prep:"", twoStep:false, readiness:"ready" };
        });
        step(`Mapping career paths for ${roleLabel}...`);
        // Skip progression/crossover/context if role already has full result data
        // This saves 8-12s per role and prevents 3-role timeout on Vercel 60s limit
        let progressionData, crossoverData, contextData;
        if (c.result && c.result.progressionData) {
          progressionData = c.result.progressionData;
          crossoverData   = c.result.crossoverData || [];
          contextData     = c.result.contextData || null;
        } else {
          [progressionData, crossoverData, contextData] = await Promise.all([
            getProgressionPaths(occ.title, occ.iscoGroup),
            getCrossoverRoles(occ.title, merged),
            getRoleContext(occ.title, merged, occ.iscoGroup),
          ]);
        }
        return { title: c.title, result: { iscoGroup:occ.iscoGroup||"", description:occ.description||"", skills:merged, progressionData, crossoverData, contextData } };
      } catch(e) {
        return { title: c.title, result: null };
      }
    };

    const analyseWithUpdate = async (c, roleIndex) => {
      const r = await analyseOne(c, roleIndex);
      setComparisons(prev => {
        const updated = prev.map(p =>
          p.title === r.title ? { title: p.title, result: r.result, failed: !r.result } : p
        );
        comparisonsRef.current = updated;
        return updated;
      });
      return r;
    };

    const results = [];
    for (let i = 0; i < pending.length; i++) {
      const r = await analyseWithUpdate(pending[i], i);
      results.push(r);
    }
    step("Building comparison...");
    setIsRunningComparison(false);
    track("comparison_completed");
    setActiveTab("compare");
    setTimeout(() => tabBarRef.current?.scrollIntoView({ behavior:"smooth", block:"start" }), 150);
    showToast("Comparison ready", null);
  }, []);

  const buildTabs = (r) => {
    if (!r) return [];
    return [
      { key:"skills",      label:"📋 Skill Detail",         color:C.muted   },
      ...(r.foundationData ? [{ key:"foundation", label:`${safePersona(persona).icon||"🎓"} Foundation Skills`, color:safePersona(persona).color||C.green }] : []),
      { key:"progression", label:"⬆️ Career Progression",   color:"#1a56db" },
      { key:"crossover",   label:"🔄 Role Crossover",        color:C.green   },
      { key:"category",    label:"🗂 Skill Categories",      color:C.teal    },
      { key:"context",     label:"🏢 Role Context",           color:"#0e7490" },
      { key:"compare",     label:"⚖️ Compare",                 color:"#1a56db" },
    ];
  };

  return (
    <>
    <style>{`
      *, *::before, *::after { box-sizing: border-box; }
      html { margin: 0; padding: 0; width: 100%; height: 100%; overflow-x: hidden; font-size: 16px; }
      body { margin: 0; padding: 0; width: 100%; min-height: 100%; overflow-x: hidden; -webkit-text-size-adjust: 100%; }
      #root { width: 100%; max-width: 100vw; overflow-x: hidden; }
      img, video { max-width: 100%; }
      :root {
        --app-height: 100svh;
        --content-pad: 12px;
        --content-max: 820px;
        --base-font: 14px;
      }
      @supports (height: 100svh) {
        :root { --app-height: 100svh; }
      }
      @media (min-width: 600px) { :root { --content-pad: 20px; } }
      .site-title { white-space: nowrap; font-size: 14px; }
      @media (min-width: 768px) { .site-title { font-size: 16px; } }
      @media (max-width: 479px) { .site-title { white-space: normal; font-size: 13px; } }
      @media (min-width: 900px)  { :root { --content-pad: 32px; --content-max: 900px; } }
      @media (min-width: 1200px) { :root { --content-max: 1000px; } }
      @media (min-width: 1600px) { :root { --content-max: 1080px; } }
      @media (min-width: 2000px) { :root { --content-max: 1200px; --base-font: 17px; } html { font-size: 18px; } }
      @media (min-width: 2560px) { :root { --content-max: 1320px; --base-font: 18px; } html { font-size: 20px; } }
      .main-content { max-width: var(--content-max); margin: 0 auto; padding: var(--content-pad) 16px; }
      @media (min-width: 600px) { .main-content { padding: var(--content-pad); } }
      /* Tablet and notebook font scaling */
      @media (min-width: 768px) {
        body { font-size: 15px; }
        .t-body { font-size: 15px !important; }
        .t-label { font-size: 13px !important; }
        .t-meta { font-size: 12px !important; }
        .t-heading { font-size: 18px !important; }
        .t-sub { font-size: 13px !important; }
      }
      @media (min-width: 1024px) {
        body { font-size: 16px; }
        .t-body { font-size: 16px !important; }
        .t-label { font-size: 14px !important; }
        .t-meta { font-size: 13px !important; }
        .t-heading { font-size: 20px !important; }
        .t-sub { font-size: 14px !important; }
        .result-text-sm { font-size: 13px !important; }
        .result-text-xs { font-size: 12px !important; }
        .result-label { font-size: 12px !important; }
      }
      @media (min-width: 1280px) {
        body { font-size: 16px; }
        .t-body { font-size: 16px !important; }
        .t-label { font-size: 14px !important; }
        .t-meta { font-size: 13px !important; }
        .t-heading { font-size: 21px !important; }
        .t-sub { font-size: 14px !important; }
        .result-text-sm { font-size: 13px !important; }
        .result-text-xs { font-size: 12px !important; }
        .result-label { font-size: 12px !important; }
      }
      /* Retina MacBook 1200-1440 CSS px: tab label lift */
      @media (min-width: 1200px) and (max-width: 1500px) {
        .main-content .tab-label { font-size: 13px !important; }
      }
      /* 2K and 4K scaling - font-size on html cascades via rem */
      @media (min-width: 2000px) {
        body { font-size: 18px; }
        .t-body { font-size: 18px !important; }
        .t-label { font-size: 15px !important; }
        .t-meta { font-size: 14px !important; }
        .t-heading { font-size: 24px !important; }
        .t-sub { font-size: 16px !important; }
        .result-text-sm { font-size: 15px !important; }
        .result-text-xs { font-size: 13px !important; }
        .result-label { font-size: 13px !important; }
      }
      @media (min-width: 2560px) {
        body { font-size: 20px; }
        .t-body { font-size: 20px !important; }
        .t-label { font-size: 17px !important; }
        .t-meta { font-size: 15px !important; }
        .t-heading { font-size: 28px !important; }
        .t-sub { font-size: 17px !important; }
        .result-text-sm { font-size: 16px !important; }
        .result-text-xs { font-size: 14px !important; }
        .result-label { font-size: 14px !important; }
      }
      @keyframes sp { to { transform: rotate(360deg); } }
      @keyframes fadeOut { 0% { opacity:1; } 70% { opacity:1; } 100% { opacity:0; } }
    `}</style>
    <div data-author="Adrian K. L. Ang" data-origin="takearoundabout.com" data-build="v5-2026"
      style={{ minHeight:"var(--app-height, 100svh)", background:C.bg, color:C.text, fontFamily:"'IBM Plex Sans','Segoe UI',sans-serif", width:"100%", maxWidth:"100vw", overflowX:"hidden", position:"relative" }}>
      {/* © Adrian K. L. Ang | takearoundabout.com | Original source - unauthorised redistribution is not permitted */}

      {compareWarning && (
        <CompareWarningModal
          onConfirm={() => {
            comparisonsRef.current = [];
            setComparisons([]);
            setCompareWarning(null);
            compareWarning.onConfirm();
          }}
          onCancel={() => setCompareWarning(null)}
        />
      )}
      <div style={{ background:C.eu, padding:"10px 16px", display:"flex", alignItems:"center", gap:10, width:"100%", boxSizing:"border-box" }}>
        <span style={{ color:C.euStar, fontSize:18, flexShrink:0 }}>★</span>
        <div style={{ flex:1, minWidth:0 }}>
          <h1 style={{ margin:0, fontSize:13, fontWeight:700, color:"#ffffff", lineHeight:1.35 }} className="site-title">AI Potential Across Role Functions</h1>
        </div>
        {step !== "idle" && (
          <button onClick={reset} style={{ background:"rgba(255,255,255,0.15)", border:"1px solid rgba(255,255,255,0.35)", borderRadius:6, color:"#fff", padding:"5px 12px", cursor:"pointer", fontSize:12, whiteSpace:"nowrap", flexShrink:0 }}>
            New Search
          </button>
        )}
      </div>

      {/* Toast notification */}
      {/* Back to top button - appears after 400px scroll, right-anchored */}
      {showBackTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
          style={{
            position: "fixed", bottom: 24, right: 18, zIndex: 998,
            display: "flex", alignItems: "center", gap: 5,
            padding: "7px 13px 7px 10px",
            background: "rgba(26,86,219,0.92)", backdropFilter: "blur(6px)",
            border: "none", borderRadius: 20,
            color: "#fff", fontSize: 12, fontWeight: 700,
            cursor: "pointer", boxShadow: "0 2px 12px rgba(0,0,0,0.18)",
            animation: "fadeInUp 0.25s ease",
            userSelect: "none",
          }}>
          <span style={{ fontSize: 14, lineHeight: 1 }}>↑</span>
          <span>Top</span>
        </button>
      )}

      {toast && (
        <div style={{ position:"fixed", bottom:24, left:"50%", transform:"translateX(-50%)", zIndex:999, background:"#1a56db", color:"#fff", borderRadius:10, padding:"12px 20px", fontSize:13, fontWeight:600, boxShadow:"0 4px 20px rgba(0,0,0,0.18)", display:"flex", alignItems:"center", gap:12, maxWidth:"90vw", animation:"slideUp 0.3s ease" }}>
          <span>{toast.msg}</span>
          {toast.action === "compare" && (
            <button onClick={() => { setActiveTab("compare"); setToast(null); track("tab_viewed", { tab:"compare" }); }}
              style={{ background:"rgba(255,255,255,0.2)", border:"1px solid rgba(255,255,255,0.4)", borderRadius:6, color:"#fff", padding:"4px 12px", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>
              View comparison →
            </button>
          )}
          <button onClick={() => setToast(null)} style={{ background:"transparent", border:"none", color:"rgba(255,255,255,0.7)", fontSize:18, cursor:"pointer", padding:0, lineHeight:1, flexShrink:0 }}>×</button>
        </div>
      )}
      <div className="main-content">

        {(step === "idle" || step === "error") && (
          <>
            {/* Search box - TOP of screen, first thing user sees */}
            <div style={{ background:C.surface, border:`2px solid ${C.accent}`, borderRadius:10, padding:14, marginBottom:10 }}>

              <div style={{ display:"flex", gap:8 }}>
                <input type="text" value={query} onChange={e=>{ setQuery(e.target.value); }} onKeyDown={e=>e.key==="Enter"&&doSearch()}
                  placeholder='Enter a job title to begin...'
                  style={{ flex:1, background:C.bg, border:`1px solid ${C.border}`, borderRadius:7, color:C.text, padding:"11px 13px", fontSize:16, outline:"none", fontFamily:"inherit" }} autoFocus />
                <button onClick={doSearch} style={{ background:C.eu, border:"none", borderRadius:7, color:"#fff", padding:"11px 22px", fontSize:13, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>
                  Search
                </button>
              </div>
              {/* v6: progressive picker - shows as user types, before pressing Analyse */}
              {query.trim().length >= 3 && (step === "idle" || step === "error") && (
                <div style={{ marginTop:8 }}>
                  {pickerLoading && (
                    <p style={{ fontSize:11, color:C.muted, margin:"4px 0" }}>Finding roles matching "{query.trim()}"...</p>
                  )}
                  {!pickerLoading && occs.length > 0 && (
                    <div>
                      <p style={{ fontSize:11, color:C.muted, margin:"0 0 5px" }}>
                        {occs.length} result{occs.length!==1?"s":""} — select one to analyse, or press Analyse to continue
                      </p>
                      {occs.slice(0,5).map((o,i) => (
                        <div key={i} onClick={() => { track("occupation_selected",{auto:false}); doAnalyse(o); }}
                          style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:7, padding:"9px 13px", marginBottom:4, cursor:"pointer", display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:8, transition:"all 0.12s" }}
                          onMouseEnter={e=>{ e.currentTarget.style.background=C.accentSoft; e.currentTarget.style.borderColor=C.accent; }}
                          onMouseLeave={e=>{ e.currentTarget.style.background=C.surface; e.currentTarget.style.borderColor=C.border; }}>
                          <div style={{ flex:1 }}>
                            <p style={{ margin:"0 0 2px", fontSize:13, fontWeight:600, color:C.text }}>{toTitleCase(o.title)}</p>
                            <p style={{ margin:0, fontSize:11, color:C.muted, lineHeight:1.4 }}>
                              {o.iscoCode && <span style={{ color:C.mutedLight }}>ISCO-08: {o.iscoCode} · </span>}
                              {(o.description||"").slice(0,90)}{(o.description||"").length>90?"...":""}
                            </p>
                          </div>
                          {o.isAltLabel && <span style={{ fontSize:9, fontWeight:700, color:C.accent, background:C.accentSoft, border:`1px solid #c3d3f5`, borderRadius:8, padding:"2px 6px", whiteSpace:"nowrap", flexShrink:0 }}>alt</span>}
                        </div>
                      ))}
                      {occs.length > 5 && (
                        <p style={{ fontSize:11, color:C.muted, margin:"4px 0 0", textAlign:"center" }}>
                          +{occs.length - 5} more — press Analyse to see all results
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
              <p style={{ margin:"8px 0 0", fontSize:11, color:C.muted, lineHeight:1.5 }}>
                Use 1 to 3 words for best results - e.g.{" "}
                <span style={{ color:C.textSub }}>HR Manager</span>,{" "}
                <span style={{ color:C.textSub }}>Physician</span>,{" "}
                <span style={{ color:C.textSub }}>Chief Executive Officer</span>,{" "}
                <span style={{ color:C.textSub }}>Software Developer</span>
              </p>
              {showExpect ? (
                <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:8, padding:"8px 10px", background:C.accentSoft, border:`1px solid #c3d3f5`, borderRadius:7 }}>
                  <span style={{ width:12, height:12, border:"2px solid #c3d3f5", borderTop:`2px solid ${C.accent}`, borderRadius:"50%", display:"inline-block", animation:"sp 0.7s linear infinite", flexShrink:0 }} />
                  <p style={{ margin:0, fontSize:12, color:C.accent, lineHeight:1.5, fontWeight:600 }}>
                    Looking up your role - analysis on the way
                  </p>
                </div>
              ) : (
                <p style={{ margin:"6px 0 0", fontSize:12, color:C.textSub, lineHeight:1.6 }}>
                  Results are indicative - a starting point, not a final assessment.
                </p>
              )}
              {step === "error" && <div style={{ marginTop:10 }}><ErrBox msg={err || "Something went wrong. Please try again."} query={query} /></div>}
            </div>
            {/* Intro card - below search box */}
            <IntroCard onPersonaSelect={setPersona} toggleRef={toggleRef} />
            {/* Persona toggle - after intro card */}
            <div ref={toggleRef}><PersonaToggle persona={persona} onChange={setPersona} /></div>
            <CommunityNote />
            <Tagline />
            <DeviceNote />
          </>
        )}

        {step === "searching" && <Spinner label={`Searching for "${query}"...`} />}

        {step === "picking" && (() => {
          // Group by sector
          const sectors = [...new Set(occs.map(o => toTitleCase(o.industry || o.iscoGroup || "General")))].sort();
          const grouped = sectors.map(s => ({ sector: s, items: occs.filter(o => toTitleCase(o.industry || o.iscoGroup || "General") === s) }));
          const singleSector = grouped.length <= 1;
          return (
          <OccupationPicker
            occs={occs}
            grouped={grouped}
            singleSector={singleSector}
            query={query}
            persona={persona}
            pickerFullLoading={pickerFullLoading}
            noExactMatch={noExactMatch}
            onSelect={(o) => { track("occupation_selected", { auto: false }); doAnalyse(o); }}
            onSearchAgain={async (newQuery) => {
              const tidy = toTitleCase(newQuery.trim());
              setQuery(tidy);
              setStep("searching");
              setOccs([]);
              setPickerFullLoading(false);
              try {
                const quick = await searchOccupations(tidy, "8");
                if (!quick.length) { setErr("no occupations found"); setStep("error"); return; }
                if (quick.length === 1) { doAnalyse(quick[0]); return; }
                setOccs(quick); setStep("picking");
                setPickerFullLoading(true);
                searchOccupations(tidy, "15 to 20").then(full => {
                  if (full.length > quick.length) {
                    const qt = new Set(quick.map(o => o.title.toLowerCase()));
                    setOccs([...quick, ...full.filter(o => !qt.has(o.title.toLowerCase()))]);
                  }
                  setPickerFullLoading(false);
                }).catch(() => setPickerFullLoading(false));
              } catch(e) { setErr(e.message); setStep("error"); }
            }}
          />
          );
        })()}

        {step === "loading" && <Spinner label={sub || "Loading..."} step={subStep} total={persona ? 4 : 3} />}

        {/* Standalone compare view - shown when step=idle but comparisons are ready */}
        {(step === "idle" || step === "picking" || step === "searching") &&
          comparisons.filter(c => c.result && c.result.skills).length >= 2 &&
          activeTab === "compare" && (
            <div style={{ marginTop:8 }}>
              <div style={{ marginBottom:14 }}>
                <p style={{ margin:"0 0 8px", fontSize:11, color:C.muted }}>Tap or click a tab below to explore the results:</p>
                <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                  <button onClick={() => setActiveTab("compare")}
                    style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"7px 14px",
                      borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer",
                      border:"2px solid #1a56db", background:"#1a56db", color:"#fff", whiteSpace:"nowrap" }}>
                    {"⚖️ Compare (" + comparisons.filter(c => c.result && c.result.skills).length + ")"}
                  </button>
                  <button onClick={() => setActiveTab("skills")}
                    style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"7px 14px",
                      borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer",
                      border:`2px solid ${C.border}`, background:C.surface, color:C.textSub, whiteSpace:"nowrap" }}>
                    ← Back to last role
                  </button>
                </div>
              </div>
              <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"15px 18px", marginBottom:16 }}>
                <h2 className="t-heading" style={{ margin:"0 0 4px", fontSize:19, fontWeight:800, color:C.text }}>⚖️ Role Comparison</h2>
                
              </div>
              <ComparisonPanel
                comparisons={comparisons}
                onRemove={removeFromComparison}
                onAnalyse={handleAnalyseRole}
                currentTitle={""}
                onAddThird={null}
              />
            </div>
        )}

        {step === "results" && sel && result && (() => {
          const tabs = buildTabs(result);
          return (
            <div>
              <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"15px 18px", marginBottom:16 }}>
                <h2 className="t-heading" style={{ margin:"0 0 5px", fontSize:19, fontWeight:800, color:C.text }}>{toTitleCase(sel.title)}</h2>
                {result.description && <p style={{ margin:0, fontSize:13, color:C.textSub, lineHeight:1.6 }}>{result.description}</p>}
                {result.iscoGroup && <p style={{ margin:"6px 0 0", fontSize:10, color:C.mutedLight }}>ESCO v1.2.1 · {result.iscoGroup}</p>}
                {/* Compare section - clean hierarchy, max 3 total */}
                {(() => {
                  const currentTitle = toTitleCase(sel.title);
                  const alreadyIn = comparisons.find(c => c.title === currentTitle);
                  // Current role always counts as slot 1 even before explicitly added
                  const effectiveTotal = comparisons.length + (alreadyIn ? 0 : 1);
                  const atLimit = effectiveTotal >= 3;
                  const inSession = comparisonsRef.current.length >= 1;
                  const readyCount = comparisons.filter(c => c.result && c.result.skills).length;
                  return (
                    <div style={{ marginTop:10 }}>
                      {/* Role pills showing queued/added roles */}
                      {comparisons.length > 0 && (
                        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:8 }}>
                          {comparisons.map((c, i) => (
                            <span key={i} style={{ fontSize:10, color: c.result ? C.green : C.accent, background: c.result ? C.greenBg : C.accentSoft, border:`1px solid ${c.result ? C.greenBdr : "#c3d3f5"}`, borderRadius:12, padding:"2px 8px", display:"inline-flex", alignItems:"center", gap:4 }}>
                              {c.result ? "✓" : "⏳"} {c.title}
                              <button onClick={() => removeFromComparison(c.title)} style={{ background:"transparent", border:"none", fontSize:11, color:C.mutedLight, cursor:"pointer", padding:0, lineHeight:1 }}>×</button>
                            </span>
                          ))}
                          {atLimit && <span style={{ fontSize:10, color:C.muted, fontStyle:"italic", alignSelf:"center" }}>3 roles maximum</span>}
                        </div>
                      )}
                      {/* Action buttons row */}
                      <div style={{ display:"flex", gap:8, flexWrap:"wrap", alignItems:"center" }}>
                        {/* Add current role button - only when not at limit and not already added */}
                        {!alreadyIn && !atLimit && (
                          <button onClick={() => {
                              const updated = [...comparisons, { title: currentTitle, result }];
                              softReset(updated);
                            }}
                            style={{ fontSize:11, fontWeight:700, color: inSession ? "#fff" : C.accent, background: inSession ? C.accent : C.accentSoft, border:`1px solid ${inSession ? C.accent : "#c3d3f5"}`, borderRadius:20, padding:"5px 14px", cursor:"pointer" }}>
                            {inSession ? "＋ Add this role to comparison" : "＋ Start comparison with this role"}
                          </button>
                        )}
                        {/* View comparison button - when 2+ ready */}
                        {readyCount >= 2 && (
                          <button onClick={() => {
                              setActiveTab("compare");
                              track("tab_viewed", { tab:"compare" });
                              setTimeout(() => tabBarRef.current?.scrollIntoView({ behavior:"smooth", block:"start" }), 80);
                            }}
                            style={{ fontSize:11, fontWeight:700, color:"#fff", background:"#0e7490", border:"none", borderRadius:20, padding:"5px 14px", cursor:"pointer" }}>
                            ⚖️ View comparison →
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })()}
                {persona && result.foundationData && (
                  <div style={{ marginTop:8, padding:"5px 10px", borderRadius:6, background:safePersona(persona).bg, border:`1px solid ${safePersona(persona).border}` }}>
                    <span style={{ fontSize:11, color:safePersona(persona).color }}>
                      {safePersona(persona).icon} <strong>{safePersona(persona).label}</strong> - foundation skills included
                    </span>
                  </div>
                )}

              </div>

              {/* Queued comparison banner */}
              {comparisons.filter(c => !c.result).length > 0 && (() => {
                // Total includes current role (which already has a result) + pending roles
                const pendingCount = comparisons.filter(c => !c.result).length;
                const totalCount = comparisons.length;
                return (
                <div ref={queueBannerRef} style={{ background:"#e8f0fe", border:"1px solid #c3d3f5", borderRadius:8, padding:"10px 14px", marginBottom:12, display:"flex", alignItems:"center", justifyContent:"space-between", gap:10, flexWrap:"wrap" }}>
                  <div>
                    <p style={{ margin:0, fontSize:12, fontWeight:700, color:C.accent }}>
                      ⚖️ {totalCount} role{totalCount !== 1 ? "s" : ""} queued to compare
                    </p>
                    <p style={{ margin:"2px 0 4px", fontSize:11, color:C.textSub }}>
                      Comparing: {comparisons.map(c => c.title).join(" vs ")}
                    </p>
                    {isRunningComparison && compareStatus && (
                      <p style={{ margin:"0 0 6px", fontSize:10, color:C.accent, fontStyle:"italic" }}>
                        Step {compareStep} - {compareStatus}
                      </p>
                    )}
                    {!isRunningComparison && (
                      <p style={{ margin:"0 0 6px", fontSize:10, color:C.muted, fontStyle:"italic" }}>
                        Tap Run comparison to analyse all roles side by side.
                      </p>
                    )}
                    <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                      {comparisons.map((c, i) => (
                        <span key={i} style={{ fontSize:10, color: c.result ? "#166534" : C.accent, background: c.result ? "#f0fdf4" : "#fff", border:`1px solid ${c.result ? "#a7f3d0" : "#c3d3f5"}`, borderRadius:12, padding:"1px 8px", display:"inline-flex", alignItems:"center", gap:4 }}>
                          {c.result ? "✓" : "⏳"} {c.title}
                          {!c.result && <button onClick={() => removeFromComparison(c.title)} style={{ background:"transparent", border:"none", fontSize:11, color:C.mutedLight, cursor:"pointer", padding:0, lineHeight:1 }}>×</button>}
                        </span>
                      ))}
                    </div>
                  </div>
                  <button onClick={runQueuedComparisons}
                    disabled={isRunningComparison}
                    style={{ padding:"7px 16px", fontSize:12, fontWeight:700, color:"#fff", background: isRunningComparison ? C.muted : C.accent, border:"none", borderRadius:6, cursor: isRunningComparison ? "not-allowed" : "pointer", flexShrink:0, display:"inline-flex", alignItems:"center", gap:6, opacity: isRunningComparison ? 0.8 : 1 }}>
                    {isRunningComparison
                      ? <><span style={{ width:11, height:11, border:"2px solid rgba(255,255,255,0.4)", borderTop:"2px solid #fff", borderRadius:"50%", display:"inline-block", animation:"sp 0.7s linear infinite", flexShrink:0 }} /> Analysing ({compareStep}/{comparisons.length * 3 + 1})...</>
                      : "▶ Run comparison"
                    }
                  </button>
                </div>
                );
              })()}
              <ExposureBar skills={result.skills} />
              <SkillSegments skills={result.skills} hasNoHuman={result.skills.every(s => s.level !== "HUMAN")} />

              <div ref={tabBarRef} style={{ marginBottom:14 }}>
                <p style={{ margin:"0 0 8px", fontSize:11, color:C.muted }}>
                  Tap or click a tab below to explore the results:
                </p>
                <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                  {tabs.map(t => {
                    const readyCount = comparisons.filter(c => c.result && c.result.skills).length;
                    const compareDisabled = t.key === "compare" && readyCount < 2;
                    const compareLabel = t.key === "compare"
                      ? (readyCount >= 2 ? `⚖️ Compare (${readyCount})` : "⚖️ Compare")
                      : t.label;
                    return (
                    <button key={t.key}
                      onClick={() => { if (!compareDisabled) { setActiveTab(t.key); track("tab_viewed", { tab: t.key }); } }}
                      title={compareDisabled ? "Add 2 or more roles to compare" : ""}
                      style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"7px 14px", borderRadius:20, fontSize:12, fontWeight:600,
                        cursor: compareDisabled ? "not-allowed" : "pointer",
                        border:`2px solid ${activeTab===t.key ? t.color : C.border}`,
                        background: compareDisabled ? C.bg : activeTab===t.key ? t.color : C.surface,
                        color: compareDisabled ? C.mutedLight : activeTab===t.key ? "#fff" : C.textSub,
                        opacity: compareDisabled ? 0.55 : 1,
                        transition:"all 0.15s", whiteSpace:"nowrap" }}>
                      {compareLabel}
                    </button>
                    );
                  })}
                </div>
              </div>

              {activeTab === "skills" && (() => {
                // Groups: Human-Led first (strength before risk)
                const groupDef = [
                  { level:"HUMAN",  label:"Human-Led",        sub:"Skills where human judgement, empathy, or presence remain essential - your distinct advantage.", color:"#166534", bg:"#f0fdf4", border:"#a7f3d0", icon:"🟢" },
                  { level:"LOW",    label:"AI-Assisted",       sub:"AI can support these skills but you remain in control. Good skills to use AI as a thinking partner.", color:C.accent,  bg:C.accentSoft, border:"#c3d3f5",  icon:"🔵" },
                  { level:"MEDIUM", label:"AI-Augmented",      sub:"These skills are significantly shaped by AI today. Understanding the tools gives you an edge.", color:"#d97706", bg:"#fffbeb", border:"#fcd9a0", icon:"🟡" },
                  { level:"HIGH",   label:"Full Automation",   sub:"AI can handle most of this independently today. Knowing this helps you focus your energy wisely.", color:"#c0392b", bg:"#fdecea", border:"#f5c6c2", icon:"🔴" },
                ];
                const grouped = groupDef.map(g => ({ ...g, skills: (result.skills||[]).filter(s => s.level === g.level) })).filter(g => g.skills.length > 0);
                return (
                <SkillGroupedView
                  grouped={grouped}
                  result={result}
                  onSearch={async (role) => {
                    const doIt = async () => {
                      const tidyRole = toTitleCase(role);
                      setQuery(tidyRole);
                      setStep("searching"); setErr("");
                      try {
                        const res = await searchOccupations(tidyRole);
                        if (!res.length) { setErr("no occupations found"); setStep("error"); return; }
                        const hasExact = res.some(r => r.title.toLowerCase() === tidyRole.toLowerCase());
                        const list = hasExact ? res : [{ title: tidyRole, iscoCode: "", iscoGroup: "", description: "Role extracted from prompt starter", isAltLabel: true }, ...res];
                        setOccs(list); setStep("picking"); window.scrollTo({ top:0, behavior:"smooth" });
                      } catch(e) { setErr(e.message); setStep("error"); }
                    };
                    confirmIfComparing(doIt);
                  }}
                  skillInputResult={skillInputResult}
                  skillInputQuery={skillInputQuery}
                  onSkillSearch={handleSkillSearch}
                  onSkillQueryChange={setSkillInputQuery}
                  firstAnalysis={!hasAnalysedOnce.current}
                  onQueue={handleQueueRole}
                  queueCount={comparisons.length + (comparisons.find(c => c.title === toTitleCase(sel?.title||"")) ? 0 : 1)}
                  currentRole={sel?.title || ""}
                />
                );
              })()}
              {activeTab === "foundation" && result.foundationData && (
                <FoundationPanel data={result.foundationData} persona={persona} />
              )}

              {activeTab === "progression" && result.progressionData && (
                <ProgressionPanel items={result.progressionData} skills={result.skills} onAnalyse={(r) => handleAnalyseRole(r, "progression")} onQueue={handleQueueRole} onQueueCount={comparisons.length + (comparisons.find(c => c.title === toTitleCase(sel?.title||"")) ? 0 : 1)} firstAnalysis={!hasAnalysedOnce.current} />
              )}

              {activeTab === "crossover" && result.crossoverData && (
                <CrossoverPanel items={result.crossoverData} skills={result.skills} onAnalyse={(r) => handleAnalyseRole(r, "crossover")} onQueue={handleQueueRole} onQueueCount={comparisons.length + (comparisons.find(c => c.title === toTitleCase(sel?.title||"")) ? 0 : 1)} firstAnalysis={!hasAnalysedOnce.current} />
              )}

              {activeTab === "category" && <CategoryPanel skills={result.skills} />}
              {activeTab === "context" && result.contextData && (
                <RoleContextPanel data={result.contextData} skills={result.skills} firstAnalysis={!hasAnalysedOnce.current} />
              )}
              {/* Compare tab content */}
              {activeTab === "compare" && (() => {
                const readyComps = comparisons.filter(c => c.result && c.result.skills);
                return (
                <div>
                  {/* Compare tab title */}
                  <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"15px 18px", marginBottom:16 }}>
                    <h2 className="t-heading" style={{ margin:"0 0 4px", fontSize:19, fontWeight:800, color:C.text }}>⚖️ Role Comparison</h2>
                    
                  </div>
                  {comparisons.length < 2 ? (
                    <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"32px 20px", textAlign:"center" }}>
                      <p style={{ margin:"0 0 8px", fontSize:15, color:C.textSub }}>You need at least 2 roles to compare.</p>
                      <p style={{ margin:0, fontSize:12, color:C.muted }}>Use the <strong>+ Add this role</strong> button or tap <strong>+ Compare</strong> on any career path card.</p>
                    </div>
                  ) : isRunningComparison ? (
                    <div style={{ background:"#f0f9ff", border:"1px solid #bae6fd", borderRadius:10, padding:"32px 20px", textAlign:"center" }}>
                      <div style={{ width:36, height:36, margin:"0 auto 14px", border:"3px solid #bae6fd", borderTop:"3px solid #1a56db", borderRadius:"50%", animation:"sp 0.7s linear infinite" }} />
                      <p style={{ margin:"0 0 6px", fontSize:13, fontWeight:700, color:"#0369a1" }}>Building comparison</p>
                      <p style={{ margin:"0 0 4px", fontSize:12, color:"#0369a1", lineHeight:1.5, minHeight:20 }}>{compareStatus}</p>
                      <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:10, margin:"0 0 16px" }}>
                        <span style={{ fontSize:11, color:C.muted }}>Step {compareStep} of {comparisons.filter(c=>!c.result).length * 3 + 2}</span>
                        <span style={{ fontSize:11, fontWeight:700, color:"#0369a1", background:"#e8f0fe", borderRadius:6, padding:"2px 9px", fontVariantNumeric:"tabular-nums", flexShrink:0 }}>
                          {Math.floor(compareElapsed/60)}:{String(compareElapsed%60).padStart(2,"0")}
                        </span>
                      </div>
                      <div style={{ display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap", marginBottom:12 }}>
                        {comparisons.map((c, i) => (
                          <span key={i} style={{ fontSize:11, color: c.result ? "#166534" : "#0369a1", background: c.result ? "#f0fdf4" : "#e8f0fe", border:`1px solid ${c.result ? "#a7f3d0" : "#bae6fd"}`, borderRadius:12, padding:"4px 12px", display:"inline-flex", alignItems:"center", gap:6 }}>
                            {c.result ? <span style={{ color:"#166534", fontWeight:700 }}>✓</span> : <span style={{ width:9, height:9, border:"1.5px solid #bae6fd", borderTop:"1.5px solid #0369a1", borderRadius:"50%", display:"inline-block", animation:"sp 0.7s linear infinite", flexShrink:0 }} />}
                            <span style={{ fontWeight: c.result ? 600 : 400 }}>{c.title}</span>
                          </span>
                        ))}
                      </div>
                      {comparisons.some(c => c.result) && (
                        <p style={{ margin:0, fontSize:11, color:"#166534", fontWeight:600 }}>{comparisons.filter(c => c.result).length} of {comparisons.length} ready</p>
                      )}
                    </div>
                  ) : readyComps.length >= 2 ? (
                    <ComparisonPanel
                      comparisons={comparisons}
                      onRemove={removeFromComparison}
                      onAnalyse={handleAnalyseRole}
                      currentTitle={toTitleCase(sel?.title || "")}
                      onAddThird={() => {
                        const currentTitle = toTitleCase(sel?.title || "");
                        const alreadyIn = comparisons.find(c => c.title === currentTitle);
                        const updated = alreadyIn ? comparisons : [...comparisons, { title: currentTitle, result }];
                        softReset(updated);
                      }}
                    />
                  ) : (
                    <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"24px 20px", textAlign:"center" }}>
                      <p style={{ margin:0, fontSize:13, color:C.muted }}>Roles are still being analysed. Please wait.</p>
                    </div>
                  )}
                </div>
                );
              })()}


              <Disclaimer />

              {/* Subtle footer */}
              <ResultFooter />
            </div>
          );
        })()}

      </div>
    </div>
    </>
  );
}
